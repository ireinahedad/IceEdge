import { pool } from '../db/connection';
import { notifySlipPlaced } from './settlement.service';
import { fetchGameById } from './nhlApiClient';
import { logger } from '../logger';

// ─── XP & Tier config ─────────────────────────────────────────────────────────

// Tier thresholds (minimum XP required)
const TIER_THRESHOLDS: Record<string, number> = {
  rookie:  0,
  analyst: 100,
  sharp:   500,
  legend:  1500,
};

// Ordered tiers lowest→highest
const TIER_ORDER = ['rookie', 'analyst', 'sharp', 'legend'] as const;
type Tier = typeof TIER_ORDER[number];

function tierForXp(xp: number): Tier {
  for (let i = TIER_ORDER.length - 1; i >= 0; i--) {
    if (xp >= TIER_THRESHOLDS[TIER_ORDER[i]]) return TIER_ORDER[i];
  }
  return 'rookie';
}

/**
 * Risk-based XP.
 * Win : the riskier the bet (low probability), the more XP.
 *   P=80% → +40 XP · P=50% → +100 XP · P=15% → +170 XP
 * Loss : the safer the bet was, the more XP is lost.
 *   P=80% → −40 XP · P=50% → −25 XP · P=15% → −8 XP
 */
export function xpForOutcome(outcome: 'win' | 'loss', combinedProbability: number | null): number {
  const P = Math.max(1, Math.min(99, combinedProbability ?? 50));
  return outcome === 'win'
    ? Math.max(10, Math.round((100 - P) * 2))
    : -Math.max(5, Math.round(P / 2));
}

/**
 * Apply an XP delta (positive or negative) to a user.
 * XP is floored at 0. The tier is recomputed in both directions,
 * and a tier badge is awarded when the user moves up.
 */
export async function applyXpDelta(
  userId: string,
  delta: number,
): Promise<{ newXp: number; newTier: Tier; tieredUp: boolean }> {
  await pool.query(
    `INSERT INTO user_profiles (user_id, xp, tier, performance_score)
     SELECT id, 0, 'rookie', 0 FROM users WHERE id = $1
     ON CONFLICT (user_id) DO NOTHING`,
    [userId],
  );

  const { rows: profileRows } = await pool.query<{ xp: number; tier: string }>(
    `SELECT xp, tier FROM user_profiles WHERE user_id = $1`,
    [userId],
  );
  const profile  = profileRows[0] ?? { xp: 0, tier: 'rookie' };
  const prevTier = (profile.tier ?? 'rookie') as Tier;
  const newXp    = Math.max(0, (profile.xp ?? 0) + delta);
  const newTier  = tierForXp(newXp);
  const tieredUp = TIER_ORDER.indexOf(newTier) > TIER_ORDER.indexOf(prevTier);

  await pool.query(
    `UPDATE user_profiles
     SET xp = $1, tier = $2, performance_score = $1
     WHERE user_id = $3`,
    [newXp, newTier, userId],
  );

  if (tieredUp) {
    const TIER_BADGES: Record<Tier, { label: string; icon: string; description: string }> = {
      analyst: { label: 'Analyst',      icon: '📊', description: 'Reached Analyst tier' },
      sharp:   { label: 'Sharp Bettor', icon: '🎯', description: 'Reached Sharp tier'   },
      legend:  { label: 'Legend',       icon: '👑', description: 'Reached Legend tier'  },
      rookie:  { label: 'Rookie',       icon: '🌱', description: 'Welcome!'             },
    };
    const badge = TIER_BADGES[newTier];
    await pool.query(
      `INSERT INTO user_badges (user_id, badge_id, label, description, icon, earned_at, tier)
       VALUES ($1, $2, $3, $4, $5, CURRENT_DATE, $6)
       ON CONFLICT (user_id, badge_id) DO NOTHING`,
      [userId, `tier_${newTier}`, badge.label, badge.description, badge.icon, newTier],
    );
  }

  return { newXp, newTier, tieredUp };
}

// ─── Submit slip ──────────────────────────────────────────────────────────────

export interface SlipLeg {
  marketType:   string;
  subjectId?:   string;
  subjectName:  string;
  subjectLogo:  string;
  selection?:   string;
  line?:        number;
  probability:  number;
  oddsLabel:    string;
  /** NHL game id — required for automatic settlement */
  gameId?:      string;
  /** Machine-readable selection (team id, 'over', 'under'…) */
  selectionValue?: string;
}

/**
 * Heure de verrouillage d'un coupon = mise au jeu de son match le plus TÔT.
 *
 * Un parlay se déverrouille dès que son premier match commence : à partir de là
 * le contenu du ticket n'a plus de valeur pour un copieur, et le masquer plus
 * longtemps ne protégerait plus rien.
 *
 * Résolu ICI, au serveur, et figé en base — jamais accepté du client, qui
 * s'offrirait le déverrouillage instantané en éditant une requête, et jamais
 * recalculé à la lecture, qui coûterait un appel NHL par affichage de page.
 *
 * Renvoie `null` si aucune heure n'est exploitable (pas de `gameId`, pari
 * futures, API indisponible). Le NULL n'est pas « pas de verrou » : la lecture
 * le traite comme « masqué tant que le coupon est pending ». Une panne de
 * résolution doit rendre un coupon trop discret, pas le divulguer trop tôt.
 */
async function resolveLocksAt(legs: SlipLeg[]): Promise<Date | null> {
  const gameIds = [...new Set(legs.map((l) => l.gameId).filter(Boolean) as string[])];
  if (!gameIds.length) return null;

  // Séquentiel : un coupon plafonne à 12 jambes, donc à 12 matchs distincts, et
  // `fetchGameById` est déjà mis en cache côté client NHL.
  let earliest: number | null = null;
  for (const id of gameIds) {
    try {
      const game = await fetchGameById(id);
      const ms = game?.startTimeUTC ? new Date(game.startTimeUTC).getTime() : NaN;
      if (Number.isFinite(ms)) earliest = earliest == null ? ms : Math.min(earliest, ms);
    } catch {
      // Un match non résolu ne doit pas faire échouer la soumission : le pari
      // de l'utilisateur passe avant l'exactitude du verrou.
    }
  }

  if (earliest == null) {
    logger.warn({ gameIds }, '[slip] locks_at non résolu — le coupon restera masqué aux tiers jusqu\'à son règlement');
  }
  return earliest == null ? null : new Date(earliest);
}

export async function submitSlip(
  userId:              string,
  legs:                SlipLeg[],
  sport:               string = 'hockey',
  combinedProbability: number | null = null,
) {
  if (!legs.length) throw Object.assign(new Error('Slip must have at least one leg'), { status: 400 });
  if (legs.length > 12) throw Object.assign(new Error('Max 12 legs per slip'), { status: 400 });

  const isParlay = legs.length > 1;
  const combined =
    combinedProbability ??
    Math.round(legs.reduce((acc, l) => acc * (l.probability / 100), 1) * 100);

  const locksAt = await resolveLocksAt(legs);

  const { rows } = await pool.query<{ id: string }>(
    `INSERT INTO bet_slips
       (user_id, sport, legs, leg_count, is_parlay, combined_probability, outcome, locks_at)
     VALUES ($1, $2, $3::jsonb, $4, $5, $6, 'pending', $7)
     RETURNING id`,
    [userId, sport, JSON.stringify(legs), legs.length, isParlay, combined, locksAt],
  );

  // Wake the settlement scheduler so it re-plans its wake horizon around this
  // bet's game(s) instead of waiting out a long idle sleep.
  notifySlipPlaced();

  return rows[0].id;
}

// ─── List slips for a user ────────────────────────────────────────────────────

export async function getSlips(userId: string, limit = 50) {
  const { rows } = await pool.query(
    `SELECT id, placed_at AS "placedAt", sport,
            legs, leg_count AS "legCount", is_parlay AS "isParlay",
            combined_probability AS "combinedProbability",
            outcome, resolved_at AS "resolvedAt", xp_awarded AS "xpAwarded"
     FROM bet_slips
     WHERE user_id = $1
     ORDER BY placed_at DESC
     LIMIT $2`,
    [userId, limit],
  );
  return rows;
}

// ─── Resolve slip (win | loss) + award XP ────────────────────────────────────

export async function resolveSlip(
  slipId:  string,
  outcome: 'win' | 'loss',
  userId:  string,
): Promise<{ xpAwarded: number; newXp: number; newTier: Tier; tieredUp: boolean }> {
  // Load the slip
  const { rows: slipRows } = await pool.query(
    `SELECT id, user_id, is_parlay, leg_count, outcome,
            combined_probability AS "combinedProbability"
     FROM bet_slips
     WHERE id = $1`,
    [slipId],
  );
  const slip = slipRows[0];
  if (!slip) throw Object.assign(new Error('Slip not found'), { status: 404 });
  if (slip.user_id !== userId) throw Object.assign(new Error('Forbidden'), { status: 403 });
  if (slip.outcome !== 'pending') throw Object.assign(new Error('Slip already resolved'), { status: 400 });

  // Risk-based XP: wins earn more when the bet was risky,
  // losses cost more when the bet was "safe".
  const xpAwarded = xpForOutcome(outcome, slip.combinedProbability);

  // Update slip (guard: only if still pending — avoids double-award races)
  const upd = await pool.query(
    `UPDATE bet_slips
     SET outcome = $1, resolved_at = NOW(), xp_awarded = $2
     WHERE id = $3 AND outcome = 'pending'`,
    [outcome, xpAwarded, slipId],
  );
  if (!upd.rowCount) throw Object.assign(new Error('Slip already resolved'), { status: 400 });

  const { newXp, newTier, tieredUp } = await applyXpDelta(userId, xpAwarded);

  return { xpAwarded, newXp, newTier, tieredUp };
}

// ─── Get a single slip ────────────────────────────────────────────────────────

export async function getSlip(slipId: string, userId: string) {
  const { rows } = await pool.query(
    `SELECT id, placed_at AS "placedAt", sport,
            legs, leg_count AS "legCount", is_parlay AS "isParlay",
            combined_probability AS "combinedProbability",
            outcome, resolved_at AS "resolvedAt", xp_awarded AS "xpAwarded"
     FROM bet_slips
     WHERE id = $1 AND user_id = $2`,
    [slipId, userId],
  );
  if (!rows[0]) throw Object.assign(new Error('Slip not found'), { status: 404 });
  return rows[0];
}
