import { Router, Request, Response } from "express";
import {
  predictMoneyline,
  predictPuckLine,
  predictTotalGoals,
  predictAnytimeGoal,
  predictFirstGoalScorer,
  predictShotsOU,
  predictAssistsOU,
  predictPointsOU,
  predictPPPoint,
  predictPositionBasedProp,
  predictFutures,
  predictDoubleChance,
  predictAltPuckLine,
  predictRegulationResult,
  predictTeamToScore,
  predictBothTeamsScore,
  predictCleanSheet,
  predictTeamPPGoal,
  predictPenaltyKill,
  predictWinningMargin,
  predictPeriodWinner,
  predictPeriodTotalGoals,
  buildRealFactors,
} from "../services/predictionEngine";
import { mlApiClient } from "../services/mlApiClient";
import { fetchGameById } from "../services/nhlApiClient";
import {
  buildGameFeatures,
  buildPlayerPropFeatures,
  buildTeamFuturesFeatures,
} from "../services/featureEngineering";
import { getBestBets } from "../services/bestBets.service";
import { logger } from "../logger";
import { sendError } from "../httpError";
import { validateBody } from "../middleware/validate.middleware";
import { predictLimiter } from "../middleware/rateLimit.middleware";
import {
  singlePredictionSchema,
  parlayPredictionSchema,
  predictFactorsSchema,
  playerPropSchema,
  predictFuturesSchema,
  predictMlSchema,
} from "../validation/schemas";

/**
 * Routeur de prédiction — PUBLIC À DESSEIN, et donc protégé en deux temps.
 *
 * Ces routes restent ouvertes sans compte : la landing affiche des probabilités
 * à un visiteur qui n'a rien signé, et c'est le produit. Ce qu'elles ne peuvent
 * pas se permettre, c'est de rester ouvertes SANS BORNES — une requête entrante
 * gratuite y déclenche des appels sortants vers l'API NHL et le service ML
 * Python.
 *
 *   1. `validateBody` refuse le corps hors bornes AVANT tout appel sortant
 *      (schémas dans `validation/schemas.ts`, avec le pourquoi de chaque borne).
 *   2. `predictLimiter` plafonne les deux routes qui construisent des variables
 *      et appellent le service Python (`/ml`, `/factors`) — les autres restent
 *      sous `apiLimiter`, parce que la landing peut en tirer ~32 d'un coup.
 *
 * Les gardes en début de handler (`legs array required`, `type and subjectId
 * are required`) sont désormais redondantes avec les schémas. Elles sont
 * conservées : elles ne coûtent rien et gardent le handler juste s'il est un
 * jour monté sans son middleware.
 */
const router = Router();

// GET /api/predict/best-bets
// Top individual bets across all markets (team + player props),
// ranked by prediction score. ML-first with rule fallback.
// Query: ?limit=15&source=ml|rules&days=3&players=15
router.get("/best-bets", async (req: Request, res: Response) => {
  try {
    const source = req.query.source === "rules" ? "rules" : "ml";
    const result = await getBestBets({
      limit:      req.query.limit   ? parseInt(String(req.query.limit), 10)   : undefined,
      days:       req.query.days    ? parseInt(String(req.query.days), 10)    : undefined,
      maxPlayers: req.query.players ? parseInt(String(req.query.players), 10) : undefined,
      source,
    });
    // Même TTL que le cache serveur : navigateur et CDN absorbent les
    // rechargements de la landing entre deux recalculs.
    res.set("Cache-Control", "public, max-age=60, stale-while-revalidate=300");
    res.json(result);
  } catch (err: any) {
    sendError(res, err, { context: '[predict/best-bets]', fallbackMessage: 'Best bets failed' });
  }
});

// --- Types ---

type BetMarketType =
  | "moneyline" | "puck_line" | "total_goals" | "regulation_result"
  | "period1_winner" | "period2_winner" | "period3_winner"
  | "period1_total_goals" | "period2_total_goals" | "period3_total_goals"
  | "game_to_ot" | "both_teams_score" | "winning_margin"
  | "alt_puck_line" | "ot_winner"
  | "first_team_score" | "last_team_score" | "team_total_goals"
  | "team_pp_goals" | "team_penalty_kill" | "clean_sheet"
  | "highest_scoring_period"
  // ML-vocab aliases sent by the stats page (mapped to canonical markets)
  | "total_goals_over" | "total_goals_under" | "pp_goal" | "penalty_kill"
  | "anytime_goal" | "first_goal_scorer" | "shots_ou" | "assists_ou"
  | "points_ou" | "pp_point" | "goalie_saves_ou" | "penalty_minutes_ou"
  | "blocked_shots_ou" | "time_on_ice_ou" | "faceoff_wins_ou" | "hits_ou";

interface PredictionRequest {
  marketType: BetMarketType;
  gameId?: string;
  teamId?: string;
  opponentId?: string;
  playerId?: string;
  playerName?: string;
  selection?: string;
  line?: number;
  isHome?: boolean;
  seasonContext?: Record<string, unknown>;
}

// --- Helpers ---

function probToOddsLabel(pct: number): string {
  const p = Math.max(5, Math.min(95, pct)) / 100;
  if (p >= 0.5) return `-${Math.round((p / (1 - p)) * 100)}`;
  return `+${Math.round(((1 - p) / p) * 100)}`;
}

const GAME_MARKET_TYPES: BetMarketType[] = [
  "moneyline", "puck_line", "total_goals", "regulation_result",
  "period1_winner", "period2_winner", "period3_winner",
  "game_to_ot", "both_teams_score", "winning_margin",
  "first_team_score", "team_total_goals", "highest_scoring_period",
];

const PLAYER_MARKET_TYPES: BetMarketType[] = [
  "anytime_goal", "first_goal_scorer", "shots_ou", "assists_ou",
  "points_ou", "pp_point", "goalie_saves_ou", "penalty_minutes_ou",
  "blocked_shots_ou", "time_on_ice_ou", "faceoff_wins_ou", "hits_ou",
];

// --- Core prediction dispatcher ---

/**
 * Normalise ML-vocabulary aliases (sent by the stats page) into the canonical
 * { marketType, selection } used by the prediction engine. This is what keeps
 * the coupon and the stats page in sync: both funnel into the same markets.
 */
function normalizeMarket(
  marketType: string,
  selection: string
): { market: string; selection: string } {
  switch (marketType) {
    case "total_goals_over":  return { market: "total_goals", selection: "over" };
    case "total_goals_under": return { market: "total_goals", selection: "under" };
    case "pp_goal":           return { market: "team_pp_goals", selection };
    case "penalty_kill":      return { market: "team_penalty_kill", selection };
    default:                  return { market: marketType, selection };
  }
}

/**
 * Resolve a game-based request into concrete team/opponent/home-ice values.
 * The coupon sends { gameId, selection: <teamAbbr> } with no teamId; the stats
 * page sends { teamId, opponentId, isHome } directly. Both must end up equal.
 */
async function resolveSubjects(body: PredictionRequest): Promise<{
  teamId?: string;
  opponentId?: string;
  isHome: boolean;
  selection: string;
}> {
  let teamId     = body.teamId;
  let opponentId = body.opponentId;
  let isHome     = body.isHome ?? true;
  let selection  = body.selection ?? "over";

  if (body.gameId) {
    try {
      const game = await fetchGameById(body.gameId);
      const home = game?.homeTeam?.id ?? game?.homeTeam?.abbreviation;
      const away = game?.awayTeam?.id ?? game?.awayTeam?.abbreviation;
      const sel  = selection?.toLowerCase();
      // selection is a team abbreviation → that team is the subject
      if (sel && (sel === String(home).toLowerCase() || sel === String(away).toLowerCase())) {
        const selIsHome = sel === String(home).toLowerCase();
        teamId     = selIsHome ? home : away;
        opponentId = selIsHome ? away : home;
        isHome     = selIsHome;
      } else if (!teamId) {
        // over/under & game-level markets: default to the home side as anchor
        teamId     = home;
        opponentId = away;
        isHome     = true;
      }
    } catch {
      /* fall back to whatever the body provided */
    }
  }

  return { teamId, opponentId, isHome, selection };
}

async function computeProbability(body: PredictionRequest): Promise<number> {
  const { market } = normalizeMarket(body.marketType, body.selection ?? "over");
  const line = body.line ?? 0.5;
  const { teamId, opponentId, isHome, selection } = await resolveSubjects({
    ...body,
    selection: normalizeMarket(body.marketType, body.selection ?? "over").selection,
  });
  const playerId = body.playerId;

  // ── Game / team markets ──────────────────────────────────────────────────
  if (market === "moneyline") {
    if (!teamId) return 50;
    return predictMoneyline(teamId, opponentId, isHome);
  }
  if (market === "first_team_score" || market === "last_team_score") {
    if (!teamId) return 50;
    return predictTeamToScore(teamId, opponentId, isHome);
  }
  if (market === "puck_line") {
    if (!teamId) return 28;
    return predictPuckLine(teamId, opponentId, isHome);
  }
  if (market === "alt_puck_line") {
    if (!teamId) return 50;
    return predictAltPuckLine(teamId, opponentId, isHome);
  }
  if (market === "ot_winner") {
    if (!teamId) return 50;
    return predictDoubleChance(teamId, opponentId, isHome);
  }
  if (market === "regulation_result") {
    if (!teamId) return 40;
    return predictRegulationResult(teamId, opponentId, isHome);
  }
  if (market === "total_goals" || market === "team_total_goals") {
    return predictTotalGoals(line, selection, teamId, opponentId);
  }
  if (
    market === "period1_total_goals" ||
    market === "period2_total_goals" ||
    market === "period3_total_goals"
  ) {
    return predictPeriodTotalGoals(line, selection, teamId, opponentId);
  }
  if (
    market === "period1_winner" ||
    market === "period2_winner" ||
    market === "period3_winner"
  ) {
    if (!teamId) return 38;
    return predictPeriodWinner(teamId, opponentId, isHome);
  }
  if (market === "both_teams_score")   return predictBothTeamsScore(teamId, opponentId);
  if (market === "clean_sheet")        return predictCleanSheet(teamId, opponentId);
  if (market === "team_pp_goals")      return predictTeamPPGoal(teamId);
  if (market === "team_penalty_kill")  return predictPenaltyKill(teamId);
  if (market === "winning_margin")     return predictWinningMargin();
  if (market === "game_to_ot")         return 24;
  if (market === "highest_scoring_period") return 38;

  // ── Player markets ─────────────────────────────────────────────────────────
  if (!playerId) return 50;

  if (market === "anytime_goal")     return predictAnytimeGoal(playerId);
  if (market === "first_goal_scorer") return predictFirstGoalScorer(playerId);
  if (market === "last_goal_scorer")  return predictFirstGoalScorer(playerId);
  if (market === "shots_ou")         return predictShotsOU(playerId, line, selection);
  if (market === "assists_ou")       return predictAssistsOU(playerId, line, selection);
  if (market === "points_ou")        return predictPointsOU(playerId, line, selection);
  if (market === "pp_point")         return predictPPPoint(playerId);

  if (
    market === "hits_ou" ||
    market === "blocked_shots_ou" ||
    market === "time_on_ice_ou" ||
    market === "faceoff_wins_ou" ||
    market === "penalty_minutes_ou" ||
    market === "goalie_saves_ou"
  ) {
    return predictPositionBasedProp(playerId, market, line, selection);
  }

  return 50;
}

// --- Routes ---

// POST /api/predict/single
router.post("/single", validateBody(singlePredictionSchema), async (req: Request, res: Response) => {
  try {
    const body        = req.body as PredictionRequest;
    const probability = await computeProbability(body);

    const confidence =
      probability >= 70 ? "very_high" :
      probability >= 60 ? "high"      :
      probability >= 50 ? "medium"    :
      probability >= 40 ? "low"       : "very_low";

    const factorType = body.playerId ? "player" : "team";
    const factorId   = body.playerId ?? body.teamId ?? "";
    const factors    = factorId
      ? await buildRealFactors(factorType, factorId, probability)
      : [];

    res.json({
      probability,
      confidence,
      factors,
      oddsLabel: probToOddsLabel(probability),
      modelVersion: "nhl-stats-v1.0",
      generatedAt: new Date().toISOString(),
    });
  } catch (err: any) {
    sendError(res, err, { context: '[predict/single]', fallbackMessage: 'Prediction failed' });
  }
});

// POST /api/predict/parlay
router.post("/parlay", validateBody(parlayPredictionSchema), (req: Request, res: Response) => {
  const { legs } = req.body as {
    legs: Array<{ marketType: BetMarketType; probability: number }>;
  };

  if (!Array.isArray(legs) || legs.length === 0) {
    res.status(400).json({ error: "legs array required" });
    return;
  }

  const combined = legs.reduce((acc, leg) => acc * (leg.probability / 100), 1) * 100;
  const adjusted = combined * 0.95;

  res.json({
    combinedProbability: Math.round(combined * 10) / 10,
    adjustedProbability: Math.round(adjusted * 10) / 10,
    legs: legs.map((leg) => ({
      marketType:  leg.marketType,
      probability: leg.probability,
    })),
  });
});

// GET /api/predict/markets/game/:id
router.get("/markets/game/:id", (_req: Request, res: Response) => {
  res.json(GAME_MARKET_TYPES);
});

// GET /api/predict/markets/player/:id
router.get("/markets/player/:id", (_req: Request, res: Response) => {
  res.json(PLAYER_MARKET_TYPES);
});

// POST /api/predict/factors
router.post("/factors", predictLimiter, validateBody(predictFactorsSchema), async (req: Request, res: Response) => {
  try {
    const { type, id, context = {} } = req.body as {
      type: string;
      id: string;
      context?: Record<string, unknown>;
    };

    const fallbackPct = (context.fallbackPct as number) ?? 50;
    const factors     = await buildRealFactors(type, id, fallbackPct);
    const deltaSum    = factors.reduce((s, f) => s + (f.delta ?? 0), 0);
    const finalPct    = Math.round(Math.max(3, Math.min(97, 50 + deltaSum)));

    res.json({ basePct: 50, factors, finalPct });
  } catch (err: any) {
    sendError(res, err, { context: '[predict/factors]', fallbackMessage: 'Factors failed' });
  }
});

// POST /api/predict/player-prop  (season-long prop)
router.post("/player-prop", validateBody(playerPropSchema), async (req: Request, res: Response) => {
  try {
    const { playerName, propType, line, playerId } = req.body as {
      playerName: string;
      propType: "goals" | "points" | "assists" | "award";
      line: number;
      playerId?: string;
    };

    let probability = 50;
    let factors: any[] = [];
    let betNote = `${playerName} season prop estimate.`;

    if (playerId) {
      const { fetchPlayerById } = await import("../services/nhlApiClient");
      const player = await fetchPlayerById(playerId);

      const gp = player.gamesPlayed || 1;
      const remaining = Math.max(0, 82 - gp);
      const current =
        propType === "goals"   ? player.goals   :
        propType === "points"  ? player.points  :
        propType === "assists" ? player.assists  : 0;

      const pace        = (current / gp) * 82;
      const needed      = line - current;
      const currentRate = current / gp;
      const rateNeeded  = remaining > 0 ? needed / remaining : Infinity;

      probability =
        needed <= 0                      ? 95 :
        rateNeeded <= currentRate * 0.85 ? 75 :
        rateNeeded <= currentRate        ? 62 :
        rateNeeded <= currentRate * 1.15 ? 45 : 28;

      probability = Math.max(3, Math.min(97, probability));

      factors = [
        { icon: "chart", label: `Season pace: ${pace.toFixed(0)} (line: ${line})`, delta: pace >= line ? 12 : -8 },
        { icon: "calendar", label: `${remaining} games remaining, needs ${needed} more`, delta: remaining >= 20 ? 5 : remaining >= 10 ? 2 : -3 },
        { icon: "trending", label: `Averaging ${currentRate.toFixed(2)}/game`, delta: currentRate >= rateNeeded ? 6 : -4 },
      ];
      betNote = `${player.name || playerName} needs ${needed} more ${propType} in ${remaining} games (pace: ${pace.toFixed(0)}).`;
    }

    res.json({
      probability,
      oddsLabel: probToOddsLabel(probability),
      factors,
      betNote,
    });
  } catch (err: any) {
    sendError(res, err, { context: '[predict/player-prop]', fallbackMessage: 'Player prop failed' });
  }
});

// POST /api/predict/futures
router.post("/futures", validateBody(predictFuturesSchema), async (req: Request, res: Response) => {
  try {
    const { teamName, teamId, propType } = req.body as {
      teamName: string;
      teamId?: string;
      propType: "cup" | "conf" | "playoff";
    };

    const id          = teamId ?? teamName;
    const probability = await predictFutures(id, propType);

    res.json({
      probability,
      oddsLabel: probToOddsLabel(probability),
      factors: [
        { icon: "standings", label: `${teamName} standings rank`, delta: probability >= 20 ? 8 : -4 },
      ],
      betNote: `${teamName} ${propType} probability based on current standings.`,
    });
  } catch (err: any) {
    sendError(res, err, { context: '[predict/futures]', fallbackMessage: 'Futures failed' });
  }
});

// ── ML service proxy ──────────────────────────────────────────────────────────
//
// POST /api/predict/ml
// Builds feature vector from NHL API data, POSTs it to the Python ML service,
// and returns the ML response. Falls back to null (frontend handles gracefully).
//
// Body: { type, subjectId, opponentId?, propType?, line?, selection? }

router.post('/ml', predictLimiter, validateBody(predictMlSchema), async (req: Request, res: Response) => {
  try {
    const { type, subjectId, opponentId, propType, line, selection } = req.body as {
      type:        'game' | 'player' | 'team';
      subjectId:   string;
      opponentId?: string;
      propType?:   string;
      line?:       number;
      selection?:  string;
    };

    if (!type || !subjectId) {
      return res.status(400).json({ error: 'type and subjectId are required' });
    }

    let result;

    if (type === 'game') {
      const marketType = propType ?? 'moneyline';
      const features = await buildGameFeatures(subjectId, opponentId ?? subjectId, marketType, line);
      result = await mlApiClient.predictGame(features);
    } else if (type === 'player') {
      const features = await buildPlayerPropFeatures(
        subjectId,
        propType ?? 'goals',
        line    ?? 0.5,
        selection ?? 'over'
      );
      result = await mlApiClient.predictPlayer(features);
    } else if (type === 'team') {
      const features = await buildTeamFuturesFeatures(subjectId, propType ?? 'moneyline');
      result = await mlApiClient.predictTeam(features);
    } else {
      return res.status(400).json({ error: `Unknown type: ${type}` });
    }

    res.json(result);
  } catch (err: any) {
    // ML service may be down — return 503 so frontend can silently hide the section.
    //
    // `detail: err.message` a été retiré : il portait l'adresse du service
    // Python (« fetch failed for http://ml-internal:8000/predict/game ») droit
    // dans le corps d'une réponse publique. Le client ne s'en servait pas — il
    // masque simplement la section sur un 503 — et le message complet part
    // maintenant dans les journaux, où il sert vraiment.
    logger.warn({ err: err.message }, '[predict/ml] ML service unavailable');
    res.status(503).json({ error: 'ML service unavailable' });
  }
});

export default router;
