#!/usr/bin/env node
/**
 * ArakIce — programmatic SEO page generator.
 *
 * Produces static, indexable HTML into client/public/ :
 *   - /nhl-player-props            props hub with client-side player search
 *   - /props/<player-slug>         one evergreen page per active player (#1)
 *   - /nhl-matchups                matchup hub
 *   - /matchup/<a>-vs-<b>          one page per team pair that plays (#4)
 * ...and regenerates /sitemap.xml (static pages + generated pages).
 *
 * Pages are EVERGREEN: durable content + a CTA into the app for the live
 * "tonight" projection. Re-run this script to add newly scheduled matchups
 * and refresh rosters/stats. Run on a machine with internet (the NHL public
 * API is not reachable from CI sandboxes here).
 *
 * Usage:
 *   node scripts/seo-gen.mjs            # full run against the NHL API
 *   node scripts/seo-gen.mjs --sample   # offline fixtures -> ./scripts/_sample_out
 *   MIN_GP=5 node scripts/seo-gen.mjs   # only players with >=5 games played
 *
 * No dependencies — Node 18+ (global fetch).
 */

import { promises as fs } from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── Config ──────────────────────────────────────────────────────────────────
const SITE = "https://arakice.com";
const API = "https://api-web.nhle.com/v1";
const SAMPLE = process.argv.includes("--sample");
const OUT_DIR = SAMPLE
  ? path.join(os.tmpdir(), "arakice-seo-sample")
  : process.env.SEO_OUT || path.join(__dirname, "..", "public");
const HORIZON_WEEKS = Number(process.env.HORIZON_WEEKS || 3); // how many schedule weeks to walk
// Gate thin player pages. 20 GP (a quarter season) is the floor at which a
// player page has enough real data to say anything the template does not already
// say. Below it the page is ~750 words of boilerplate around a line of zeroes,
// which is what Google's scaled-content-abuse policy targets — and hundreds of
// those drag down the pages that DO deserve to rank.
const MIN_GP = Number(process.env.MIN_GP || 20);
const CONCURRENCY = 6;

const STATIC_PAGES = [
  { loc: "/", changefreq: "daily", priority: "1.0" },
  { loc: "/nhl-predictions-today", changefreq: "daily", priority: "0.9" },
  { loc: "/best-nhl-picks-today", changefreq: "daily", priority: "0.9" },
  { loc: "/nhl-ai-predictions", changefreq: "weekly", priority: "0.8" },
  { loc: "/best-nhl-betting-software", changefreq: "monthly", priority: "0.7" },
  { loc: "/about", changefreq: "monthly", priority: "0.5" },

  // App routes made independently indexable by scripts/route-shells.mjs (each
  // gets its own title/description/canonical at build time). They must be in the
  // sitemap for Google to consider them as sitelink candidates. Keep this list in
  // sync with ROUTES in route-shells.mjs.
  { loc: "/nhl-predictions", changefreq: "daily", priority: "0.9" },
  { loc: "/schedule", changefreq: "daily", priority: "0.9" },
  { loc: "/stats", changefreq: "daily", priority: "0.8" },
  { loc: "/stats/chart/all-teams", changefreq: "daily", priority: "0.8" },
  { loc: "/bet", changefreq: "weekly", priority: "0.7" },
  { loc: "/league", changefreq: "daily", priority: "0.7" },
  // /login is deliberately absent: route-shells.mjs marks it `noindex`, and a
  // sitemap entry for a noindexed URL is a contradictory signal that shows up in
  // Search Console as "Submitted URL marked noindex".
];

// ── Liste blanche des pages joueur ───────────────────────────────────────────
// Le gabarit produisait 786 pages quasi identiques ; Search Console en a refusé
// 417 (« Crawled - currently not indexed »). On ne garde que celles dont la
// donnée montre qu'elles servent à quelque chose. La liste et sa provenance
// vivent dans scripts/props-allowlist.json, pour être remise à jour depuis
// Search Console sans toucher au code.
//
// ⚠️ MIN_GP ne suffisait pas : c'était un proxy de « page mince » et il se
// trompait. Sept pages sous 20 matchs joués rankaient réellement, dont une en
// position 4 avec un clic. C'est la donnée qui tranche, pas le nombre de matchs.
const ALLOWLIST_PATH = process.env.PROPS_ALLOWLIST
  || path.join(__dirname, "props-allowlist.json");

async function loadPropsAllowlist() {
  try {
    const raw = await fs.readFile(ALLOWLIST_PATH, "utf-8");
    const slugs = JSON.parse(raw).slugs;
    if (!Array.isArray(slugs) || !slugs.length) throw new Error("slugs vide");
    return new Set(slugs);
  } catch (e) {
    // Pas de repli silencieux sur « tout écrire » : ce serait republier les 786
    // pages sans que personne ne le remarque.
    throw new Error(`liste blanche des props illisible (${ALLOWLIST_PATH}) : ${e.message}`);
  }
}

// ── Head to head history ─────────────────────────────────────────────────────
// Les pages d'affiche ne servaient qu'un explicatif générique : Google en a
// refusé 417 sur 786 du même moule côté joueurs, et les pages d'affiche
// plafonnaient à 0 clic malgré des impressions réelles. Elles servent
// maintenant l'historique réel de la confrontation, tiré du jeu de données ML.
//
// ⚠️ COUPLAGE ASSUMÉ : ce générateur, qui ne lisait que l'API NHL, dépend
// désormais d'un fichier de `ml/`. Le couplage se limite aux 9 colonnes ci-
// dessous, qui sont stables. La lecture est tolérante : fichier absent ou
// illisible => les pages se génèrent sans le bloc plutôt que de casser le build.
const H2H_CSV = process.env.H2H_CSV || path.join(__dirname, "..", "..", "ml", "data", "nhl_games_v4.csv");
const H2H_SEASONS = new Set(["2021", "2022", "2023", "2024", "2025"]); // 5 dernières
// Sous ce nombre de rencontres on donne le décompte brut et jamais un
// pourcentage : « 100 % en prolongation » sur 4 matchs décrédibilise la page.
const H2H_MIN_PCT = 8;
// La franchise d'Utah n'existe que depuis 2024-25. Le jeu de données réécrit
// TOUTE l'histoire d'Arizona/Phoenix en UTA : sans ce plancher, la page
// attribuerait à Utah seize saisons qui ne sont pas les siennes.
const RELOCATED_SINCE = { UTA: "2024" };

async function loadH2H() {
  let raw;
  try {
    raw = await fs.readFile(H2H_CSV, "utf-8");
  } catch {
    console.warn(`  ⚠️  ${H2H_CSV} illisible — les pages d'affiche seront générées sans historique.`);
    return new Map();
  }
  const lines = raw.split("\n");
  const head = lines[0].split(",");
  const ix = {};
  for (const c of ["season","date","home_team","away_team","home_score","away_score","home_win","total_goals","went_to_ot"]) {
    ix[c] = head.indexOf(c);
    if (ix[c] < 0) {
      console.warn(`  ⚠️  colonne « ${c} » absente de ${H2H_CSV} — historique désactivé.`);
      return new Map();
    }
  }
  // Le fichier est écrit par pandas : pas de champ entre guillemets, un split
  // suffit. Les booléens y sont sérialisés en "1.0"/"0.0" et non "1"/"0" —
  // comparer à "1" rendait 0 prolongation sur 129 pages, un chiffre inventé.
  const yes = (v) => v === "1" || v === "1.0";
  const games = new Map();
  for (let i = 1; i < lines.length; i++) {
    const f = lines[i].split(",");
    if (f.length < head.length) continue;
    const season = f[ix.season];
    if (!H2H_SEASONS.has(season)) continue;
    const total = f[ix.total_goals];
    if (!total) continue;
    const home = f[ix.home_team], away = f[ix.away_team];
    const floor = RELOCATED_SINCE[home] || RELOCATED_SINCE[away];
    if (floor && season < floor) continue;
    const key = [home, away].sort().join("|");
    if (!games.has(key)) games.set(key, []);
    games.get(key).push({
      date: f[ix.date], home, away,
      hs: Number(f[ix.home_score]), as: Number(f[ix.away_score]),
      homeWin: yes(f[ix.home_win]), total: Number(total), ot: yes(f[ix.went_to_ot]),
    });
  }
  for (const list of games.values()) list.sort((x, y) => x.date.localeCompare(y.date));
  return games;
}

// ── Small utilities ───────────────────────────────────────────────────────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function slugify(s) {
  return String(s || "")
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function esc(s) {
  return String(s == null ? "" : s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function nhlLogo(abbr) {
  return `https://assets.nhle.com/logos/nhl/svg/${String(abbr).toUpperCase()}_light.svg`;
}

async function getJSON(url, tries = 3) {
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url, { headers: { "User-Agent": "ArakIce-SEO/1.0" } });
      if (!res.ok) throw new Error("HTTP " + res.status);
      return await res.json();
    } catch (e) {
      if (i === tries - 1) throw e;
      await sleep(400 * (i + 1));
    }
  }
}

async function pMap(items, fn, concurrency = CONCURRENCY) {
  const out = [];
  let idx = 0;
  const workers = Array.from({ length: Math.min(concurrency, items.length) }, async () => {
    while (idx < items.length) {
      const cur = idx++;
      try { out[cur] = await fn(items[cur], cur); }
      catch (e) { out[cur] = null; }
    }
  });
  await Promise.all(workers);
  return out;
}

async function writePage(relPath, html) {
  const full = path.join(OUT_DIR, relPath);
  await fs.mkdir(path.dirname(full), { recursive: true });
  await fs.writeFile(full, html, "utf-8");
}

// ── Shared HTML shell ─────────────────────────────────────────────────────────
// `disclaimer` : l'avertissement de jeu responsable n'a de sens que sur une page
// qui parle de pari ou de cotes. Les pages d'affiche n'en parlent plus (elles ne
// servent que des statistiques de match) et le passent donc à false ; toutes les
// autres pages le gardent.
function layout({ title, desc, canonicalPath, jsonld, body, extraHead = "", disclaimer = true }) {
  const url = SITE + canonicalPath;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${esc(title)}</title>
  <meta name="description" content="${esc(desc)}" />
  <link rel="canonical" href="${url}" />
  <meta name="robots" content="index, follow, max-image-preview:large" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="ArakIce" />
  <meta property="og:title" content="${esc(title)}" />
  <meta property="og:description" content="${esc(desc)}" />
  <meta property="og:url" content="${url}" />
  <meta property="og:image" content="${SITE}/arakice-og.png" />
  <meta property="og:image:secure_url" content="${SITE}/arakice-og.png" />
  <meta property="og:image:type" content="image/png" />
  <meta property="og:image:width" content="1200" />
  <meta property="og:image:height" content="630" />
  <meta property="og:image:alt" content="ArakIce, NHL predictions powered by ML" />
  <meta name="twitter:card" content="summary_large_image" />
  <meta name="twitter:title" content="${esc(title)}" />
  <meta name="twitter:description" content="${esc(desc)}" />
  <meta name="twitter:image" content="${SITE}/arakice-og.png" />
  <meta name="twitter:image:alt" content="ArakIce, NHL predictions powered by ML" />
  <link rel="icon" type="image/png" sizes="96x96" href="/arakice-icon-96.png" />
  <link rel="icon" type="image/png" sizes="192x192" href="/arakice-icon-192.png" />
  <link rel="icon" type="image/png" sizes="512x512" href="/arakice-icon-512.png" />
  <link rel="apple-touch-icon" sizes="180x180" href="/arakice-icon-180.png" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="/seo.css" />
${jsonld ? `  <script type="application/ld+json">\n${JSON.stringify(jsonld, null, 2)}\n  </script>\n` : ""}${extraHead}</head>
<body>
  <header class="site-header">
    <div class="wrap">
      <a class="brand" href="${SITE}/" aria-label="ArakIce home">
        <img class="brand-logo" src="/arakice-logo-80.png" alt="ArakIce" width="40" height="40" />
        <span class="brand-word">ArakIce</span>
      </a>
      <a class="nav-cta" href="${SITE}/">Open the app</a>
    </div>
  </header>
  <main>
${body}
${disclaimer ? `    <div class="disclaimer">
      <p>ArakIce provides statistical analysis and predictions for informational and entertainment purposes only. Nothing here is financial advice or a guarantee of results. Betting involves risk and you should never wager more than you can afford to lose. Must be of legal gambling age in your jurisdiction. If gambling stops being fun, help is available. In the US, call or text 1-800-GAMBLER.</p>
    </div>` : ""}
  </main>
  <footer class="site-footer">
    <div class="wrap">
      <nav>
        <a href="${SITE}/nhl-predictions-today">NHL Predictions</a>
        <a href="${SITE}/nhl-player-props">Player Props</a>
        <a href="${SITE}/nhl-matchups">Matchups</a>
        <a href="${SITE}/best-nhl-picks-today">Best Picks</a>
      </nav>
      <span>&copy; ArakIce. Statistical edge for smarter sports bets.</span>
    </div>
  </footer>
</body>
</html>
`;
}

function ctaBox(heading, text, label) {
  return `    <div class="cta-box">
      <h3>${esc(heading)}</h3>
      <p>${esc(text)}</p>
      <a class="btn" href="${SITE}/">${esc(label)}</a>
    </div>`;
}

// ── Templates ────────────────────────────────────────────────────────────────
function playerPage(p) {
  const isGoalie = p.pos === "G";
  const posName = { C: "center", L: "left wing", R: "right wing", D: "defenseman", G: "goaltender" }[p.pos] || "player";
  const team = p.teamName || p.team;
  const s = p.stats || {};
  const gp = Number(s.gamesPlayed || 0);

  // Per-game rates → genuinely unique numbers per player (reduces duplicate-content risk).
  let rateBlock = "";
  if (!isGoalie && gp > 0) {
    const ppg = (Number(s.points || 0) / gp).toFixed(2);
    const spg = (Number(s.shots || 0) / gp).toFixed(1);
    const gpg = (Number(s.goals || 0) / gp).toFixed(2);
    rateBlock = `      <h2>What ${esc(p.name)}'s rates tell us</h2>
      <p>Across ${gp} games, ${esc(p.name)} is averaging about <strong>${ppg} points</strong> and <strong>${spg} shots on goal</strong> per game, at roughly ${gpg} goals a night. Rates matter more than raw totals for props, because a prop line is a single game question, and a pace of ${spg} shots is the base the model adjusts up or down for the specific matchup, ice time and pace. When ${esc(p.name)}'s role or linemates change, those rates are the first thing to move.</p>`;
  } else if (isGoalie && gp > 0) {
    const svp = s.savePctg != null ? Number(s.savePctg).toFixed(3) : null;
    rateBlock = `      <h2>What ${esc(p.name)}'s numbers tell us</h2>
      <p>Over ${gp} appearances${svp ? ` at a ${svp} save percentage` : ""}, ${esc(p.name)} gives the model a base workload and stopping rate to build on. For goaltender props, the swing factor is volume: the model estimates how many shots ${esc(team)}'s opponent is likely to generate, then pairs that with ${esc(p.name)}'s save rate to project saves. A busy opponent lifts the saves projection even when the win is in doubt. A quiet one suppresses it.</p>`;
  }
  const statCards = isGoalie
    ? [
        ["GP", s.gamesPlayed], ["W", s.wins], ["GAA", s.goalsAgainstAvg != null ? Number(s.goalsAgainstAvg).toFixed(2) : null],
        ["SV%", s.savePctg != null ? Number(s.savePctg).toFixed(3) : null], ["SO", s.shutouts],
      ]
    : [
        ["GP", s.gamesPlayed], ["G", s.goals], ["A", s.assists], ["P", s.points], ["SOG", s.shots],
      ];
  const cardsHtml = statCards
    .filter(([, v]) => v != null && v !== "")
    .map(([l, v]) => `        <div class="stat"><div class="value">${esc(v)}</div><div class="label">${esc(l)}</div></div>`)
    .join("\n");

  const propsFocus = isGoalie
    ? `For a goaltender like ${esc(p.name)}, the props that matter most are saves and, on the totals side, the game's over/under. Both driven by how many shots the opposition is likely to generate. Our model estimates ${esc(p.name)}'s expected workload from the quality of shots ${esc(team)} tends to allow, the pace of the opponent, and rest, then compares that projection to the posted save line.`
    : `For a skater like ${esc(p.name)}, shots on goal and points are the headline props. Shots are the more stable of the two. They depend on ice time, role and how many attempts ${esc(team)} generates. Points swing more with linemates and finishing luck. The model projects each from ${esc(p.name)}'s usage and matchup, then flags where that number diverges from the sportsbook line.`;

  const stats = p.stats && p.stats.gamesPlayed
    ? `      <h2>${esc(p.name)}'s season at a glance</h2>
      <div class="stats-row">
${cardsHtml}
      </div>
      <p>These are ${esc(p.name)}'s current regular season totals. They form the base rate the model starts from before adjusting for tonight's specific matchup, opponent quality, rest and role.</p>`
    : "";

  const jsonld = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      { "@type": "Question", name: `How are ${p.name}'s prop projections made?`,
        acceptedAnswer: { "@type": "Answer", text: `ArakIce projects ${p.name}'s output from usage, role and matchup: how many chances ${team} generates or allows, the opponent's pace, rest and recent form. It then compares the projection to the posted prop line to find value.` } },
      { "@type": "Question", name: `Where can I see ${p.name}'s projection for tonight?`,
        acceptedAnswer: { "@type": "Answer", text: `Open the ArakIce app. When ${p.name} is on the slate, the live projection and the edge against the current line appear there, updated as lineups and odds move.` } },
      { "@type": "Question", name: `Are ${p.name} prop predictions guaranteed?`,
        acceptedAnswer: { "@type": "Answer", text: `No. Props are high-variance and no projection is guaranteed. The goal is to find value against the line over a large sample, not to win any single night.` } },
    ],
  };

  const body = `    <section class="hero">
      <p class="eyebrow">${esc(team)} · ${esc(posName)}</p>
      <h1>${esc(p.name)} Prop Predictions</h1>
      <p class="lede">Projections and betting context for ${esc(p.name)} of the ${esc(team)}. See how ArakIce models ${esc(p.name)}'s props, ${isGoalie ? "saves and totals" : "shots and points included"}, and where the numbers point against the sportsbook line.</p>
    </section>
    <p>If you follow ${esc(p.name)}, you already know the box score only tells part of the story. Prop betting rewards understanding the <em>process</em> behind the numbers: the ice time, the role, the matchup and the pace that decide how many chances a ${esc(posName)} actually gets. This page explains how ArakIce turns that context into a projection for ${esc(p.name)}, and how to use it without fooling yourself.</p>
${ctaBox(`See ${p.name}'s live projection tonight`, `When ${p.name} is playing, ArakIce shows the projection and the edge against the current prop line, updated through the day.`, "Open ArakIce")}
${stats}
      <h2>How we project ${esc(p.name)}'s props</h2>
      <p>${propsFocus}</p>
      <p>The projection is not a season average dressed up. It weighs the specific game: the opponent ${esc(team)} faces, whether either team is playing a second night in a row or sitting deep in a road trip, the goaltending on the other side, and the referee crew where it affects scoring. Those factors are weighed per matchup, so ${esc(p.name)}'s number on a rested home night against a weak defense looks very different from a tired night against an elite one.</p>
${rateBlock}
      <h2>Which ${esc(p.name)} props to watch</h2>
      <p>The best prop bets are the ones where the model and the market disagree most, not simply the ones with the biggest names attached. When ${esc(p.name)}'s projection clearly exceeds the posted line, that gap is the reason to bet the over; when it falls short, the under or a pass is the disciplined play. Treat the size of the gap as your guide to stake size, and remember that even a strong edge will miss plenty of individual nights.</p>
${ctaBox(`Track ${p.name} in the app`, `Follow ${p.name}'s projections game by game and get the edge against the line the moment it moves.`, "Open ArakIce")}
      <section class="related">
        <h2>Explore more</h2>
        <ul>
          <li><a href="${SITE}/nhl-player-props">All NHL player prop predictions</a></li>
          <li><a href="${SITE}/best-nhl-picks-today">Best NHL picks today</a></li>
          <li><a href="${SITE}/">Open the ArakIce app</a></li>
        </ul>
      </section>`;

  return layout({
    title: `${p.name} Prop Predictions & Projections | ArakIce`,
    desc: `${p.name} (${team}) prop predictions: ${isGoalie ? "save and totals" : "shots, points and more"} projections and betting context from ArakIce's NHL model.`,
    canonicalPath: `/props/${p.slug}`,
    jsonld,
    body,
  });
}

function propsHubPage(players) {
  // WHY THE LIST IS RENDERED HERE AND NOT BY seo-search.js
  // This hub used to ship an empty <ul> plus a JSON blob, and let the browser
  // build the rows. That left ZERO <a href="/props/..."> in the served HTML, so
  // every player page was an orphan reachable only from sitemap.xml — and a
  // sitemap-only URL with no internal link is the lowest-priority thing Google
  // crawls. (The client build also capped the rendered list at 300 rows, so
  // even after JS ran, most players had no link pointing at them at all.)
  //
  // The rows are now emitted here, as real anchors, sorted by name. seo-search.js
  // filters the rows that already exist instead of creating them, so the search
  // box behaves identically and the CSS is untouched.
  const sorted = [...players].sort((a, b) => a.name.localeCompare(b.name));
  const rows = sorted
    .map((p) => {
      // Lower-cased, diacritic-free haystack so the filter never has to
      // normalize at keystroke time.
      const hay = `${p.name} ${p.teamName || p.team} ${p.pos}`
        .toLowerCase()
        .normalize("NFD")
        .replace(/\p{Diacritic}/gu, "");
      return `        <li data-hay="${esc(hay)}"><a class="player-row" href="/props/${p.slug}"><span class="player-name">${esc(p.name)}</span><span class="player-meta">${esc([p.pos, p.team].filter(Boolean).join(" · "))}</span></a></li>`;
    })
    .join("\n");
  const jsonld = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "NHL Player Prop Predictions",
    description: "Search any NHL player for prop projections and betting context.",
    url: `${SITE}/nhl-player-props`,
  };
  const body = `    <section class="hero">
      <p class="eyebrow">Search ${players.length} NHL players</p>
      <h1>NHL Player Prop Predictions</h1>
      <p class="lede">Type any player's name to open their prop page. Shots, points and goaltender saves, each with the projection and the edge against the sportsbook line. Every active NHL player, one search away.</p>
    </section>
    <div class="search-wrap">
      <input id="player-search" type="search" placeholder="Search a player, for example Connor McDavid" autocomplete="off" aria-label="Search NHL players" />
      <div id="player-count">${players.length} players</div>
    </div>
    <ul id="player-list">
${rows}
    </ul>
    <script src="/seo-search.js" defer></script>
${ctaBox("See tonight's prop edges", "The app ranks tonight's player props by how far the projection beats the line. Open it to see the biggest edges live.", "Open ArakIce")}
      <h2>How ArakIce projects player props</h2>
      <p>A player prop is a bet on an individual's output rather than on who wins: shots on goal, points, goaltender saves. The edge comes from projecting that output more accurately than the sportsbook's line. ArakIce builds each projection from usage and role, the pace and quality of the matchup, rest and travel, and the goaltending involved, then compares it to the posted number. Where the two disagree, there is value; where they agree, there is not.</p>
      <p>Props are fertile ground for edges because sportsbooks price hundreds of them every night and cannot sharpen each one. Use the search above to find any player, read the reasoning on their page, and open the app for tonight's live projection.</p>`;
  return layout({
    title: "NHL Player Prop Predictions | Search Any Player | ArakIce",
    desc: "Search any NHL player for prop projections, shots and points and goaltender saves, with the edge against the line, from ArakIce's model.",
    canonicalPath: "/nhl-player-props",
    jsonld,
    body,
  });
}

// ── Statistiques de confrontation ────────────────────────────────────────────
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
function niceDate(iso) {
  const [y, m, d] = iso.split("-");
  return `${MONTHS[Number(m) - 1]} ${Number(d)}, ${y}`;
}

// La ligne de total la plus courante à la LNH. Sert de repère au graphique et
// de pivot au décompte « en dessous / au dessus ».
const COMMON_LINE = 6;

function h2hStats(games, a, b) {
  if (!games || !games.length) return null;
  const totals = games.map((g) => g.total);
  const n = games.length;
  const aWins = games.filter((g) => (g.home === a.abbr) === g.homeWin).length;
  const roadWins = games.filter((g) => !g.homeWin);
  return {
    n, games, aWins, bWins: n - aWins,
    avg: totals.reduce((x, y) => x + y, 0) / n,
    homeWins: games.filter((g) => g.homeWin).length,
    ot: games.filter((g) => g.ot).length,
    under: totals.filter((t) => t < COMMON_LINE).length,
    over: totals.filter((t) => t > COMMON_LINE).length,
    onLine: totals.filter((t) => t === COMMON_LINE).length,
    lo: Math.min(...totals), hi: Math.max(...totals),
    biggest: games.reduce((m, g) => (g.total > m.total ? g : m), games[0]),
    last: games[games.length - 1],
    firstYear: games[0].date.slice(0, 4),
    roadWin: roadWins[0] || null,
  };
}

// Figure : un point par rencontre sur l'axe des buts. Le SVG est écrit à la
// main plutôt que dessiné par une bibliothèque parce que ces pages n'exécutent
// aucun JS et n'ont le droit de charger aucune ressource externe (CSP).
// Une seule couleur : c'est une seule série, une deuxième teinte ne coderait rien.
function h2hFigure(st, a, b) {
  const X0 = 62, X1 = 676, BASE = 126, STEP = 19, R = 7;
  const span = Math.max(1, st.hi - st.lo);
  const x = (g) => X0 + ((g - st.lo) * (X1 - X0)) / span;
  const counts = new Map();
  for (const g of st.games) counts.set(g.total, (counts.get(g.total) || 0) + 1);
  let dots = "";
  for (const g of [...counts.keys()].sort((m, n) => m - n)) {
    for (let i = 0; i < counts.get(g); i++) {
      // L'anneau couleur surface évite que deux points empilés se confondent.
      dots += `<circle cx="${x(g).toFixed(1)}" cy="${(BASE - 10 - i * STEP).toFixed(1)}" r="${R}" fill="#1A8AFF" stroke="#131A12" stroke-width="2"/>`;
    }
  }
  let ticks = "";
  for (let g = st.lo; g <= st.hi; g++) {
    ticks += `<line x1="${x(g).toFixed(1)}" y1="${BASE}" x2="${x(g).toFixed(1)}" y2="${BASE + 6}" stroke="#283323" stroke-width="1"/>`
           + `<text x="${x(g).toFixed(1)}" y="${BASE + 24}" fill="#92A08A" font-size="13" text-anchor="middle" font-family="Inter, system-ui, sans-serif">${g}</text>`;
  }
  const refx = x(COMMON_LINE + 0.5).toFixed(1);
  const alt = `Total goals in each of the ${st.n} meetings between ${a.name} and ${b.name} since ${st.firstYear}. `
            + `${st.under} finished below ${COMMON_LINE + 1} goals, ${st.over} above, ${st.onLine} on ${COMMON_LINE}.`;
  return `      <figure class="h2h-fig">
        <svg viewBox="0 0 720 186" width="100%" role="img" xmlns="http://www.w3.org/2000/svg" aria-label="${esc(alt)}">
          <rect x="0" y="0" width="720" height="186" fill="#131A12" rx="10"/>
          <line x1="${refx}" y1="24" x2="${refx}" y2="${BASE}" stroke="#3B4A36" stroke-width="2" stroke-dasharray="3 4"/>
          <text x="${(Number(refx) + 10).toFixed(1)}" y="36" fill="#92A08A" font-size="12.5" font-family="Inter, system-ui, sans-serif">common line ${COMMON_LINE}.5</text>
          <line x1="${X0 - 26}" y1="${BASE}" x2="${X1 + 26}" y2="${BASE}" stroke="#283323" stroke-width="1"/>
          ${ticks}${dots}
          <text x="360" y="${BASE + 52}" fill="#92A08A" font-size="13" text-anchor="middle" font-family="Inter, system-ui, sans-serif">total goals, one dot per meeting</text>
        </svg>
        <figcaption>${st.n} meetings since ${st.firstYear}. ${st.under} finished at ${COMMON_LINE - 1} goals or fewer, ${st.over} at ${COMMON_LINE + 1} or more, and ${st.onLine === 0 ? `none landed on ${COMMON_LINE}` : `${st.onLine} landed on ${COMMON_LINE}`}.</figcaption>
      </figure>`;
}

function matchupPage(a, b, games) {
  const sameDiv = a.division && a.division === b.division;
  const sameConf = a.conference && a.conference === b.conference;
  const rel = sameDiv ? `a ${esc(a.division)} Division matchup`
            : sameConf ? `a ${esc(a.conference)} Conference matchup`
            : "a matchup between the conferences";
  const st = h2hStats(games, a, b);

  // Décompte plutôt que pourcentage sous le plancher.
  const pct = (k) => (st.n >= H2H_MIN_PCT ? ` (${Math.round((100 * k) / st.n)}%)` : "");
  const city = (t) => t.common || t.name;
  const byAbbr = { [a.abbr]: a, [b.abbr]: b };
  const winTxt = (g) => {
    const w = g.homeWin ? g.home : g.away, l = g.homeWin ? g.away : g.home;
    const ws = g.homeWin ? g.hs : g.as, ls = g.homeWin ? g.as : g.hs;
    return `${esc(city(byAbbr[w]))} ${ws}, ${esc(city(byAbbr[l]))} ${ls}`;
  };

  const jsonld = st ? {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      { "@type": "Question", name: `What is the record between ${a.name} and ${b.name}?`,
        acceptedAnswer: { "@type": "Answer", text: `Over their last ${st.n} meetings, going back to ${st.firstYear}, ${st.aWins > st.bWins ? a.name : b.name} lead ${Math.max(st.aWins, st.bWins)} wins to ${Math.min(st.aWins, st.bWins)}. The home team won ${st.homeWins} of the ${st.n}.` } },
      { "@type": "Question", name: `How many goals do ${a.name} and ${b.name} games usually produce?`,
        acceptedAnswer: { "@type": "Answer", text: `Their last ${st.n} meetings averaged ${st.avg.toFixed(2)} goals. ${st.under} finished at ${COMMON_LINE - 1} goals or fewer and ${st.over} at ${COMMON_LINE + 1} or more. The highest was ${st.biggest.total} goals on ${niceDate(st.biggest.date)}.` } },
      { "@type": "Question", name: `When did ${a.name} and ${b.name} last play?`,
        acceptedAnswer: { "@type": "Answer", text: `${niceDate(st.last.date)}. ${winTxt(st.last).replace(/&#39;/g, "'")}.` } },
    ],
  } : null;

  const table = [...st.games].reverse().map((g) =>
    `        <tr><td>${niceDate(g.date)}</td><td>${winTxt(g)}${g.ot ? " (OT)" : ""}</td><td>${esc(city(byAbbr[g.home]))}</td><td class="num">${g.total}</td></tr>`
  ).join("\n");

  const leader = st.aWins > st.bWins ? a : b;

  const body = `    <section class="hero">
      <p class="eyebrow">${rel}</p>
      <h1>${esc(a.name)} vs ${esc(b.name)} Head to Head</h1>
      <div class="matchup-teams">
        <div class="team"><img src="${nhlLogo(a.abbr)}" alt="${esc(a.name)} logo" width="72" height="72" /><div class="abbr">${esc(a.abbr)}</div></div>
        <div class="vs">vs</div>
        <div class="team"><img src="${nhlLogo(b.abbr)}" alt="${esc(b.name)} logo" width="72" height="72" /><div class="abbr">${esc(b.abbr)}</div></div>
      </div>
${h2hFigure(st, a, b)}
    </section>
    <p>Here is what the record between these two clubs looks like, and how ArakIce reads their next meeting.</p>
      <h2>The last ${st.n} meetings</h2>
      <div class="stats-row">
        <div class="stat"><div class="value">${st.n}</div><div class="label">meetings since ${st.firstYear}</div></div>
        <div class="stat"><div class="value">${st.avg.toFixed(2)}</div><div class="label">goals per game</div></div>
        <div class="stat"><div class="value">${st.homeWins} of ${st.n}</div><div class="label">won by the home team</div></div>
        <div class="stat"><div class="value">${st.over} of ${st.n}</div><div class="label">over ${COMMON_LINE}.5</div></div>
      </div>
      <p>${esc(city(leader))} lead the recent series ${Math.max(st.aWins, st.bWins)} wins to ${Math.min(st.aWins, st.bWins)}. ${st.n >= H2H_MIN_PCT ? `Where the game is played has mattered more than who is better. ` : ``}The home team won ${st.homeWins} of the ${st.n}${pct(st.homeWins)}.${st.roadWin ? ` The only road win by either club was ${winTxt(st.roadWin)} on ${niceDate(st.roadWin.date)}.` : ""}</p>
      <p>${st.n >= H2H_MIN_PCT && st.onLine === 0 ? `Totals have split rather than clustered. ` : ``}${st.under} of the ${st.n} finished at ${COMMON_LINE - 1} goals or fewer. ${st.over} finished at ${COMMON_LINE + 1} or more. ${st.onLine === 0 ? `The number never landed on ${COMMON_LINE}.` : `${st.onLine} landed on ${COMMON_LINE}.`} The busiest was ${niceDate(st.biggest.date)}, ${winTxt(st.biggest)}, ${st.biggest.total} goals between them. ${st.ot} of the ${st.n} needed overtime. Most recent meeting: ${niceDate(st.last.date)}, ${winTxt(st.last)}.</p>
      <div class="h2h-wrap">
        <table class="h2h">
          <caption>Every ${esc(a.name)} and ${esc(b.name)} meeting since ${st.firstYear}</caption>
          <thead><tr><th>Date</th><th>Result</th><th>Host</th><th class="num">Goals</th></tr></thead>
          <tbody>
${table}
          </tbody>
        </table>
      </div>
      <p class="src">Compiled from ArakIce's own game database, covering every meeting between these clubs since ${st.firstYear}. Percentages appear only for matchups with at least ${H2H_MIN_PCT} meetings.</p>
${ctaBox("See the projection for this game", `When ${esc(a.name)} and ${esc(b.name)} are on the slate, ArakIce projects a win probability and a total for the game.`, "Open ArakIce")}
      <h2>How the model reads ${esc(a.name)} vs ${esc(b.name)}</h2>
      <p>The projection starts with expected goals, meaning the quality of chances each club creates and gives up. That holds up better than goals scored, which swing on shooting luck. From there it adjusts for what is true only of this game: who is confirmed in net, whether either club is playing a second night in a row or sitting deep in a road trip, the travel and the time zones, and the referee crew where it moves the total.</p>
      <h2>What tends to move ${esc(a.name)} vs ${esc(b.name)}</h2>
      <p>${sameDiv
        ? `Division rivals meet several times a year and know each other well. Those games tend to be tighter and more defensive, which is part of why the totals above sit where they do.`
        : sameConf
        ? `Conference games carry playoff seeding weight. The intensity tightens the checking and pulls event rates down compared with a casual date against the other conference.`
        : `These clubs meet rarely, so unfamiliarity, travel and scheduling quirks carry more weight than usual. Those are exactly the situations the model is built to read.`}
        Beyond that, the biggest movers are goaltending confirmations, home ice, and whether either side is playing a second night in a row or finishing a long trip.</p>
      <section class="related">
        <h2>Explore more</h2>
        <ul>
          <li><a href="${SITE}/nhl-matchups">All NHL matchup pages</a></li>
          <li><a href="${SITE}/nhl-predictions-today">NHL predictions today</a></li>
          <li><a href="${SITE}/">Open the ArakIce app</a></li>
        </ul>
      </section>`;

  return layout({
    title: `${a.name} vs ${b.name} Head to Head Record and Totals | ArakIce`,
    desc: `${a.name} against ${b.name}: the last ${st.n} meetings, ${st.avg.toFixed(2)} goals a game, ${st.homeWins} of ${st.n} won by the home team, with every result listed.`,
    canonicalPath: `/matchup/${a.slug}-vs-${b.slug}`,
    jsonld,
    body,
    // Cette page ne parle plus de moneyline, de cotes ni de mise : elle ne sert
    // que des résultats de matchs. L'avertissement de jeu responsable reste sur
    // toutes les pages qui, elles, parlent de pari.
    disclaimer: false,
  });
}

function matchupHubPage(pairs) {
  const items = pairs
    .map((pr) => `          <li><a href="${SITE}/matchup/${pr.a.slug}-vs-${pr.b.slug}">${esc(pr.a.name)} vs ${esc(pr.b.name)}</a></li>`)
    .join("\n");
  const jsonld = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "NHL Head to Head Records",
    url: `${SITE}/nhl-matchups`,
  };
  const body = `    <section class="hero">
      <p class="eyebrow">${pairs.length} upcoming matchups</p>
      <h1>NHL Head to Head Records</h1>
      <p class="lede">Every upcoming NHL matchup, with the record between the two clubs over the last five seasons: how the meetings have gone, how many goals they produce, and how much home ice has mattered.</p>
    </section>
${ctaBox("See tonight's full slate", "ArakIce projects a win probability and a total for every game on tonight's schedule.", "Open ArakIce")}
      <section class="related">
        <h2>Upcoming matchups</h2>
        <ul>
${items}
        </ul>
      </section>`;
  return layout({
    title: "NHL Head to Head Records | Every Upcoming Game | ArakIce",
    desc: "Head to head records for every upcoming NHL game: recent meetings, goals per game and how often the home team wins.",
    canonicalPath: "/nhl-matchups",
    jsonld,
    body,
    disclaimer: false,   // ce hub n'ouvre que sur des pages de statistiques
  });
}

// ── Sitemap ──────────────────────────────────────────────────────────────────
async function writeSitemap(dynamicLocs) {
  // Google ignores <changefreq> and <priority> entirely, but it does read
  // <lastmod> — and only trusts it if it is accurate. A generator run is the
  // only thing that rewrites these pages, so the run date is the honest value.
  const lastmod = new Date().toISOString().slice(0, 10);
  const rows = [];
  for (const p of STATIC_PAGES) {
    rows.push(`  <url>\n    <loc>${SITE}${p.loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>${p.changefreq}</changefreq>\n    <priority>${p.priority}</priority>\n  </url>`);
  }
  for (const loc of dynamicLocs) {
    rows.push(`  <url>\n    <loc>${SITE}${loc}</loc>\n    <lastmod>${lastmod}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.6</priority>\n  </url>`);
  }
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${rows.join("\n")}\n</urlset>\n`;
  await fs.writeFile(path.join(OUT_DIR, "sitemap.xml"), xml, "utf-8");
}

// ── Data fetchers ─────────────────────────────────────────────────────────────
async function fetchTeams() {
  const data = await getJSON(`${API}/standings/now`);
  const teams = {};
  for (const t of data.standings || []) {
    const abbr = t.teamAbbrev?.default;
    if (!abbr) continue;
    const common = t.teamCommonName?.default || t.teamName?.default || abbr;
    const full = t.teamName?.default || `${t.placeName?.default || ""} ${common}`.trim();
    teams[abbr] = {
      abbr,
      name: full,
      common,
      slug: slugify(common),
      division: t.divisionName || "",
      conference: t.conferenceName || "",
    };
  }
  return teams;
}

async function fetchMatchupPairs(teams) {
  const seen = new Set();
  const pairs = [];
  let date = "now";
  for (let w = 0; w < HORIZON_WEEKS; w++) {
    let data;
    try { data = await getJSON(`${API}/schedule/${date}`); } catch { break; }
    for (const day of data.gameWeek || []) {
      for (const g of day.games || []) {
        const aAbbr = g.awayTeam?.abbrev, bAbbr = g.homeTeam?.abbrev;
        if (!aAbbr || !bAbbr) continue;
        const [x, y] = [aAbbr, bAbbr].sort();
        if (seen.has(x + y)) continue;
        seen.add(x + y);
        const a = teams[x], b = teams[y];
        if (a && b) pairs.push({ a, b });
      }
    }
    if (!data.nextStartDate) break;
    date = data.nextStartDate;
  }
  return pairs;
}

async function fetchPlayers(teams) {
  const abbrs = Object.keys(teams);
  const rosters = await pMap(abbrs, async (abbr) => {
    try {
      const r = await getJSON(`${API}/roster/${abbr}/current`);
      const list = [...(r.forwards || []), ...(r.defensemen || []), ...(r.goalies || [])];
      return list.map((pl) => ({
        id: pl.id,
        name: `${pl.firstName?.default || ""} ${pl.lastName?.default || ""}`.trim(),
        pos: pl.positionCode || "",
        team: abbr,
        teamName: teams[abbr].name,
      }));
    } catch { return []; }
  });
  const players = rosters.flat().filter((p) => p.id && p.name);

  // Enrich with season stats (gates thin pages) — one landing call per player.
  await pMap(players, async (p) => {
    try {
      const l = await getJSON(`${API}/player/${p.id}/landing`);
      const sub = l.featuredStats?.regularSeason?.subSeason || {};
      p.stats = sub;
    } catch { p.stats = {}; }
  });

  // Slug + de-dup. Le filtrage par liste blanche est fait dans main(), pour que
  // le mode --sample (qui ne passe jamais ici) obéisse à la même règle.
  const usedSlugs = new Set();
  const out = [];
  for (const p of players) {
    const gp = Number(p.stats?.gamesPlayed || 0);
    if (gp < MIN_GP) continue;
    let slug = slugify(p.name);
    if (usedSlugs.has(slug)) slug = `${slug}-${p.id}`;
    usedSlugs.add(slug);
    p.slug = slug;
    out.push(p);
  }
  return out;
}

// ── Fixtures for --sample (offline) ───────────────────────────────────────────
function sampleData() {
  const teams = {
    EDM: { abbr: "EDM", name: "Edmonton Oilers", common: "Oilers", slug: "oilers", division: "Pacific", conference: "Western" },
    CGY: { abbr: "CGY", name: "Calgary Flames", common: "Flames", slug: "flames", division: "Pacific", conference: "Western" },
    TOR: { abbr: "TOR", name: "Toronto Maple Leafs", common: "Maple Leafs", slug: "maple-leafs", division: "Atlantic", conference: "Eastern" },
  };
  // ⚠️ Chiffres INVENTÉS : ce sont des fixtures hors ligne, pas des statistiques.
  // Les slugs, eux, doivent appartenir à props-allowlist.json, sinon --sample
  // n'écrit plus aucune page joueur et ne teste donc plus playerPage().
  // Un patineur, un ailier et un gardien, pour couvrir les deux branches.
  const players = [
    { id: 8479318, name: "Auston Matthews", pos: "C", team: "TOR", teamName: "Toronto Maple Leafs", slug: "auston-matthews", stats: { gamesPlayed: 70, goals: 40, assists: 30, points: 70, shots: 250 } },
    { id: 8478420, name: "Mikko Rantanen", pos: "R", team: "DAL", teamName: "Dallas Stars", slug: "mikko-rantanen", stats: { gamesPlayed: 70, goals: 30, assists: 50, points: 80, shots: 220 } },
    { id: 8481691, name: "Yaroslav Askarov", pos: "G", team: "SJS", teamName: "San Jose Sharks", slug: "yaroslav-askarov", stats: { gamesPlayed: 40, wins: 18, goalsAgainstAvg: 2.80, savePctg: 0.905, shutouts: 2 } },
  ];
  const pairs = [{ a: teams.CGY, b: teams.EDM }];
  return { teams, players, pairs };
}

// ── Main ─────────────────────────────────────────────────────────────────────
async function main() {
  console.log(`ArakIce SEO generator — ${SAMPLE ? "SAMPLE (offline)" : "LIVE (NHL API)"} → ${OUT_DIR}`);
  let teams, players, pairs;

  const allow = await loadPropsAllowlist();

  if (SAMPLE) {
    ({ teams, players, pairs } = sampleData());
  } else {
    console.log("Fetching teams (standings)…");
    teams = await fetchTeams();
    console.log(`  ${Object.keys(teams).length} teams`);
    console.log("Fetching schedule (matchup pairs)…");
    pairs = await fetchMatchupPairs(teams);
    console.log(`  ${pairs.length} upcoming pairs`);
    console.log("Fetching rosters + player stats…");
    players = await fetchPlayers(teams);
    console.log(`  ${players.length} players before the allowlist`);
  }

  // Un seul endroit décide quelles pages joueur existent, mode --sample compris.
  const beforeAllow = players.length;
  players = players.filter((p) => allow.has(p.slug));
  const missing = [...allow].filter((sl) => !players.some((p) => p.slug === sl));
  console.log(`  ${players.length} player pages after the allowlist (${beforeAllow} candidates, allowlist of ${allow.size})`);
  if (missing.length) {
    // Slug de la liste sans joueur correspondant : échangé, retraité, renommé.
    // On le signale, on n'invente pas la page.
    console.warn(`  ⚠️  ${missing.length} allowlisted slug(s) with no matching player: ${missing.join(", ")}`);
  }

  const dynamicLocs = [];

  // Player pages + hub
  for (const p of players) {
    await writePage(`props/${p.slug}.html`, playerPage(p));
    dynamicLocs.push(`/props/${p.slug}`);
  }
  await writePage("nhl-player-props.html", propsHubPage(players));
  dynamicLocs.push("/nhl-player-props");

  // Matchup pages + hub
  console.log("Loading head to head history…");
  const h2h = await loadH2H();
  console.log(`  ${h2h.size} team pairs with recent meetings`);

  let noHistory = 0;
  const written = [];   // le hub ne doit lister que les pages réellement écrites
  for (const pr of pairs) {
    const games = h2h.get([pr.a.abbr, pr.b.abbr].sort().join("|")) || [];
    if (!games.length) { noHistory++; continue; }   // pas d'invention : pas de page
    await writePage(`matchup/${pr.a.slug}-vs-${pr.b.slug}.html`, matchupPage(pr.a, pr.b, games));
    dynamicLocs.push(`/matchup/${pr.a.slug}-vs-${pr.b.slug}`);
    written.push(pr);
  }
  await writePage("nhl-matchups.html", matchupHubPage(written));
  dynamicLocs.push("/nhl-matchups");

  await writeSitemap(dynamicLocs);

  if (noHistory) console.log(`  ⚠️  ${noHistory} pair(s) skipped: no meeting in the last five seasons.`);
  console.log(`Done. Wrote ${players.length} player pages, ${pairs.length - noHistory} matchup pages, 2 hubs, sitemap.xml.`);
}

// `main()` ne s'exécute que si ce fichier est lancé directement. Importé, il
// n'expose que ses fabriques de pages : c'est ce qui permet de régénérer un
// sous-ensemble de pages hors ligne (ou de tester une page) sans déclencher une
// campagne complète d'appels à l'API NHL.
const RUN_DIRECTLY = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (RUN_DIRECTLY) {
  main().catch((e) => { console.error("Generator failed:", e); process.exit(1); });
}

export { layout, matchupPage, playerPage, propsHubPage, matchupHubPage, loadH2H, h2hStats, writeSitemap };
