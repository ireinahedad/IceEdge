/**
 * useChatSocket — real-time chat via Socket.io
 *
 * Usage:
 *   const { messages, onlineCount, connected, initMessages, appendOptimistic, confirmMessage } =
 *     useChatSocket(roomId);
 *
 * Flow:
 *   1. On mount, caller fetches HTTP history and calls initMessages(msgs)
 *   2. Socket emits 'new_message' → deduped and appended automatically
 *   3. For own sends: appendOptimistic(msg) immediately, then confirmMessage(tempId, serverMsg)
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import { io as socketIO, Socket } from 'socket.io-client';
import type { ChatMessage } from '../types/user';
import { tokenStore } from '../services/tokenStore';
import { env } from '../env';

const SOCKET_URL = env.socketUrl;

export function useChatSocket(roomId: string | null) {
  const socketRef = useRef<Socket | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [onlineCount, setOnlineCount] = useState(0);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!roomId) return;

    const socket = socketIO(SOCKET_URL, {
      transports: ['websocket', 'polling'],
      path: '/socket.io',
      // Callback form, not a literal: reading the token is async since R3.6.
      // Socket.io calls this before each (re)connection, so a token refreshed
      // in the meantime is picked up instead of the one captured at mount.
      auth: (cb: (data: object) => void) => {
        tokenStore.getAccess().then((token) => cb({ token: token ?? '' }));
      },
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConnected(true);
      socket.emit('join_room', roomId);
    });

    socket.on('disconnect', () => setConnected(false));

    socket.on('new_message', (msg: ChatMessage) => {
      setMessages((prev) => {
        // Ignore if already present (own optimistic or duplicate)
        if (prev.some((m) => m.id === msg.id)) return prev;
        return [...prev, msg];
      });
    });

    socket.on('message_deleted', ({ messageId }: { messageId: string }) => {
      setMessages((prev) => prev.filter((m) => m.id !== messageId));
    });

    socket.on('room_users', (count: number) => setOnlineCount(count));

    return () => {
      socket.emit('leave_room', roomId);
      socket.disconnect();
      socketRef.current = null;
      setConnected(false);
    };
  }, [roomId]);

  /** Seed the initial HTTP history */
  const initMessages = useCallback((msgs: ChatMessage[]) => {
    setMessages(msgs);
  }, []);

  /** Optimistically add own message before the server confirms */
  const appendOptimistic = useCallback((msg: ChatMessage) => {
    setMessages((prev) => [...prev, msg]);
  }, []);

  /** Replace the optimistic message with the confirmed server version.
   *  Also removes any socket-delivered copy that may have arrived first
   *  (race: socket fires before the HTTP await resolves → double message). */
  const confirmMessage = useCallback((tempId: string, confirmed: ChatMessage) => {
    setMessages((prev) =>
      prev
        .filter((m) => m.id !== confirmed.id && m.id !== tempId).concat(confirmed)
    );
  }, []);

  /** Remove a message locally (optimistic delete before/without the socket event). */
  const removeMessage = useCallback((messageId: string) => {
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
  }, []);

  return { messages, onlineCount, connected, initMessages, appendOptimistic, confirmMessage, removeMessage };
}
