/**
 * i18n — lightweight English/French translation layer.
 *
 * Usage:
 *   const { t, lang, setLang } = useI18n();
 *   <span>{t("nav.home")}</span>
 *
 * The language is persisted in localStorage and applied app-wide.
 * Unknown keys fall back to English, then to the key itself.
 */

import { createContext, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";

export type Lang = "en" | "fr";
const STORAGE_KEY = "iceedge_lang";

/**
 * La langue du navigateur, quand l'utilisateur n'a encore rien choisi.
 *
 * Jusqu'au 2026-09-08 le repli était `"en"` en dur : un iPhone configuré en
 * français démarrait en anglais, et il fallait trouver le sélecteur pour
 * revenir dans sa langue. Le choix explicite (localStorage) reste prioritaire —
 * quelqu'un qui a mis l'anglais sur un téléphone français le garde.
 *
 * `navigator.languages` avant `navigator.language` : la liste reflète l'ordre
 * de préférence réel, et sur iOS un appareil réglé en français avec l'anglais
 * en second y apparaît dans le bon ordre. Tout ce qui commence par `fr`
 * (`fr-CA`, `fr-FR`…) compte ; le reste tombe en anglais, qui est la langue
 * complète du dictionnaire.
 */
function detectLang(): Lang {
  try {
    const list = navigator.languages?.length ? navigator.languages : [navigator.language];
    for (const tag of list) {
      if (typeof tag === "string" && tag.toLowerCase().startsWith("fr")) return "fr";
    }
  } catch { /* pas de navigator (rendu hors navigateur) */ }
  return "en";
}

const DICT: Record<string, { en: string; fr: string }> = {
  // ── Navigation ──
  "nav.home":    { en: "Home",    fr: "Accueil" },
  "nav.stats":   { en: "Stats",   fr: "Stats" },
  "nav.slip":    { en: "Slip",    fr: "Coupon" },
  "nav.league":  { en: "League",  fr: "Ligue" },
  "nav.profile": { en: "Profile", fr: "Profil" },

  // ── Common ──
  "common.save":    { en: "Save Changes", fr: "Enregistrer" },
  "common.saving":  { en: "Saving…",      fr: "Enregistrement…" },
  "common.saved":   { en: "Saved!",       fr: "Enregistré !" },
  "common.cancel":  { en: "Cancel",       fr: "Annuler" },
  "common.close":   { en: "Close",        fr: "Fermer" },
  "common.back":    { en: "Back",         fr: "Retour" },
  "common.loading": { en: "Loading…",     fr: "Chargement…" },
  "common.members": { en: "members",      fr: "membres" },
  "common.online":  { en: "online",       fr: "en ligne" },
  "common.retry":   { en: "Try again",    fr: "Réessayer" },
  "chat.sendFailed": { en: "Message not sent \u2014 your text is back in the box.", fr: "Message non envoyé \u2014 ton texte est revenu dans la zone de saisie." },
  // Les trois issues d'échec de la connexion Google. Le serveur les met dans
  // `?error=` ; jusqu'au 2026-09-08 l'écran de connexion les ignorait purement
  // et simplement, donc un refus Google ramenait sur un formulaire muet.
  "login.googleDenied":     { en: "Google sign-in was cancelled.", fr: "La connexion Google a été annulée." },
  "login.googleFailed":     { en: "Google sign-in failed. Try again, or use your e-mail and password.", fr: "La connexion Google a échoué. Réessaie, ou utilise ton e-mail et ton mot de passe." },
  "login.googleUnverified": { en: "This Google account\u2019s e-mail address is not verified. Verify it with Google, or sign in with your e-mail and password.", fr: "L\u2019adresse de ce compte Google n\u2019est pas vérifiée. Vérifie-la chez Google, ou connecte-toi avec ton e-mail et ton mot de passe." },
  // Les trois clés de l'état d'erreur partagé (`ErrorState`). Le titre reste
  // vague à dessein : l'utilisateur n'a rien à faire d'un code HTTP, et le
  // détail technique part déjà dans la console.
  "common.loadFailed":     { en: "Couldn\u2019t load this.", fr: "Impossible de charger ça." },
  "common.loadFailedHint": { en: "Check your connection, then try again.", fr: "Vérifie ta connexion, puis réessaie." },
  "common.timedOut":       { en: "The connection is taking too long.", fr: "La connexion prend trop de temps." },

  // ── Profile ──
  "profile.title":        { en: "Profile",       fr: "Profil" },
  "profile.overview":     { en: "Overview",      fr: "Aperçu" },
  "profile.settings":     { en: "Settings",      fr: "Paramètres" },
  "profile.signout":      { en: "Sign Out",      fr: "Déconnexion" },
  "profile.security":     { en: "Security",      fr: "Sécurité" },
  "profile.signoutAll":   { en: "Log out of all devices", fr: "Se déconnecter de tous les appareils" },
  "profile.signoutAllDesc": { en: "Ends your session everywhere — you'll need to sign in again on each device.", fr: "Met fin à votre session partout — vous devrez vous reconnecter sur chaque appareil." },
  "profile.signoutAllConfirm": { en: "Log out of all devices?", fr: "Se déconnecter de tous les appareils ?" },
  "profile.photo":        { en: "Profile Photo", fr: "Photo de profil" },
  "profile.changePhoto":  { en: "Change photo",  fr: "Changer la photo" },
  "profile.uploading":    { en: "Uploading…",    fr: "Envoi…" },
  "profile.photoHint":    { en: "JPG, PNG or WebP · large images are compressed automatically", fr: "JPG, PNG ou WebP · les grandes images sont compressées automatiquement" },
  "profile.iceAvatar":    { en: "Or pick an ice avatar", fr: "Ou choisis un avatar glacé" },
  "profile.choosePhoto":  { en: "Profile photo",     fr: "Photo de profil" },
  "profile.chooseEmoji":  { en: "Choose an emoji",   fr: "Choisir un emoji" },
  "profile.chooseFlag":   { en: "Choose a flag",     fr: "Choisir un drapeau" },
  "profile.flagHint":     { en: "Shown next to your name in the podium and chat", fr: "Affiché à côté de ton nom dans le podium et le chat" },
  "profile.info":         { en: "Profile Info",  fr: "Infos du profil" },
  "profile.username":     { en: "Username",      fr: "Nom d'utilisateur" },
  "profile.usernameHint": { en: "3–20 characters · lowercase letters, numbers, underscores · must be unique", fr: "3–20 caractères · minuscules, chiffres, tirets bas · doit être unique" },
  "profile.displayName":  { en: "Display Name",  fr: "Nom affiché" },
  "profile.bio":          { en: "Bio",           fr: "Bio" },
  "profile.favTeam":      { en: "Favorite Team", fr: "Équipe favorite" },
  "profile.public":       { en: "Public Profile", fr: "Profil public" },
  // Formulé à la négative : la visibilité est le défaut, se retirer est le geste
  // délibéré. Les anciennes clés showSlips/showSlipsHint sont retirées avec le
  // toggle opt-in qu'elles servaient.
  "profile.privacy":      { en: "Privacy", fr: "Confidentialité" },
  "profile.hideSlips":    { en: "Hide my slips from other players", fr: "Masquer mes coupons aux autres joueurs" },
  "profile.hideSlipsHint":{ en: "Pro members can browse your settled slips. Turning this on hides all of them — your leaderboard rank is unaffected.", fr: "Les membres Pro peuvent consulter tes coupons réglés. Activer ceci les masque tous — ton rang au classement n'est pas touché." },
  "profile.language":     { en: "Language",      fr: "Langue" },
  "profile.bookmaker":    { en: "Sportsbook",    fr: "Site de paris" },
  "profile.bookmakerHint":{ en: "Which site the “Place bet” buttons open", fr: "Le site que les boutons « Parier » ouvrent" },
  "profile.dark":         { en: "Dark",          fr: "Sombre" },
  "profile.light":        { en: "Light",         fr: "Clair" },
  "profile.aiSettings":   { en: "AI Settings",   fr: "Paramètres IA" },
  "profile.parlayRecord": { en: "Parlay Record", fr: "Bilan des combinés" },
  "profile.parlayWins":   { en: "Parlay Wins",   fr: "Combinés gagnés" },
  "profile.parlayLosses": { en: "Parlay Losses", fr: "Combinés perdus" },
  "profile.parlayRate":   { en: "Parlay Rate",   fr: "Taux de combinés" },
  "profile.memberSince":  { en: "ArakIce member since {date}", fr: "Membre ArakIce depuis {date}" },
  "profile.aiSettingsDesc":{ en: "Enter your OpenAI API key to use the Ask LLM feature. Your key is stored securely and used only for your requests.", fr: "Entre ta clé API OpenAI pour utiliser la fonction Ask LLM. Ta clé est stockée en toute sécurité et utilisée uniquement pour tes requêtes." },
  "profile.getKey":       { en: "Get a key →",   fr: "Obtenir une clé →" },
  "profile.openaiKey":    { en: "OpenAI API Key", fr: "Clé API OpenAI" },
  "profile.show":         { en: "Show",          fr: "Afficher" },
  "profile.hide":         { en: "Hide",          fr: "Masquer" },
  "profile.keyStored":     { en: "A key is saved on your account", fr: "Une clé est enregistrée sur ton compte" },
  "profile.replaceKey":    { en: "Replace",                       fr: "Remplacer" },
  "profile.keyNotShown":   { en: "For your security it is never displayed again — replace it or remove it.", fr: "Par sécurité elle n'est jamais réaffichée — remplace-la ou retire-la." },
  "profile.keyPendingRemoval": { en: "The key will be removed when you save.", fr: "La clé sera retirée à l'enregistrement." },
  "profile.removeKey":    { en: "Remove key",    fr: "Supprimer la clé" },
  "profile.calibration":  { en: "Calibration",   fr: "Calibrage" },
  "profile.hitRateTrend": { en: "Hit Rate Trend", fr: "Tendance du taux de réussite" },
  "profile.perfByMarket": { en: "Performance by Market", fr: "Performance par marché" },
  "profile.betHistory":   { en: "Bet History",    fr: "Historique des paris" },
  "profile.filterAll":    { en: "All",            fr: "Tous" },
  "profile.filterWins":   { en: "Wins",           fr: "Gagnés" },
  "profile.filterLosses": { en: "Losses",         fr: "Perdus" },
  "profile.filterLive":   { en: "Live",           fr: "En direct" },
  "profile.calWell":      { en: "Well Calibrated", fr: "Bien calibré" },
  "profile.calDecent":    { en: "Decent",         fr: "Correct" },
  "profile.calNeedsWork": { en: "Needs Work",     fr: "À améliorer" },
  "profile.modelCalibration": { en: "Model Calibration", fr: "Calibrage du modèle" },
  "profile.calDescHigh":  { en: "Your picks align closely with model probabilities — a sign of sharp judgment.", fr: "Tes choix collent de près aux probabilités du modèle — signe d'un bon jugement." },
  "profile.calDescMid":   { en: "Your hit rate roughly matches model predictions with some variance.", fr: "Ton taux de réussite correspond globalement aux prédictions du modèle, avec quelques écarts." },
  "profile.calDescLow":   { en: "Your selections often diverge from model predictions. Try sticking to higher-confidence picks.", fr: "Tes sélections s'écartent souvent des prédictions du modèle. Essaie de privilégier les choix à forte confiance." },

  // ── League / leaderboard ──
  "league.rankings":   { en: "Rankings",             fr: "Classement" },
  "league.chat":       { en: "Chat",                 fr: "Chat" },
  "league.podium":     { en: "This Season's Podium", fr: "Podium de la saison" },
  "league.podiumTap":  { en: "Tap a player to view their profile", fr: "Touche un joueur pour voir son profil" },
  "league.searchPlayer": { en: "Search a player…",   fr: "Rechercher un joueur…" },
  "league.noPlayerFound": { en: "No player found", fr: "Aucun joueur trouvé" },
  "league.score":      { en: "Score",                fr: "Score" },
  "league.hitRate":    { en: "Hit Rate",             fr: "Réussite" },
  "league.volume":     { en: "Volume",               fr: "Volume" },
  "league.player":     { en: "Player",               fr: "Joueur" },
  "league.recentSlips":{ en: "Recent slips",         fr: "Coupons récents" },
  "league.slipsPrivate": { en: "🔒 This player keeps their slips private", fr: "🔒 Ce joueur garde ses coupons privés" },
  "league.noSlips":    { en: "No slips yet",         fr: "Aucun coupon pour l'instant" },
  "league.you":        { en: "you",                  fr: "toi" },
  "league.bets":       { en: "Bets",                 fr: "Paris" },
  "chat.noRoomsYet":   { en: "No rooms yet",         fr: "Aucun salon" },
  "chat.noRoomsHint":  { en: "Join a public room from Discover, enter a join code above, or create your own.", fr: "Rejoins un salon public depuis Découvrir, entre un code d'accès ci-dessus, ou crée le tien." },
  "chat.nothingDiscover": { en: "Nothing to discover", fr: "Rien à découvrir" },
  "chat.noPublicRooms":{ en: "No public rooms to join right now.", fr: "Aucun salon public à rejoindre pour le moment." },

  // ── Chat ──
  "chat.myRooms":      { en: "My Rooms",             fr: "Mes salons" },
  "chat.discover":     { en: "Discover",             fr: "Découvrir" },
  "chat.sectionPublic":  { en: "Public",             fr: "Public" },
  "chat.sectionPrivate": { en: "Private",            fr: "Privé" },
  "chat.noPrivateRooms": { en: "No private rooms yet — join one with a code.", fr: "Aucun salon privé — rejoins-en un avec un code." },
  "chat.roomColor":    { en: "Room Color",           fr: "Couleur du salon" },
  "chat.deleteMessageConfirm": { en: "Delete this message?", fr: "Supprimer ce message ?" },
  "chat.newRoom":      { en: "+ New Room",           fr: "+ Nouveau salon" },
  "chat.createRoom":   { en: "Create a new room",    fr: "Créer un nouveau salon" },
  "chat.createTitle":  { en: "New Chat Room",        fr: "Nouveau salon" },
  "chat.roomName":     { en: "Room Name",            fr: "Nom du salon" },
  "chat.description":  { en: "Description",          fr: "Description" },
  "chat.icon":         { en: "Icon",                 fr: "Icône" },
  "chat.create":       { en: "Create Room",          fr: "Créer le salon" },
  "chat.creating":     { en: "Creating…",            fr: "Création…" },
  "chat.private":      { en: "🔒 Private room",      fr: "🔒 Salon privé" },
  "chat.publicRoom":   { en: "🌐 Public room",       fr: "🌐 Salon public" },
  "chat.privateHint":  { en: "Only people with the join code can enter", fr: "Seules les personnes avec le code peuvent entrer" },
  "chat.publicHint":   { en: "Anyone can find and join this room", fr: "Tout le monde peut trouver et rejoindre ce salon" },
  "chat.searchRooms":  { en: "Search rooms or enter a join code…", fr: "Cherche un salon ou entre un code…" },
  "chat.join":         { en: "Join",                 fr: "Rejoindre" },
  "chat.joining":      { en: "Joining…",             fr: "Connexion…" },
  "chat.open":         { en: "Open",                 fr: "Ouvrir" },
  "chat.hide":         { en: "Hide ✕",               fr: "Masquer ✕" },
  "chat.pinned":       { en: "Pinned",               fr: "Épinglés" },
  "chat.rooms":        { en: "Rooms",                fr: "Salons" },
  "chat.otherRooms":   { en: "Other Rooms",          fr: "Autres salons" },
  "chat.joinCode":     { en: "Join code",            fr: "Code d'accès" },
  "chat.pinRoom":      { en: "Pin room",             fr: "Épingler le salon" },
  "chat.unpinRoom":    { en: "Unpin room",           fr: "Désépingler le salon" },
  "chat.membersMenu":  { en: "Members",              fr: "Membres" },
  "chat.leaveRoom":    { en: "Leave room",           fr: "Quitter le salon" },
  "chat.deleteRoom":   { en: "Delete room (admin)",  fr: "Supprimer le salon (admin)" },
  "chat.noCode":       { en: "No room found for this code", fr: "Aucun salon trouvé pour ce code" },
  "chat.joinFailed":   { en: "Could not join the room",    fr: "Impossible de rejoindre le salon" },
  "chat.roomNameRequired": { en: "Room name is required",  fr: "Le nom du salon est requis" },
  "chat.createFailed": { en: "Could not create room",      fr: "Impossible de créer le salon" },
  "chat.showHidden":   { en: "Show {n} hidden room(s)",    fr: "Afficher {n} salon(s) masqué(s)" },
  "chat.copyCode":     { en: "Copy code",            fr: "Copier le code" },

  // ── Modération du chat — PRE_IOS_PLAN.md R4.3 ──
  "chat.messageActions": { en: "Message options",   fr: "Options du message" },
  "chat.report":       { en: "Report message",      fr: "Signaler le message" },
  "chat.blockUser":    { en: "Block user",          fr: "Bloquer l'utilisateur" },
  "chat.guidelines":   { en: "Community guidelines", fr: "Règles de la communauté" },

  // ── Pannes du socket de chat — audit pré-freeze iOS ──
  "chat.sessionExpired":  { en: "Your session expired — sign in again to keep chatting.",
                            fr: "Ta session a expiré — reconnecte-toi pour continuer à discuter." },
  "chat.accessDenied":    { en: "You no longer have access to this room.",
                            fr: "Tu n'as plus accès à ce salon." },
  "chat.roomJoinFailed":  { en: "Could not join this room.",
                            fr: "Impossible de rejoindre ce salon." },

  "report.title":      { en: "Report this message", fr: "Signaler ce message" },
  "report.subtitle":   { en: "We read every report. Tell us what is wrong with it.", fr: "Nous lisons chaque signalement. Dis-nous ce qui ne va pas." },
  "report.reason.spam":       { en: "Spam or scam",        fr: "Pourriel ou arnaque" },
  "report.reason.harassment": { en: "Harassment or bullying", fr: "Harcèlement ou intimidation" },
  "report.reason.hate":       { en: "Hate speech",         fr: "Discours haineux" },
  "report.reason.sexual":     { en: "Sexual content",      fr: "Contenu sexuel" },
  "report.reason.other":      { en: "Something else",      fr: "Autre chose" },
  "report.noteLabel":  { en: "Anything to add? (optional)", fr: "Quelque chose à ajouter ? (facultatif)" },
  "report.notePlaceholder": { en: "Context helps us decide faster…", fr: "Un peu de contexte nous aide à trancher…" },
  "report.submit":     { en: "Send report",         fr: "Envoyer le signalement" },
  "report.sending":    { en: "Sending…",            fr: "Envoi…" },
  "report.sent":       { en: "Report sent — thank you.", fr: "Signalement envoyé — merci." },
  "report.already":    { en: "You already reported this message.", fr: "Tu as déjà signalé ce message." },
  "report.failed":     { en: "Could not send the report", fr: "Impossible d'envoyer le signalement" },

  "block.title":       { en: "Block {name}?",       fr: "Bloquer {name} ?" },
  "block.description": { en: "You will no longer see their messages, and they will no longer see yours. You can undo this at any time in Settings.", fr: "Tu ne verras plus ses messages, et il ne verra plus les tiens. Tu peux annuler à tout moment dans les Paramètres." },
  "block.confirm":     { en: "Block",               fr: "Bloquer" },
  "block.done":        { en: "{name} is blocked.",  fr: "{name} est bloqué." },
  "block.failed":      { en: "Could not block this user", fr: "Impossible de bloquer cet utilisateur" },
  "block.unblockDone": { en: "{name} is unblocked.", fr: "{name} est débloqué." },
  "block.unblockFailed": { en: "Could not unblock", fr: "Impossible de débloquer" },

  "blocked.title":     { en: "Blocked users",       fr: "Utilisateurs bloqués" },
  "blocked.empty":     { en: "You have not blocked anyone.", fr: "Tu n'as bloqué personne." },
  "blocked.hint":      { en: "Blocking hides messages both ways. Unblocking restores them.", fr: "Le blocage masque les messages dans les deux sens. Le déblocage les rétablit." },
  "blocked.unblock":   { en: "Unblock",             fr: "Débloquer" },
  "blocked.loadFailed": { en: "Could not load the blocked list", fr: "Impossible de charger la liste des blocages" },

  "user.viewProfile":  { en: "View full profile",   fr: "Voir le profil complet" },
  "user.blocked":      { en: "blocked",             fr: "bloqué" },
  "chat.openRoom":     { en: "Open room",            fr: "Ouvrir le salon" },
  "chat.shareCode":    { en: "Share this code so others can join:", fr: "Partage ce code pour inviter d'autres joueurs :" },
  "chat.privateCreated": { en: "🔒 Private room created", fr: "🔒 Salon privé créé" },
  "chat.roomsAvailable": { en: "rooms available",    fr: "salons disponibles" },
  "chat.beFirst":      { en: "Be the first to say something!", fr: "Sois le premier à écrire !" },
  "chat.replyingTo":   { en: "Replying to",          fr: "Réponse à" },
  "chat.message":      { en: "Message",              fr: "Message" },

  // ── Auth gate (guest write actions) ──
  "gate.title":        { en: "Sign in required",     fr: "Connexion requise" },
  "gate.message":      { en: "You need to be connected to {action}.", fr: "Vous devez être connecté pour {action}." },
  "gate.signIn":       { en: "Sign in",              fr: "Se connecter" },
  "gate.sendMessage":  { en: "send a message",       fr: "envoyer un message" },
  "gate.createRoom":   { en: "create a room",        fr: "créer un salon" },
  "gate.joinRoom":     { en: "join a room",          fr: "rejoindre un salon" },
  "gate.react":        { en: "react to a message",   fr: "réagir à un message" },
  "gate.pinRoom":      { en: "pin a room",           fr: "épingler un salon" },
  "gate.leaveRoom":    { en: "leave a room",         fr: "quitter un salon" },
  "gate.deleteMessage":{ en: "delete a message",     fr: "supprimer un message" },
  "gate.deleteRoom":   { en: "delete a room",        fr: "supprimer un salon" },
  "gate.report":       { en: "report a message",     fr: "signaler un message" },
  "gate.block":        { en: "block a user",         fr: "bloquer un utilisateur" },
  "gate.searchPlayers":{ en: "search for a player",  fr: "rechercher un joueur" },

  // ── Slips / builder ──
  "slip.build":        { en: "Build",           fr: "Créer" },
  "slip.mySlips":      { en: "My Slips",        fr: "Mes coupons" },
  "slip.predictions":  { en: "Your Predictions", fr: "Tes prédictions" },
  "slip.add":          { en: "Add",             fr: "Ajouter" },
  "slip.active":       { en: "Active",          fr: "Actifs" },
  "slip.history":      { en: "History",         fr: "Historique" },
  "slip.checkResults": { en: "Check results",   fr: "Vérifier les résultats" },
  "slip.visibilityNotice": {
    en: "Once settled, your slips are visible to Pro members — picks stay hidden until puck drop. You can hide them in Settings.",
    fr: "Une fois réglés, tes coupons sont visibles aux membres Pro — les sélections restent cachées jusqu'à la mise au jeu. Tu peux les masquer dans Paramètres.",
  },
  "slip.pending":      { en: "Pending",         fr: "En attente" },
  "slip.won":          { en: "Won",             fr: "Gagné" },
  "slip.lost":         { en: "Lost",            fr: "Perdu" },

  // ── Page joueur (coupons d'un autre membre — réservé aux abonnés Pro) ──────
  "player.title":         { en: "Player",  fr: "Joueur" },
  "player.viewAll":       { en: "See all their bets →", fr: "Voir tous ses paris →" },
  "player.single":        { en: "Single",  fr: "Simple" },
  "player.parlayLegs":    { en: "Parlay · {n} legs", fr: "Combiné · {n} paris" },
  "player.unlocksAt":     { en: "Picks revealed at {time}", fr: "Sélections dévoilées à {time}" },
  "player.unlocksAtStart":{ en: "Picks revealed at puck drop", fr: "Sélections dévoilées à la mise au jeu" },
  "player.noLegDetail":   { en: "No breakdown available for this slip", fr: "Aucun détail disponible pour ce coupon" },
  "player.formLine":      { en: "of {settled} bets won this month", fr: "des {settled} paris gagnés ce mois-ci" },
  "player.formTooFew":    { en: "{settled} bets this month — too few to rate", fr: "{settled} paris ce mois-ci — échantillon insuffisant" },
  "player.overallLine":   { en: "{settled} bets in total", fr: "{settled} paris au total" },
  "player.since":         { en: "since {date}", fr: "depuis le {date}" },
  "player.proTitle":      { en: "See other players' bets", fr: "Voir les paris des autres" },
  "player.proDesc":       { en: "Pro members can browse any player's slips, bet by bet.", fr: "Les membres Pro consultent les coupons de n'importe quel joueur, pari par pari." },
  "player.hiddenTitle":   { en: "This player hides their slips", fr: "Ce joueur masque ses coupons" },
  "player.hiddenDesc":    { en: "Nothing to do with your subscription — they chose to stay private.", fr: "Rien à voir avec ton abonnement — il a choisi de rester discret." },
  "player.notFound":      { en: "Player not found", fr: "Joueur introuvable" },
  "player.errorTitle":    { en: "Couldn't load this player", fr: "Impossible de charger ce joueur" },
  "player.noSlipsYet":    { en: "No slips yet", fr: "Aucun coupon pour l'instant" },
  "slip.autoSettle":   { en: "Settled automatically when games finish — riskier bets earn more XP", fr: "Réglé automatiquement à la fin des matchs — plus le pari est risqué, plus il rapporte d'XP" },
  "slip.noSlips":      { en: "No slips yet",    fr: "Aucun coupon" },
  "slip.noSlipsHint":  { en: "Lock your first prediction to see it here", fr: "Verrouille ta première prédiction pour la voir ici" },
  "slip.empty":        { en: "No predictions yet", fr: "Aucune prédiction" },
  "slip.emptyHint":    { en: "Add predictions from the Stats page or tap below to browse all markets", fr: "Ajoute des prédictions depuis la page Stats ou explore les marchés ci-dessous" },
  "slip.browse":       { en: "Browse Markets",  fr: "Explorer les marchés" },
  "slip.signin":       { en: "Sign in to see your slips", fr: "Connecte-toi pour voir tes coupons" },
  "slip.signinHint":   { en: "Your locked slips and history will appear here", fr: "Tes coupons verrouillés et ton historique apparaîtront ici" },
  "slip.placeBet365":  { en: "Place on Bet365 ↗", fr: "Parier sur Bet365 ↗" },
  "slip.placeBet":     { en: "Place on {book} ↗", fr: "Parier sur {book} ↗" },
  "slip.xpEarned":     { en: "XP earned",       fr: "XP gagnés" },
  "slip.sharePhoto":   { en: "Share",           fr: "Partager" },
  "slip.addToSee":     { en: "Add predictions to see probability", fr: "Ajoute des prédictions pour voir la probabilité" },
  "slip.gaugeAddLegs": { en: "Add legs",        fr: "Ajoute des paris" },
  "slip.gaugeStrong":  { en: "Strong",          fr: "Fort" },
  "slip.gaugeModerate":{ en: "Moderate",        fr: "Modéré" },
  "slip.gaugeRisky":   { en: "Risky",           fr: "Risqué" },
  "slip.gaugeLongShot":{ en: "Long Shot",       fr: "Peu probable" },
  "slip.signinRequired":{ en: "Sign in required to submit", fr: "Connexion requise pour soumettre" },
  "slip.legsReady":    { en: "{n} legs ready to lock", fr: "{n} paris prêts à verrouiller" },
  "slip.combined":     { en: "Combined",        fr: "Combiné" },
  "slip.addLeg":       { en: "Add Leg",         fr: "Ajouter un pari" },
  "slip.submitting":   { en: "Submitting...",   fr: "Envoi..." },
  "slip.lockSlip":     { en: "Lock Slip",       fr: "Verrouiller le coupon" },
  "slip.individualProb":{ en: "Individual prediction probability", fr: "Probabilité de prédiction individuelle" },
  "slip.howProbTitle": { en: "How probability works", fr: "Comment fonctionne la probabilité" },
  "slip.howProbBody":  { en: "Combined probability assumes each leg is independent. More legs means a lower combined chance but higher potential reward.", fr: "La probabilité combinée suppose que chaque pari est indépendant. Plus il y a de paris, plus la chance combinée est faible, mais plus la récompense potentielle est élevée." },

  // ── Stats ──
  "stats.title":       { en: "Statistics",      fr: "Statistiques" },
  "stats.subtitle":    { en: "AI-powered predictions", fr: "Prédictions par IA" },
  "stats.search":      { en: "Search team, player, game...", fr: "Cherche une équipe, un joueur, un match..." },
  "stats.teams":       { en: "teams",           fr: "équipes" },
  "stats.futures":     { en: "Season Futures",  fr: "Paris de saison" },
  "stats.loadingTeams":{ en: "Loading team data...", fr: "Chargement des équipes..." },
  "stats.noGames":     { en: "No games scheduled today", fr: "Aucun match aujourd'hui" },
  "stats.byTeam":      { en: "By Team",   fr: "Par équipe" },
  "stats.byGame":      { en: "By Game",   fr: "Par match" },
  "stats.byPlayer":    { en: "By Player", fr: "Par joueur" },
  "stats.statistics":  { en: "Statistics", fr: "Statistiques" },
  "stats.loadingNHL":  { en: "Loading NHL data...", fr: "Chargement des données LNH..." },
  "stats.matches":     { en: "{n} matches", fr: "{n} matchs" },
  "stats.players":     { en: "Players",   fr: "Joueurs" },
  "stats.tapToAdd":    { en: "Tap + to add to slip", fr: "Touche + pour ajouter au coupon" },
  "stats.loadingTeamsHint": { en: "The stats service is not responding. Try again in a moment.", fr: "Le service de statistiques ne répond pas. Réessaie dans un instant." },
  "stats.noGamesHint": { en: "Check back on game nights, or explore season futures below", fr: "Reviens les soirs de match, ou explore les paris de saison ci-dessous" },
  "stats.loadingStandings": { en: "Loading standings data...", fr: "Chargement du classement..." },
  "stats.viewBets":    { en: "View bets ›", fr: "Voir les paris ›" },
  "stats.stanleyCup":  { en: "Stanley Cup", fr: "Coupe Stanley" },
  "stats.conference":  { en: "Conference", fr: "Conférence" },
  "stats.futuresTag":  { en: "Futures",    fr: "Paris de saison" },
  "stats.winCup":      { en: "Win Stanley Cup 2026", fr: "Gagner la Coupe Stanley 2026" },

  // ── Home / landing ──
  "home.bestBets":       { en: "Best Bets",         fr: "Meilleurs paris" },
  "home.top":            { en: "Top {n}",           fr: "Top {n}" },
  "home.show":           { en: "Show",              fr: "Afficher" },
  "home.hide":           { en: "Hide",              fr: "Masquer" },
  "home.rules":          { en: "Rules",             fr: "Règles" },
  "home.safe":           { en: "↓ Safe",            fr: "↓ Sûrs" },
  "home.risky":          { en: "↑ Risky",           fr: "↑ Risqués" },
  "home.noBets":         { en: "No bets available right now", fr: "Aucun pari disponible pour le moment" },
  "home.liveNow":        { en: "Live Now",          fr: "En direct" },
  "home.live":           { en: "Live",              fr: "En direct" },
  "home.noGames":        { en: "No games scheduled", fr: "Aucun match prévu" },
  "home.upcomingMatches":{ en: "Upcoming Matches",  fr: "Matchs à venir" },
  "home.noMatches":      { en: "No matches scheduled", fr: "Aucun match prévu" },
  "home.tonightGames":   { en: "Tonight's Games",   fr: "Matchs de ce soir" },
  "home.tomorrowGames":  { en: "Tomorrow's Games",  fr: "Matchs de demain" },
  "home.gamesOn":        { en: "{date} Games",      fr: "Matchs du {date}" },
  "home.added":          { en: "✓ Added",           fr: "✓ Ajouté" },
  "home.add":            { en: "+ Add",             fr: "+ Ajouter" },
  "home.more":           { en: "More",              fr: "Plus" },
  "home.moreBets":       { en: "More bets",         fr: "Plus de paris" },
  "home.betOn":          { en: "Place a bet →",   fr: "Parier →" },
  "home.addedSlip":      { en: "✓ Added to slip",   fr: "✓ Ajouté au coupon" },
  "home.addToSlip":      { en: "+ Add {name} to slip", fr: "+ Ajouter {name} au coupon" },
  "home.edge":           { en: "+{edge}% edge",     fr: "+{edge}% avantage" },
  "home.game":           { en: "Game",              fr: "Match" },
  "home.nhlGame":        { en: "NHL Game",          fr: "Match LNH" },
  "home.oddsApprox":     { en: "≈{odds}",           fr: "≈{odds}" },
  "home.oddsFairHint":   { en: "Fair odds implied by our model — not a bookmaker price.", fr: "Cote équitable déduite de notre modèle — ce n'est pas un prix de bookmaker." },

  // ── Risk labels ──
  "risk.safe":     { en: "Safe",      fr: "Sûr" },
  "risk.moderate": { en: "Moderate",  fr: "Modéré" },
  "risk.risky":    { en: "Risky",     fr: "Risqué" },
  "risk.high":     { en: "High risk", fr: "Risque élevé" },

  // ── Best bets labels ──
  "bb.teamWin":   { en: "{abbr} to win",    fr: "Victoire de {abbr}" },
  "bb.playerWin": { en: "{name} to win",    fr: "Victoire de {name}" },
  "bb.over":      { en: "Over {line} goals", fr: "Plus de {line} buts" },
  "bb.under":     { en: "Under {line} goals", fr: "Moins de {line} buts" },
  "bb.vs":        { en: "vs {opp}",         fr: "contre {opp}" },

  // ── NHL predictions page ──
  "nhl.title":         { en: "🏒 NHL Predictions", fr: "🏒 Prédictions NHL" },
  "nhl.subtitle":      { en: "All bet365 markets · Rules + ML + LLM", fr: "Tous les marchés bet365 · Règles + ML + LLM" },
  "nhl.ruleStats":     { en: "Statistical rules",  fr: "Règles statistiques" },
  "nhl.llmOpinion":    { en: "LLM opinion",        fr: "Avis du LLM" },
  "nhl.analyzing":     { en: "Analyzing…",         fr: "Analyse en cours..." },
  "nhl.askLLM":        { en: "✨ Ask LLM",          fr: "✨ Demander au LLM" },
  "nhl.today":         { en: "Today",              fr: "Aujourd'hui" },
  "nhl.marketsCount":  { en: "{n} markets",        fr: "{n} marchés" },

  // NHL rule notes
  "nhl.note.moneyline":       { en: "{abbr} home · historical win% vs opponent", fr: "{abbr} domicile · win% historique vs adversaire" },
  "nhl.note.puck_line":       { en: "{abbr} wins by ≥2 goals", fr: "{abbr} gagne par ≥2 buts" },
  "nhl.note.total_goals":     { en: "Avg {goals} goals/game · line {line}", fr: "Moy. {goals} buts/match · ligne {line}" },
  "nhl.note.regulation":      { en: "Win in 60 min (no OT/SO)", fr: "Victoire en 60 min (sans OT/SO)" },
  "nhl.note.game_to_ot":      { en: "Close games → OT", fr: "Matchs serrés → OT" },
  "nhl.note.btts":            { en: "GF/G home {h} · away {a}", fr: "GF/G domicile {h} · ext {a}" },
  "nhl.note.winning_margin":  { en: "Exact winning margin", fr: "Marge de victoire exacte" },
  "nhl.note.alt_puck_line":   { en: "Alternate line ±2.5 goals", fr: "Ligne alternative ±2.5 buts" },
  "nhl.note.ot_winner":       { en: "Favorite in OT if game goes to overtime", fr: "Favori en OT si prolongation" },
  "nhl.note.p1_winner":       { en: "Win% in 1st period", fr: "Win% en 1ère période" },
  "nhl.note.p2_winner":       { en: "Win% in 2nd period", fr: "Win% en 2e période" },
  "nhl.note.p3_winner":       { en: "Win% in 3rd period", fr: "Win% en 3e période" },
  "nhl.note.high_period":     { en: "2nd period often the most productive (NHL avg)", fr: "2e période souvent la + productive (NHL avg)" },
  "nhl.note.p1_total":        { en: "Avg {n} goals/P1", fr: "Moy. {n} buts/P1" },
  "nhl.note.p2_total":        { en: "Avg {n} goals/P2", fr: "Moy. {n} buts/P2" },
  "nhl.note.p3_total":        { en: "Avg {n} goals/P3", fr: "Moy. {n} buts/P3" },
  "nhl.note.first_score":     { en: "First to score = home advantage", fr: "Premier à marquer = avantage domicile" },
  "nhl.note.last_score":      { en: "Last goal → often the leading team", fr: "Dernier but → souvent l'équipe qui mène" },
  "nhl.note.team_total":      { en: "{abbr} avg {n} goals/game", fr: "{abbr} avg {n} buts/match" },
  "nhl.note.team_pp":         { en: "Power play goals · avg ~0.8/game", fr: "Power play goals · moyenne ~0.8/match" },
  "nhl.note.clean_sheet":     { en: "{abbr} concedes 0 goals", fr: "{abbr} concède 0 but" },
  "nhl.note.every_period":    { en: "Score in all 3 periods", fr: "Marquer dans les 3 périodes" },
  "nhl.note.total_pim":       { en: "Total PIM · line 12.5 min · NHL avg", fr: "Total PIM · ligne 12.5 min · NHL avg" },
  "nhl.note.anytime_goal":    { en: "Anytime scorer — top scorer ~30%", fr: "Buteur en tout temps — top scorer ~30%" },
  "nhl.note.first_scorer":    { en: "First scorer — top scorer ~12% chance", fr: "1er buteur — top scorer ~12% de chance" },
  "nhl.note.last_scorer":     { en: "Last scorer — similar probability", fr: "Dernier buteur — probabilité similaire" },
  "nhl.note.shots":           { en: "Shots on goal · elite forward avg ~3/game", fr: "Tirs sur but · moyenne attaquant élite ~3/match" },
  "nhl.note.assists":         { en: "Assists · line 0.5", fr: "Passes décisives · ligne 0.5" },
  "nhl.note.points":          { en: "Points (G+A) · top players ~0.8 pts/game", fr: "Points (B+P) · top players ~0.8 pts/match" },
  "nhl.note.pp_point":        { en: "Power play point", fr: "Point en avantage numérique" },
  "nhl.note.saves":           { en: "Saves · elite goalie avg ~28/game", fr: "Arrêts · moyenne gardien élite ~28/match" },
  "nhl.note.pim_player":      { en: "Player penalty minutes · line 0.5", fr: "Minutes de pénalité joueur · ligne 0.5" },
  "nhl.note.blocks":          { en: "Blocked shots · defenseman avg ~1.8/game", fr: "Tirs bloqués · défenseur avg ~1.8/match" },
  "nhl.note.toi":             { en: "Time on ice · line 18.5 min", fr: "Temps sur glace · ligne 18.5 min" },
  "nhl.note.faceoffs":        { en: "Faceoff wins · line 9.5", fr: "Mises en jeu gagnées · ligne 9.5" },
  "nhl.note.hits":            { en: "Hits · line 1.5", fr: "Mises en échec · ligne 1.5" },
  "nhl.note.default":         { en: "Prediction based on season data", fr: "Prédiction basée sur les données saisonnières" },

  // NHL mock LLM response
  "nhl.llm.body": {
    en: "Analysis of {market} for {home} vs {away}: statistical rules give {pct}%. Taking context into account (home ice, recent form, head-to-head), this market offers {value}. Confidence: {conf}. [Connect your LLM model via /api/chat for a more detailed analysis]",
    fr: "Analyse {market} pour {home} vs {away} : les règles statistiques donnent {pct}%. En tenant compte du contexte (domicile, forme récente, confrontations directes), ce marché présente {value}. Confidence: {conf}. [Connectez votre modèle LLM via /api/chat pour une analyse plus détaillée]",
  },
  "nhl.llm.goodValue":  { en: "good value",     fr: "une bonne valeur" },
  "nhl.llm.modValue":   { en: "moderate value", fr: "une valeur modérée" },
  "nhl.llm.high":       { en: "high",           fr: "élevée" },
  "nhl.llm.medium":     { en: "medium",         fr: "moyenne" },

  // ── Prediction page ──
  "pred.title":          { en: "Prediction",            fr: "Prédiction" },
  "pred.calcPredictions":{ en: "Calculated Predictions", fr: "Prédictions calculées" },
  "pred.base":           { en: "Base: {n}%",            fr: "Base : {n} %" },
  "pred.aiPrediction":   { en: "AI Prediction",         fr: "Prédiction IA" },
  "pred.liveModel":      { en: "Live Model",            fr: "Modèle en direct" },
  "pred.rules":          { en: "Rules",                 fr: "Règles" },
  "pred.chart":          { en: "Chart",                 fr: "Graphique" },
  // ── Charts page ──
  "chart.title":         { en: "Statistics",            fr: "Statistiques" },
  "chart.skaters":       { en: "Skaters",               fr: "Patineurs" },
  "chart.goalies":       { en: "Goalies",               fr: "Gardiens" },
  "chart.player":        { en: "Player",                fr: "Joueur" },
  "chart.noData":        { en: "No season data available.", fr: "Aucune donnée de saison disponible." },
  "chart.last6":         { en: "Last 6 seasons",        fr: "6 dernières saisons" },
  "chart.m.points":      { en: "Points",                fr: "Points" },
  "chart.m.goals":       { en: "Goals",                 fr: "Buts" },
  "chart.m.assists":     { en: "Assists",               fr: "Passes" },
  "chart.m.plusMinus":   { en: "+/-",                   fr: "+/-" },
  "chart.m.shots":       { en: "Shots",                 fr: "Tirs" },
  "chart.m.ppPoints":    { en: "PP Pts",                fr: "Pts AN" },
  "chart.m.gp":          { en: "Games",                 fr: "Matchs" },
  "chart.m.wins":        { en: "Wins",                  fr: "Victoires" },
  "chart.m.savePct":     { en: "SV%",                   fr: "%Arr" },
  "chart.m.gaa":         { en: "GAA",                   fr: "MBA" },
  "chart.m.shutouts":    { en: "Shutouts",              fr: "Blanchissages" },
  // Charts — controls & columns
  "chart.teamStats":     { en: "Team Stats",            fr: "Stats d'équipe" },
  "chart.playerStats":   { en: "Player Stats",          fr: "Stats des joueurs" },
  "chart.col.total":     { en: "Total",                 fr: "Total" },
  "chart.col.perGame":   { en: "Avg / Game",            fr: "Moy. / match" },
  "chart.col.vsTeam":    { en: "vs {team}",             fr: "c. {team}" },
  "chart.opponent":      { en: "Opponent",              fr: "Adversaire" },
  "chart.allOpponents":  { en: "Choose team",           fr: "Choisir équipe" },
  "chart.season":        { en: "Season",                fr: "Saison" },
  "chart.tm.goalsFor":     { en: "Goals For",           fr: "Buts pour" },
  "chart.tm.goalsAgainst": { en: "Goals Against",       fr: "Buts contre" },
  "chart.tm.points":       { en: "Points",              fr: "Points" },
  "chart.tm.wins":         { en: "Wins",                fr: "Victoires" },
  "chart.tm.ppPct":        { en: "Power Play %",        fr: "% Avantage num." },
  "chart.tm.pkPct":        { en: "Penalty Kill %",      fr: "% Désavantage num." },
  "chart.tm.shots":        { en: "Shots",               fr: "Tirs" },
  // Charts — team picker, position filter
  "chart.team":          { en: "Team",                  fr: "Équipe" },
  "chart.position":      { en: "Position",              fr: "Position" },
  "chart.pos.all":       { en: "All",                   fr: "Tous" },
  "chart.pos.forwards":  { en: "Forwards",              fr: "Attaquants" },
  "chart.pos.defense":   { en: "Defense",               fr: "Défense" },
  // Charts — team trends table
  "chart.teamTrends":    { en: "Team Trends",           fr: "Tendances d'équipe" },
  "chart.col.season":    { en: "Season",                fr: "Saison" },
  "chart.tm.goalDiff":   { en: "Goal Diff",             fr: "Diff. de buts" },
  "chart.tm.pointPct":   { en: "Point %",               fr: "% Points" },
  "chart.tm.faceoffPct": { en: "Faceoff %",             fr: "% Mises au jeu" },
  "chart.tm.record":     { en: "Record",                fr: "Fiche" },
  "chart.tm.home":       { en: "Home",                  fr: "Domicile" },
  "chart.tm.away":       { en: "Away",                  fr: "Extérieur" },
  "chart.tm.last10":     { en: "Last 10",               fr: "10 derniers" },
  "chart.tm.streak":     { en: "Streak",                fr: "Séquence" },
  "chart.tm.oneGoal":    { en: "1-Goal Games",          fr: "Matchs à 1 but" },
  // Charts — line graph + pie breakdowns
  "chart.byGame":        { en: "by game",               fr: "par match" },
  "chart.cumNote":       { en: "Cumulative · top {n} players", fr: "Cumulé · {n} meilleurs joueurs" },
  "chart.game":          { en: "Game",                  fr: "Match" },
  "chart.breakdowns":    { en: "Breakdowns",            fr: "Répartitions" },
  "chart.pie.results":   { en: "Results (Home / Away)",  fr: "Résultats (dom. / ext.)" },
  "chart.pie.pointShare":{ en: "Points share by player", fr: "Part des points par joueur" },
  "chart.pie.goalShare": { en: "Goals share by player",  fr: "Part des buts par joueur" },
  "chart.pie.wonHome":   { en: "Won home",              fr: "Gagné dom." },
  "chart.pie.wonAway":   { en: "Won away",              fr: "Gagné ext." },
  "chart.pie.lostHome":  { en: "Lost home",             fr: "Perdu dom." },
  "chart.pie.lostAway":  { en: "Lost away",             fr: "Perdu ext." },
  "chart.others":        { en: "Others",                fr: "Autres" },
  "chart.noTeam":        { en: "No team",               fr: "Aucune équipe" },
  "chart.choosePrompt":  { en: "Choose a team to see its charts.", fr: "Choisis une équipe pour voir ses graphiques." },
  "chart.noPlayer":      { en: "No player",             fr: "Aucun joueur" },
  "chart.choosePlayerPrompt": { en: "Choose a team and player to see their charts.", fr: "Choisis une équipe et un joueur pour voir leurs graphiques." },
  "chart.m.shootingPct": { en: "Shooting %",            fr: "% Tirs" },
  "chart.m.pim":         { en: "PIM",                   fr: "Min. pén." },
  "chart.m.ppg":         { en: "PP Goals",              fr: "Buts AN" },
  "chart.m.shp":         { en: "SH Points",             fr: "Points DN" },
  "chart.m.toi":         { en: "TOI / Game",            fr: "Temps de jeu / match" },
  "chart.m.losses":      { en: "Losses",                fr: "Défaites" },
  "chart.m.otLosses":    { en: "OT Losses",             fr: "Défaites Prol." },
  "chart.pie.pointsBreakdown": { en: "Points Breakdown", fr: "Répartition des points" },
  "chart.pie.pts":       { en: "PTS",                   fr: "PTS" },
  "chart.compare.title":     { en: "Compare Players",   fr: "Comparer les joueurs" },
  "chart.compare.search":    { en: "Search a player to compare…", fr: "Rechercher un joueur à comparer…" },
  "chart.compare.noResults": { en: "No players found",  fr: "Aucun joueur trouvé" },
  "chart.compare.column":    { en: "Compare",           fr: "Comparer" },
  "chart.allPlayers":        { en: "All players",       fr: "Tous les joueurs" },
  "chart.pie.assistShare":   { en: "Assists share by player", fr: "Part des passes par joueur" },
  "chart.bar.decisions":     { en: "Decisions breakdown", fr: "Répartition des décisions" },
  "chart.allTeams":          { en: "All teams",         fr: "Toutes les équipes" },
  "chart.allGames.title":    { en: "All Games",         fr: "Tous les matchs" },
  "chart.allGames.note":     { en: "{n} games · {month}", fr: "{n} matchs · {month}" },
  "chart.gm.date":           { en: "Date",              fr: "Date" },
  "chart.gm.matchup":        { en: "Matchup",           fr: "Match" },
  "chart.gm.score":          { en: "Score",             fr: "Pointage" },
  "chart.gm.total":          { en: "Total",             fr: "Total" },
  "chart.gm.diff":           { en: "Margin",            fr: "Écart" },
  "chart.gm.status":         { en: "Status",            fr: "Statut" },
  "chart.gm.venue":          { en: "Venue",             fr: "Aréna" },
  "chart.gm.next5":          { en: "Next 5 days",       fr: "5 prochains jours" },
  "chart.gm.next10":         { en: "Next 10 days",      fr: "10 prochains jours" },
  "chart.gm.month":          { en: "Month",             fr: "Mois" },
  "chart.gm.results":        { en: "Results",           fr: "Résultats" },
  "chart.gm.upcoming":       { en: "Upcoming",          fr: "À venir" },
  "chart.gm.time":           { en: "Time",              fr: "Heure" },
  "chart.gm.noResults":      { en: "No games played in this range.", fr: "Aucun match joué sur cette période." },
  "chart.gm.noUpcoming":     { en: "No upcoming games in this range.", fr: "Aucun match à venir sur cette période." },
  "chart.gm.allTeams":       { en: "All teams",         fr: "Toutes les équipes" },
  "chart.gm.allGames":       { en: "All games",         fr: "Tous les matchs" },
  "chart.gm.periodScoring":  { en: "Scoring by period", fr: "Pointage par période" },
  "chart.gm.teamStats":      { en: "Game Stats",        fr: "Stats du match" },
  "chart.gm.summary":        { en: "Scoring Summary",   fr: "Résumé du pointage" },
  "chart.gm.stars":          { en: "Three Stars",       fr: "Trois étoiles" },
  "chart.gm.skaters":        { en: "Skaters",           fr: "Patineurs" },
  "chart.gm.goalies":        { en: "Goalies",           fr: "Gardiens" },
  "chart.gm.seasonForm":     { en: "Season Comparison", fr: "Comparaison de saison" },
  "chart.gm.notStarted":     { en: "Stats available once the game starts.", fr: "Stats disponibles au début du match." },
  "chart.gm.shots":          { en: "Shots",             fr: "Tirs" },
  "chart.gm.hits":           { en: "Hits",              fr: "Mises en échec" },
  "chart.gm.blocks":         { en: "Blocked Shots",     fr: "Tirs bloqués" },
  "chart.gm.giveaways":      { en: "Giveaways",         fr: "Revirements" },
  "chart.gm.takeaways":      { en: "Takeaways",         fr: "Revirements provoqués" },
  "chart.gm.ppGoals":        { en: "PP Goals",          fr: "Buts en AN" },
  "chart.gm.pim":            { en: "PIM",               fr: "Min. pén." },
  "chart.gm.period":         { en: "Period",            fr: "Période" },
  "chart.gm.ot":             { en: "OT",                fr: "Prol." },
  "chart.gm.so":             { en: "SO",                fr: "Fusillade" },
  "chart.gm.scheduled":      { en: "Scheduled",         fr: "À venir" },
  "chart.gm.live":           { en: "Live",              fr: "En direct" },
  "chart.gm.final":          { en: "Final",             fr: "Terminé" },
  "chart.allTeams.title":    { en: "All Teams",         fr: "Toutes les équipes" },
  "chart.allTeams.note":     { en: "League performance · {n} teams", fr: "Performance de la ligue · {n} équipes" },
  "chart.searchPlayer":      { en: "Search a player…",  fr: "Rechercher un joueur…" },
  "chart.searchTeam":        { en: "Search a team…",    fr: "Rechercher une équipe…" },
  "chart.noResults":         { en: "No results",        fr: "Aucun résultat" },
  "chart.tm.gp":             { en: "GP",                fr: "PJ" },
  "chart.tm.losses":         { en: "Losses",            fr: "Défaites" },
  "chart.tm.otLosses":       { en: "OT Losses",         fr: "Défaites Prol." },
  "chart.tm.shotsAgainst":   { en: "Shots Against",     fr: "Tirs contre" },
  "chart.tm.shutouts":       { en: "Shutouts",          fr: "Blanchissages" },
  "chart.bar.note":          { en: "Top {n} · stacked", fr: "Top {n} · empilé" },
  "chart.bar.allNote":       { en: "All {n} · stacked", fr: "Les {n} · empilé" },
  "chart.pie.winShare":      { en: "Wins share by goalie",    fr: "Part des victoires par gardien" },
  "chart.pie.shutoutShare":  { en: "Shutouts share by goalie", fr: "Part des blanchissages par gardien" },
  "chart.pie.gpShare":       { en: "Games played share",      fr: "Part des matchs joués" },
  "chart.allPlayers.title":  { en: "Top Players",       fr: "Meilleurs joueurs" },
  "chart.allPlayers.note":   { en: "Top {n} by {metric}", fr: "Top {n} par {metric}" },
  "chart.rank":              { en: "#",                 fr: "#" },
  "pred.llmAnalysis":    { en: "LLM Analysis",          fr: "Analyse LLM" },
  "pred.markets":        { en: "Markets",               fr: "Marchés" },
  "pred.hideAll":        { en: "👁 Hide all",           fr: "👁 Masquer tout" },
  "pred.revealAll":      { en: "👁 Reveal all",         fr: "👁 Révéler tout" },
  "pred.showingRules":   { en: "📐 Rules — all",        fr: "📐 Règles — tout" },
  "pred.showingMl":      { en: "🤖 ML — all",           fr: "🤖 ML — tout" },
  "pred.tap":            { en: "Tap",                   fr: "Toucher" },
  "pred.today":          { en: "Today",                 fr: "Aujourd'hui" },
  "pred.recommendedBet": { en: "Recommended Bet",       fr: "Pari recommandé" },
  "pred.goToBuilder":    { en: "Go to Bet Builder →",   fr: "Aller au créateur de coupon →" },
  "pred.recentForm":     { en: "Recent Form",           fr: "Forme récente" },
  "pred.h2hTitle":       { en: "Head-to-head",          fr: "Confrontations directes" },
  "pred.h2hNone":        { en: "No meetings yet this season", fr: "Aucune confrontation cette saison" },
  "pred.win":            { en: "Win",                   fr: "Victoire" },
  "pred.loss":           { en: "Loss",                  fr: "Défaite" },
  "pred.ranking":        { en: "Ranking",               fr: "Classement" },
  "pred.points":         { en: "Points",                fr: "Points" },
  "pred.predFactors":    { en: "Prediction Factors",    fr: "Facteurs de prédiction" },
  "pred.notFound":       { en: "Not Found",             fr: "Introuvable" },
  "pred.notExist":       { en: "This prediction doesn't exist.", fr: "Cette prédiction n'existe pas." },
  "pred.goBack":         { en: "Go Back",               fr: "Retour" },
  "pred.slipShort":      { en: "✓ Slip",                fr: "✓ Coupon" },
  "pred.slipAddShort":   { en: "+ Slip",                fr: "+ Coupon" },
  "pred.addToSlip":      { en: "+ Add to slip",         fr: "+ Ajouter au coupon" },
  "pred.addedToSlip":    { en: "✓ Added to slip",       fr: "✓ Ajouté au coupon" },
  "pred.lastN":          { en: "Last {n}",              fr: "{n} derniers" },
  "pred.formOverLast":   { en: "Form over last {n} games · {wl}", fr: "Forme sur les {n} derniers matchs · {wl}" },
  "pred.winRateL":       { en: "Win Rate (L{n})",       fr: "Taux de victoire (L{n})" },
  "pred.confHigh":       { en: "High Confidence",       fr: "Confiance élevée" },
  "pred.confModerate":   { en: "Moderate",              fr: "Modérée" },
  "pred.confEven":       { en: "Even Match",            fr: "Match serré" },
  "pred.confUnderdog":   { en: "Underdog Pick",         fr: "Choix outsider" },
  "pred.chooseTeam":     { en: "Which team are you betting on?", fr: "Sur quelle équipe pariez-vous ?" },
  "pred.bettingOn":      { en: "Betting on",            fr: "Pari sur" },
  "pred.change":         { en: "Change",                fr: "Changer" },
  "pred.odds":           { en: "Odds",                  fr: "Cote" },
  "pred.unavailable":               { en: "Model prediction unavailable",                       fr: "Prédiction du modèle indisponible" },
  "pred.unavailableNotConfigured":  { en: "Prediction service not configured",                  fr: "Service de prédiction non configuré" },
  "pred.unavailableOffline":        { en: "Prediction service unreachable",                     fr: "Service de prédiction injoignable" },
  "pred.unavailableHint":           { en: "No estimate is shown rather than a made-up one. Try again shortly.", fr: "Aucune estimation n'est affichée plutôt qu'un chiffre inventé. Réessaie dans un instant." },
  "pred.unavailableLeg":            { en: "Can't add this leg — no model probability right now.", fr: "Impossible d'ajouter cette jambe — pas de probabilité du modèle pour l'instant." },
  "pred.unavailableParlay":         { en: "Combined probability unavailable",                   fr: "Probabilité combinée indisponible" },
  "lastn.noData":                   { en: "No data",                                            fr: "Pas de données" },
  "pred.viewPlayers":    { en: "👥 View players",       fr: "👥 Voir les joueurs" },
  // Game picker (player & team pages) + players table (game page)
  "pred.forGame":        { en: "Bets for game",         fr: "Paris pour le match" },
  "pred.chooseGame":     { en: "Choose a game",         fr: "Choisir un match" },
  "pred.viewGame":       { en: "View game →",           fr: "Voir le match →" },
  "pred.noUpcoming":     { en: "No game scheduled in the next 14 days", fr: "Aucun match prévu dans les 14 prochains jours" },
  "pred.playersTable":   { en: "Players",               fr: "Joueurs" },
  "pred.seasonStats":    { en: "Season stats",          fr: "Stats de la saison" },
  "pred.playerCharts":   { en: "Stats",                 fr: "Stats" },
  "pred.playerTeam":     { en: "Team",                  fr: "Équipe" },
  "pred.playerPreds":    { en: "Predictions",           fr: "Prédictions" },
  "pred.playerBackToStats": { en: "Back to his stats",  fr: "Revoir ses stats" },
  "pro.back":            { en: "Back",                  fr: "Retour" },
  // ── Market selector sheet ──
  "mkt.addPrediction": { en: "Add Prediction",   fr: "Ajouter une prédiction" },
  "mkt.selectMarket":  { en: "Select Market",    fr: "Choisir un marché" },
  "mkt.configure":     { en: "Configure",        fr: "Configurer" },
  "mkt.search":        { en: "Search team, player, or game…", fr: "Cherche une équipe, un joueur ou un match…" },
  "mkt.games":         { en: "🏒 Games",         fr: "🏒 Matchs" },
  "mkt.teams":         { en: "🛡️ Teams",         fr: "🛡️ Équipes" },
  "mkt.players":       { en: "⭐ Players",        fr: "⭐ Joueurs" },
  "mkt.backToMarkets": { en: "← Back to markets", fr: "← Retour aux marchés" },
  "mkt.line":          { en: "Line ({unit})",    fr: "Ligne ({unit})" },
  "mkt.selection":     { en: "Selection",        fr: "Sélection" },
  "mkt.draw60":        { en: "Draw after 60 min", fr: "Nul après 60 min" },
  "mkt.addedSlip":     { en: "✓ Added to Slip!", fr: "✓ Ajouté au coupon !" },
  "mkt.adding":        { en: "Adding…",          fr: "Ajout…" },
  "mkt.addToSlip":     { en: "Add to Prediction Slip", fr: "Ajouter au coupon de prédiction" },

  // ── ML prediction card ──
  "ml.title":        { en: "ML Prediction",   fr: "Prédiction ML" },
  "ml.aiPrediction": { en: "AI Prediction",   fr: "Prédiction IA" },
  "ml.conf":         { en: "{n}% conf.",      fr: "{n} % conf." },
  "ml.confidence":   { en: "{n}% confidence", fr: "{n} % de confiance" },
  "ml.probability":  { en: "probability",     fr: "probabilité" },
  "ml.vsRules":      { en: "{d}% vs rules",   fr: "{d} % vs règles" },
  "ml.rules":        { en: "Rules",           fr: "Règles" },
  "ml.rulesColon":   { en: "Rules:",          fr: "Règles :" },
  "ml.sameSignal":   { en: "≈ same signal",   fr: "≈ même signal" },
  "ml.keyFactors":   { en: "Key model factors", fr: "Facteurs clés du modèle" },
  "ml.topFactors":   { en: "Top Factors",     fr: "Facteurs principaux" },
  // ── Facteurs du modèle de score (S4 ②) ─────────────────────────────────────
  // Le service ML renvoie une CLÉ (`factor.attack`, …) et non un libellé, pour
  // que le facteur soit traduit comme le reste. Un nom inconnu — les colonnes
  // brutes du repli classifieur — s'affiche tel quel, cf. `factorLabel`.
  "ml.factor.attack":        { en: "Attack",           fr: "Attaque" },
  "ml.factor.opp_defense":   { en: "Opponent defense", fr: "Défense adverse" },
  "ml.factor.goalie":        { en: "Goaltending",      fr: "Gardien" },
  "ml.factor.lineup":        { en: "Lineup",           fr: "Alignement" },
  "ml.factor.schedule":      { en: "Schedule",         fr: "Calendrier" },
  "ml.factor.team_strength": { en: "Team strength",    fr: "Force d'équipe" },
  "ml.factor.home_ice":      { en: "Home ice",         fr: "Avantage glace" },
  // Filet de `_factor_of` côté service : ne devrait jamais s'afficher.
  "ml.factor.other":         { en: "Other",            fr: "Autres" },
  "ml.verdictStrong":{ en: "Strong signal ▲", fr: "Fort signal ▲" },
  "ml.verdictPos":   { en: "Positive signal", fr: "Signal positif" },
  "ml.verdictNeutral":{ en: "Neutral signal", fr: "Signal neutre" },
  "ml.verdictWeak":  { en: "Weak signal ▼",   fr: "Signal faible ▼" },
  "ml.explainNorm":  { en: "The model estimates a {pct}% probability based on stats and head-to-head records.", fr: "Le modèle estime {pct} % de probabilité basé sur les statistiques et confrontations." },
  "ml.explainFallback": { en: "ML estimate based on season stats, head-to-head records and recent trends for {market}.", fr: "Estimation ML basée sur les statistiques de saison, confrontations directes et tendances récentes pour {market}." },
  "ml.thisMarket":   { en: "this market",     fr: "ce marché" },

  // ── Last N games section ──
  "lastn.selectTeam":  { en: "Select a team",     fr: "Choisis une équipe" },
  "lastn.chooseTeam":  { en: "Choose a team…",    fr: "Choisis une équipe…" },
  "lastn.searchTeam":  { en: "Search team…",      fr: "Cherche une équipe…" },
  "lastn.selectSpan":  { en: "Select span",       fr: "Choisis une période" },
  "lastn.lastGames":   { en: "Last {n} Games",    fr: "{n} derniers matchs" },
  "lastn.loading":     { en: "Loading…",          fr: "Chargement…" },
  "lastn.explore":     { en: "Select a team above to explore their recent form", fr: "Choisis une équipe ci-dessus pour explorer sa forme récente" },

  // ── Players tab ──
  "players.selectTeam":  { en: "Select a team",     fr: "Choisis une équipe" },
  "players.loading":     { en: "loading…",          fr: "chargement…" },
  "players.count":       { en: "{n} players",       fr: "{n} joueurs" },
  "players.none":        { en: "No players found for {abbr}", fr: "Aucun joueur trouvé pour {abbr}" },
  "players.pickHint":    { en: "← Pick a team to see its players", fr: "← Choisis une équipe pour voir ses joueurs" },

  // ── Share page ──
  // `share.title` / `heading` / `slipId` / `soon` retirées avec SharePage le
  // 2026-09-06 (Guideline 2.1 / 4.2). `share.goHome` reste : NotFoundPage s'en
  // sert, c'est son seul appelant.
  "share.goHome":     { en: "Go to Home",         fr: "Aller à l'accueil" },

  // ── Login ──
  "login.title":     { en: "Welcome back",     fr: "Bon retour" },
  "login.email":     { en: "Email",            fr: "Courriel" },
  "login.password":  { en: "Password",         fr: "Mot de passe" },
  "login.signin":    { en: "Sign In",          fr: "Se connecter" },
  "login.signup":    { en: "Create Account",   fr: "Créer un compte" },
  "login.google":    { en: "Continue with Google", fr: "Continuer avec Google" },
  "login.username":  { en: "Username",         fr: "Nom d'utilisateur" },
  "login.firstName": { en: "First name (optional)", fr: "Prénom (facultatif)" },
  "login.or":        { en: "or",               fr: "ou" },
  "login.error":     { en: "Something went wrong", fr: "Une erreur est survenue" },
  "login.disclaimer":{ en: "18+ · Gamble Responsibly · Not available in all jurisdictions", fr: "18+ · Jouez de manière responsable · Non disponible dans toutes les juridictions" },
  "login.codeSent":   { en: "We sent a 6-digit code to your email.", fr: "Nous avons envoyé un code à 6 chiffres à votre courriel." },
  "login.verifyPrompt":{ en: "Enter the confirmation code sent to", fr: "Entrez le code de confirmation envoyé à" },
  "login.verifyBtn":  { en: "Confirm",            fr: "Confirmer" },
  "login.resend":     { en: "Resend code",        fr: "Renvoyer le code" },
  "login.back":       { en: "← Back",             fr: "← Retour" },
  "login.remember":   { en: "Keep me logged in",  fr: "Rester connecté" },
  "login.forgot":     { en: "Forgot password?",   fr: "Mot de passe oublié ?" },
  "login.forgotPrompt":{ en: "Enter your email and we'll send you a reset code.", fr: "Entrez votre courriel et nous vous enverrons un code de réinitialisation." },
  "login.sendCode":   { en: "Send code",          fr: "Envoyer le code" },
  "login.newPassword":{ en: "New password",       fr: "Nouveau mot de passe" },
  "login.resetBtn":   { en: "Reset password",     fr: "Réinitialiser le mot de passe" },
  "login.resetDone":  { en: "Password updated — you can now sign in.", fr: "Mot de passe mis à jour — vous pouvez vous connecter." },
  "login.confirmPassword": { en: "Confirm password", fr: "Confirmez le mot de passe" },
  "login.pwdMismatch": { en: "Passwords do not match.", fr: "Les mots de passe ne correspondent pas." },
  "login.introTitle": { en: "Smarter bets, backed by data", fr: "Des paris plus malins, basés sur les données" },
  "login.introSubtitle": { en: "Sign in to unlock the full experience.", fr: "Connectez-vous pour débloquer toute l'expérience." },
  "login.continueGuest": { en: "Browse without signing in →", fr: "Parcourir sans se connecter →" },
  "login.feat1Title": { en: "AI predictions", fr: "Prédictions IA" },
  "login.feat1Body": { en: "Model-driven win probabilities on every market.", fr: "Probabilités de victoire par modèle sur chaque marché." },
  "login.feat2Title": { en: "Best bets & edges", fr: "Meilleurs paris & edges" },
  "login.feat2Body": { en: "Pre-ranked value picks across live and upcoming games.", fr: "Sélections de valeur classées pour les matchs en direct et à venir." },
  "login.feat3Title": { en: "Build & track slips", fr: "Créez & suivez vos coupons" },
  "login.feat3Body": { en: "Combine legs, lock slips and follow your results.", fr: "Combinez vos sélections, verrouillez et suivez vos résultats." },

  // ── Pro / subscription ──
  "pro.title":        { en: "Go ArakIce Pro",  fr: "Passe à ArakIce Pro" },
  "pro.subtitle":     { en: "Unlock the full edge: every prediction, the value-bet finder, and unlimited AI analysis.", fr: "Débloque l'avantage complet : toutes les prédictions, le détecteur de value bets et l'analyse IA illimitée." },
  "pro.included":     { en: "Included in Pro", fr: "Inclus dans Pro" },
  "pro.badge":        { en: "Pro",             fr: "Pro" },
  "pro.unlock":       { en: "Unlock with Pro", fr: "Débloquer avec Pro" },
  "pro.perMonth":     { en: "/mo",             fr: "/mois" },
  "pro.annualNote":   { en: "or $99/yr (2 months free)", fr: "ou 99 $/an (2 mois offerts)" },
  "pro.cta":          { en: "Upgrade to Pro",  fr: "Passer à Pro" },
  "pro.startTrial":   { en: "Start 7-day free trial", fr: "Commencer l'essai gratuit 7 jours" },
  "pro.trialNote":    { en: "Start with 7 days free, then billed monthly.", fr: "7 jours gratuits, puis facturé mensuellement." },
  "pro.trialActive":  { en: "Free trial active 🎉", fr: "Essai gratuit actif 🎉" },
  "pro.trialEnds":    { en: "Trial ends on",   fr: "Essai se termine le" },
  "pro.loginPrompt":  { en: "Sign in to subscribe", fr: "Connecte-toi pour t'abonner" },
  "pro.cancel":       { en: "Cancel subscription", fr: "Annuler l'abonnement" },
  "pro.isProTitle":   { en: "You're Pro 🎉",   fr: "Tu es Pro 🎉" },
  "pro.isProBody":    { en: "Thanks! You have access to everything.", fr: "Merci ! Tu as accès à toutes les fonctionnalités." },
  "pro.renews":       { en: "Renews on",       fr: "Renouvellement le" },
  "pro.cancelScheduled": { en: "Your Pro access ends on", fr: "Ton accès Pro se termine le" },
  "pro.successTitle": { en: "Welcome to ArakIce Pro 🎉", fr: "Bienvenue dans ArakIce Pro 🎉" },
  "pro.successBody":  { en: "Your Pro access is active. Enjoy every prediction, alert and market — no limits.", fr: "Ton accès Pro est activé. Profite de toutes les prédictions, alertes et marchés — sans limite." },
  "pro.successHome":  { en: "Back to home",    fr: "Retour à l'accueil" },
  "pro.getPro":       { en: "Get ArakIce Pro", fr: "Passer à ArakIce Pro" },
  "pro.manage":       { en: "Manage subscription", fr: "Gérer l'abonnement" },
  "pro.settingsCancel": { en: "Cancel subscription", fr: "Annuler l'abonnement" },
  "pro.canceling":    { en: "Canceling…",      fr: "Annulation…" },
  "pro.subscription": { en: "Subscription",    fr: "Abonnement" },
  "pro.promo.label":       { en: "Have a promo code?", fr: "Tu as un code promo ?" },
  "pro.promo.placeholder": { en: "Enter code",         fr: "Entre ton code" },
  "pro.promo.apply":       { en: "Apply",              fr: "Appliquer" },
  // Pro-exclusive benefits (title + description)
  "pro.b.bestbets.t": { en: "Daily Best Bets",           fr: "Best Bets du jour" },
  "pro.b.bestbets.d": { en: "The day's top picks, selected and rated by the model.", fr: "Les meilleurs paris du jour, sélectionnés et notés par le modèle." },
  "pro.b.ev.t":       { en: "Value-bet finder (EV)",     fr: "Détecteur de value bets (EV)" },
  "pro.b.ev.d":       { en: "Automatically flags positive-EV bets where your edge beats the odds.", fr: "Repère automatiquement les paris à valeur positive (+EV) où ton edge dépasse la cote." },
  "pro.b.alerts.t":   { en: "Value-bet notifications",   fr: "Notifications value bets" },
  "pro.b.alerts.d":   { en: "Get alerted the moment a new +EV appears, before the odds move.", fr: "Reçois une alerte dès qu'un nouveau +EV apparaît, avant que la cote bouge." },
  "pro.b.llm.t":      { en: "Unlimited AI analysis",     fr: "Analyse IA illimitée" },
  "pro.b.llm.d":      { en: "The LLM's take on every game, with no daily limit.", fr: "L'avis du LLM sur tous les matchs, sans limite quotidienne." },
  "pro.b.markets.t":  { en: "All markets & full slate",  fr: "Tous les marchés & calendrier complet" },
  "pro.b.markets.d":  { en: "Beyond today's games: the full schedule and every bet365 market.", fr: "Au-delà des matchs du jour : tout le calendrier et chaque marché bet365." },
  "pro.b.others.t":   { en: "Other players' stats & bets", fr: "Stats & bets des autres joueurs" },
  "pro.b.others.d":   { en: "Compare yourself to the leaderboard and see their picks.", fr: "Compare-toi aux meilleurs du classement et vois leurs paris." },

  // ── Schedule (calendrier des matchs) ──
  "home.schedule":       { en: "Game calendar", fr: "Calendrier des matchs" },
  "schedule.title":      { en: "Schedule",      fr: "Calendrier" },
  "schedule.subtitle":   { en: "Every game of the season", fr: "Tous les matchs de la saison" },
  "schedule.loading":    { en: "Loading games…", fr: "Chargement des matchs…" },
  "schedule.noGames":    { en: "No games this month.", fr: "Aucun match ce mois-ci." },
  "schedule.error":      { en: "Couldn't load the schedule.", fr: "Impossible de charger le calendrier." },
  "schedule.at":         { en: "@", fr: "@" },

  // ── Home: value bets (EV) + locked sections ──
  "home.evTitle":     { en: "Value Bets (EV)",  fr: "Value Bets (EV)" },
  "home.evSpot":      { en: "Value spot · model edge", fr: "Opportunité · edge du modèle" },
  "home.evEmpty":     { en: "No value bets right now — check back soon.", fr: "Aucun value bet pour l'instant — reviens bientôt." },
  "home.evLockDesc":  { en: "The detector flags bets where our model's probability beats the bookmaker's odds (+EV). Pro only.", fr: "Le détecteur repère les paris où la probabilité de notre modèle dépasse la cote (+EV). Réservé aux Pro." },
  "home.evSettings":  { en: "Alert settings", fr: "Réglages des alertes" },
  "home.bestBetsLockDesc": { en: "The day's top picks, selected and rated by the model. Upgrade to Pro to see them.", fr: "Les meilleurs paris du jour, sélectionnés et notés par le modèle. Passe à Pro pour les voir." },

  // ── Profile: notifications (Pro) ──
  "profile.notifications":      { en: "Notifications",         fr: "Notifications" },
  "profile.notifyValueBets":    { en: "Value-bet alerts",      fr: "Alertes value bets" },
  "profile.notifyValueBetsHint":{ en: "Get notified when a new +EV opportunity appears.", fr: "Sois averti dès qu'un nouveau +EV apparaît." },
  "profile.minEv":              { en: "Minimum edge",           fr: "Edge minimum" },
  "profile.minEvHint":          { en: "Only alert me when the value bet's edge is at least this %.", fr: "Ne m'alerte que si l'edge du value bet atteint au moins ce %." },
  "profile.notifyDenied":       { en: "Notifications blocked — allow them in your browser.", fr: "Notifications bloquées — autorise-les dans ton navigateur." },

  // ── Legal / support ──
  "legal.terms":   { en: "Terms",         fr: "CGU" },
  "legal.privacy": { en: "Privacy",       fr: "Confidentialité" },
  "legal.support": { en: "Support",       fr: "Support" },

  // ── 404 ──
  "notFound.title": { en: "Page not found", fr: "Page introuvable" },
  "notFound.body":  { en: "This page doesn't exist or has moved.", fr: "Cette page n'existe pas ou a été déplacée." },

  // ── League: Pro lock on other players' bets ──
  "league.othersProTitle": { en: "See their bets with Pro", fr: "Vois leurs paris avec Pro" },
  "league.othersProDesc":  { en: "Viewing other players' bet slips is a Pro feature.", fr: "Voir les coupons des autres joueurs est réservé aux Pro." },

  // ── Home: rink layout (jersey carousel + centre-ice live zone) ──
  "home.allTeams":     { en: "All Teams",   fr: "Toutes les équipes" },
  "home.teamStats":    { en: "Stats",       fr: "Stats" },
  "home.teamPrediction": { en: "Prediction", fr: "Prédiction" },
  "home.teamOptions":  { en: "Open {team}", fr: "Ouvrir {team}" },
  "home.noLiveGames":  { en: "No game in progress", fr: "Aucun match en cours" },
  "home.scheduleCta":  { en: "View",           fr: "Voir" },
};

type TParams = Record<string, string | number>;

function translate(key: string, lang: Lang, params?: TParams): string {
  const entry = DICT[key];
  let str = entry ? (entry[lang] ?? entry.en) : key;
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      str = str.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
    }
  }
  return str;
}

interface I18nValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string, params?: TParams) => string;
}

const I18nContext = createContext<I18nValue>({
  lang: "en",
  setLang: () => {},
  t: (k, p) => translate(k, "en", p),
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored === "fr" || stored === "en") return stored;
    } catch { /* navigation privée : on tombe sur la détection */ }
    return detectLang();
  });

  const setLang = (l: Lang) => {
    setLangState(l);
    try { localStorage.setItem(STORAGE_KEY, l); } catch { /* ignore */ }
  };

  /**
   * `<html lang>` suit la langue affichée.
   *
   * `index.html` est servi avec `lang="en"` en dur et ne bougeait jamais : les
   * lecteurs d'écran lisaient donc du français avec une voix anglaise, et la
   * correction orthographique du navigateur se trompait de dictionnaire. C'est
   * la seule écriture hors React de ce module, et elle est volontairement dans
   * un effet plutôt qu'au rendu — muter le document pendant le rendu est un
   * effet de bord que React se réserve le droit de rejouer.
   */
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  return (
    <I18nContext.Provider value={{ lang, setLang, t: (k, p) => translate(k, lang, p) }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n(): I18nValue {
  return useContext(I18nContext);
}
