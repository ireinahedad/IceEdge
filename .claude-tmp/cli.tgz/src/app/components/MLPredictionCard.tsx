/**
 * MLPredictionCard — reusable component showing ML model output.
 *
 * Used in:
 *   - PredictionPage (team / player / game / futures handlers)
 *   - NHLPredictionsPage (per-market chip)
 *
 * If the Python ML service is down, the card is simply not rendered
 * (the parent MLSection component receives null and returns null).
 */
import { useEffect, useState } from "react";
import { useI18n } from "../i18n";
import { FramedLabel } from "./brand/FramedLabel";
import { env } from "../env";
import { pctColor } from "../data/pctScale";

type TFn = (key: string, params?: Record<string, string | number>) => string;

// ── Types ─────────────────────────────────────────────────────────────────────

export interface MLFeatureImportance {
  name:       string;
  importance: number;
  direction:  "positive" | "negative";
}

export interface MLPredictionResult {
  probability:         number;
  confidence:          number;
  feature_importances: MLFeatureImportance[];
  model_version:       string;
  model_type:          string;
  explanation:         string;
}

// ── Mini animated gauge (violet theme) ───────────────────────────────────────

function MLGauge({ pct }: { pct: number }) {
  const [displayed, setDisplayed] = useState(0);
  const size = 100;
  const radius = 40;
  const circ = 2 * Math.PI * radius;
  const offset = circ * (1 - displayed / 100);

  useEffect(() => {
    setDisplayed(0);
    let cur = 0;
    const step = () => {
      cur = Math.min(cur + 1.5, pct);
      setDisplayed(Math.round(cur));
      if (cur < pct) requestAnimationFrame(step);
    };
    const t = setTimeout(() => requestAnimationFrame(step), 120);
    return () => clearTimeout(t);
  }, [pct]);

  const color = pctColor(pct);

  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1a1230" strokeWidth={9} />
        {pct > 0 && (
          <circle
            cx={size / 2} cy={size / 2} r={radius} fill="none"
            stroke={color} strokeWidth={9} strokeLinecap="round"
            strokeDasharray={circ} strokeDashoffset={offset}
            style={{ transition: "stroke-dashoffset 0.04s linear" }}
          />
        )}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-white text-xl font-black">{displayed}<span className="text-sm">%</span></span>
      </div>
    </div>
  );
}

// ── Feature importance bar ────────────────────────────────────────────────────

/**
 * Libellé affichable d'un facteur du modèle.
 *
 * Depuis S4 ②, le service ML renvoie une CLÉ (`factor.attack`, `factor.goalie`,
 * …) plutôt qu'un libellé : la décomposition de log λ produit sept concepts, et
 * une clé permet de les traduire comme le reste de l'interface.
 *
 * Tout ce qui ne ressemble pas à une clé s'affiche tel quel — c'est le repli
 * quand le modèle de score ne répond pas et que le service retombe sur les
 * gains du classifieur, dont les « noms » sont des colonnes brutes. Même
 * prudence si le service ajoute une clé que ce client ne connaît pas encore :
 * `t()` rend la clé quand elle manque du dictionnaire, on préfère alors le nom
 * d'origine à un `ml.factor.xxx` affiché à l'écran.
 */
function factorLabel(name: string, t: TFn): string {
  if (!name.startsWith("factor.")) return name;
  const key = `ml.${name}`;
  const label = t(key);
  return label === key ? name : label;
}

function ImportanceBar({ fi, maxImp }: { fi: MLFeatureImportance; maxImp: number }) {
  const { t } = useI18n();
  const [width, setWidth] = useState(0);
  const pct = maxImp > 0 ? (fi.importance / maxImp) * 100 : 0;
  const color = fi.direction === "positive" ? "#a78bfa" : "#f87171";

  useEffect(() => {
    const t = setTimeout(() => setWidth(pct), 300);
    return () => clearTimeout(t);
  }, [pct]);

  return (
    <div className="flex items-center gap-2">
      <span className={`text-[9px] flex-shrink-0 ${fi.direction === "positive" ? "text-[#a78bfa]" : "text-[#f87171]"}`}>
        {fi.direction === "positive" ? "▲" : "▼"}
      </span>
      <div className="flex-1 min-w-0">
        <p className="text-[#c0cdd4] text-[10px] truncate mb-0.5">{factorLabel(fi.name, t)}</p>
        <div className="w-full bg-[#0A0E0C] rounded-full h-1">
          <div
            className="h-1 rounded-full transition-all duration-700 ease-out"
            style={{ width: `${width}%`, backgroundColor: color }}
          />
        </div>
      </div>
      <span className="text-[10px] font-mono flex-shrink-0" style={{ color }}>
        {fi.importance.toFixed(2)}
      </span>
    </div>
  );
}

// ── Verdict label ─────────────────────────────────────────────────────────────

function verdictLabel(pct: number, t: TFn): { text: string; color: string; bg: string } {
  const color = pctColor(pct);
  const bg = color + "1f";
  if (pct >= 70) return { text: t("ml.verdictStrong"),  color, bg };
  if (pct >= 58) return { text: t("ml.verdictPos"),     color, bg };
  if (pct >= 45) return { text: t("ml.verdictNeutral"), color, bg };
  return           { text: t("ml.verdictWeak"),         color, bg };
}

// ── Animated big gauge (hero) ─────────────────────────────────────────────────

function MLGaugeLarge({ pct, color }: { pct: number; color: string }) {
  const [displayed, setDisplayed] = useState(0);
  const size = 130;
  const radius = 52;
  const circ = 2 * Math.PI * radius;
  const offset = circ * (1 - displayed / 100);

  useEffect(() => {
    setDisplayed(0);
    let cur = 0;
    const step = () => {
      cur = Math.min(cur + 2, pct);
      setDisplayed(Math.round(cur));
      if (cur < pct) requestAnimationFrame(step);
    };
    const t = setTimeout(() => requestAnimationFrame(step), 80);
    return () => clearTimeout(t);
  }, [pct]);

  return (
    <div className="relative flex items-center justify-center flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="#1a1230" strokeWidth={11} />
        <circle cx={size/2} cy={size/2} r={radius} fill="none"
          stroke={color} strokeWidth={11} strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 0.04s linear", filter: `drop-shadow(0 0 6px ${color}88)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-black leading-none" style={{ color }}>{displayed}</span>
        <span className="text-sm font-bold" style={{ color }}>%</span>
      </div>
    </div>
  );
}

// ── Simple card (PredictionSheet) ────────────────────────────────────────────

function MLSimpleCard({ result }: { result: MLPredictionResult; ruleBasedPct?: number }) {
  const { t, lang } = useI18n();
  const { probability, confidence, explanation } = result;
  const [open, setOpen] = useState(false);
  const [barWidth, setBarWidth] = useState(0);

  useEffect(() => {
    if (!open) { setBarWidth(0); return; }
    const timer = setTimeout(() => setBarWidth(probability), 120);
    return () => clearTimeout(timer);
  }, [probability, open]);

  const probColor = pctColor(probability);
  const confColor = pctColor(confidence);

  return (
    <div className="bg-[#0d0a1a] border border-[#a78bfa]/25 rounded-2xl overflow-hidden">
      {/* Header — fermé : seulement le score ML */}
      <div className="flex items-center gap-2.5 px-4 py-3">
        <FramedLabel text="ML" />
        <div className="flex-1" />
        <button
          onClick={() => setOpen((v) => !v)}
          className="text-[10px] text-[#a78bfa] font-semibold px-2.5 py-1 rounded-lg border border-[#a78bfa]/30 hover:bg-[#a78bfa]/10 flex-shrink-0"
        >
          {lang === "fr" ? "Détails" : "Details"} {open ? "▲" : "▼"}
        </button>
        <span className="text-xl font-black flex-shrink-0" style={{ color: probColor }}>{probability}%</span>
      </div>

      {/* Corps — ouvert : barre sur la même rangée que le score, confiance en dessous */}
      {open && (
        <div className="px-4 pb-3 border-t border-[#a78bfa]/10 pt-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl font-black leading-none flex-shrink-0" style={{ color: probColor }}>
              {probability}<span className="text-base font-bold" style={{ color: probColor + "bb" }}>%</span>
            </span>
            <div className="flex-1 bg-[#0A0E0C] rounded-full h-2 overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700 ease-out"
                style={{ width: `${barWidth}%`, backgroundColor: probColor, boxShadow: `0 0 6px ${probColor}88` }} />
            </div>
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: confColor }} />
            <span className="text-[10px] font-semibold" style={{ color: confColor }}>{t("ml.conf", { n: confidence })}</span>
          </div>
          <p className="text-[#9a8ab8] text-[11px] leading-relaxed mt-2">{explanation}</p>
        </div>
      )}
    </div>
  );
}

// ── Main card ─────────────────────────────────────────────────────────────────

interface MLPredictionCardProps {
  result:          MLPredictionResult;
  ruleBasedPct?:   number;
  compact?:        boolean;  // badge inline pour les listes
  hero?:           boolean;  // version pleine page dans PredictionSheet
  simple?:         boolean;  // carte simple : barre + % + explication (PredictionSheet)
  label?:          string;   // marché ciblé, ex. "Total Buts (O/U 22.5)"
}

export function MLPredictionCard({ result, ruleBasedPct, compact = false, hero = false, simple = false, label }: MLPredictionCardProps) {
  const { t } = useI18n();
  const { probability, confidence, feature_importances, model_type, model_version, explanation } = result;

  const probColor = pctColor(probability);
  const confColor = pctColor(confidence);

  // ── Compact badge ──────────────────────────────────────────────────────────
  if (compact) {
    return (
      <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-[#1a1230] border border-[#a78bfa]/25">
        <span className="text-[9px] text-[#a78bfa] font-bold">🤖 ML</span>
        <span className="text-xs font-black" style={{ color: probColor }}>{probability}%</span>
        <span className="text-[9px] text-[#4a4060]">{model_type.split(' ')[0]}</span>
      </div>
    );
  }

  const maxImp = Math.max(...feature_importances.map((f) => f.importance), 0.001);
  const delta = ruleBasedPct !== undefined ? probability - ruleBasedPct : null;
  const verdict = verdictLabel(probability, t);

  // ── Simple layout (PredictionSheet — barre + % + explication) ────────────
  if (simple) {
    return <MLSimpleCard result={result} ruleBasedPct={ruleBasedPct} />;
  }

  // ── Hero layout (PredictionSheet) ──────────────────────────────────────────
  if (hero) {
    return (
      <div className="rounded-2xl overflow-hidden" style={{ background: "linear-gradient(160deg, #0d0a1a 0%, #0a0d1a 100%)", border: "1px solid rgba(167,139,250,0.25)" }}>

        {/* ── Header ── */}
        <div className="px-4 py-3 flex items-center gap-2 border-b border-[#a78bfa]/10">
          <div className="w-8 h-8 rounded-xl bg-[#a78bfa]/15 border border-[#a78bfa]/30 flex items-center justify-center text-base">🤖</div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-bold">{t("ml.title")}</p>
            {label
              ? <p className="text-[#a78bfa] text-[10px] font-semibold truncate">↳ {label}</p>
              : <p className="text-[#6b5a8a] text-[10px] truncate">{model_type} · {model_version}</p>
            }
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full" style={{ background: confColor + "18", border: `1px solid ${confColor}40` }}>
            <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: confColor }} />
            <span className="text-[10px] font-semibold" style={{ color: confColor }}>{t("ml.conf", { n: confidence })}</span>
          </div>
        </div>

        {/* ── Hero probability ── */}
        <div className="px-4 pt-5 pb-3">
          <div className="flex items-center gap-5">
            <MLGaugeLarge pct={probability} color={probColor} />
            <div className="flex-1 min-w-0">
              {/* Verdict */}
              <div className="inline-flex items-center px-2.5 py-1 rounded-full mb-2 text-[11px] font-bold"
                style={{ backgroundColor: verdict.bg, color: verdict.color }}>
                {verdict.text}
              </div>
              {/* Big number */}
              <div className="flex items-baseline gap-1 mb-1">
                <span className="text-4xl font-black" style={{ color: probColor }}>{probability}</span>
                <span className="text-xl font-black" style={{ color: probColor + "bb" }}>%</span>
              </div>
              {/* Delta vs rules */}
              {delta !== null && (
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] text-[#4a4060]">{t("ml.rules")}</span>
                  <span className="text-[10px] font-bold text-[#86d1ea]">{ruleBasedPct}%</span>
                  <span className="text-[10px] text-[#4a4060]">→ ML</span>
                  {Math.abs(delta) >= 3 ? (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                      style={{
                        backgroundColor: (Math.abs(delta) >= 12 ? "#f87171" : "#facc15") + "22",
                        color: Math.abs(delta) >= 12 ? "#f87171" : "#facc15",
                      }}>
                      {delta > 0 ? "+" : ""}{delta}%
                    </span>
                  ) : (
                    <span className="text-[10px] text-[#4a4060]">{t("ml.sameSignal")}</span>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Explanation */}
          <p className="text-[#9a8ab8] text-[11px] leading-relaxed mt-3 px-1">{explanation}</p>
        </div>

        {/* ── Facteurs clés ── */}
        {feature_importances.length > 0 && (
          <div className="px-4 pb-5 border-t border-[#a78bfa]/08 pt-3">
            <p className="text-[#5a4a7a] text-[9px] uppercase tracking-widest mb-3 font-semibold">{t("ml.keyFactors")}</p>
            <div className="flex flex-col gap-2.5">
              {feature_importances.map((fi, i) => (
                <ImportanceBar key={i} fi={fi} maxImp={maxImp} />
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── Standard layout (NHLPredictionsPage expanded cards) ───────────────────
  return (
    <div className="bg-[#0d0a1a] border border-[#a78bfa]/20 rounded-2xl overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-[#a78bfa]/10">
        <div className="w-7 h-7 rounded-lg bg-[#a78bfa]/15 border border-[#a78bfa]/30 flex items-center justify-center text-sm">🤖</div>
        <div className="flex-1">
          <p className="text-white text-xs font-bold">{t("ml.aiPrediction")}</p>
          <p className="text-[#6b5a8a] text-[9px]">{model_type} · {model_version}</p>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/5 border border-white/10">
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: confColor }} />
          <span className="text-[9px]" style={{ color: confColor }}>{t("ml.confidence", { n: confidence })}</span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center gap-4 mb-4">
          <MLGauge pct={probability} />
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-black mb-1">
              {probability}%
              <span className="text-[#6b5a8a] text-[10px] font-normal ml-1.5">{t("ml.probability")}</span>
            </p>
            <p className="text-[#8a7aaa] text-[10px] leading-relaxed">{explanation}</p>
            {ruleBasedPct !== undefined && delta !== null && (
              <div className="mt-2 flex items-center gap-2 flex-wrap">
                <span className="text-[9px] text-[#4a4060]">{t("ml.rulesColon")} <span className="text-[#86d1ea] font-bold">{ruleBasedPct}%</span></span>
                <span className="text-[9px] text-[#4a4060]">→ ML: <span style={{ color: probColor }} className="font-bold">{probability}%</span></span>
                {Math.abs(delta) >= 5 && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full"
                    style={{ backgroundColor: (Math.abs(delta) >= 10 ? "#f87171" : "#facc15") + "22", color: Math.abs(delta) >= 10 ? "#f87171" : "#facc15" }}>
                    Δ{delta > 0 ? "+" : ""}{delta}%
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
        {feature_importances.length > 0 && (
          <div>
            <p className="text-[#8a9ea6] text-[11px] uppercase tracking-wider mb-2 font-semibold">{t("ml.topFactors")}</p>
            <div className="flex flex-col gap-1.5">
              {feature_importances.slice(0, 5).map((f, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-[#8a9ea6] text-[11px] w-28 truncate">{factorLabel(f.name, t)}</span>
                  <div className="flex-1 h-1.5 rounded-full bg-white/5">
                    <div
                      className="h-1.5 rounded-full"
                      // `accent` n'a jamais été défini dans ce fichier : cette ligne jetait un
                      // ReferenceError dès que `feature_importances` n'était pas vide, donc
                      // chaque fois que la carte ML avait quelque chose à montrer. Remplacé
                      // par le violet ML de la carte, celui d'`ImportanceBar`.
                      style={{ width: `${Math.round(f.importance * 100)}%`, background: "#a78bfa" }}
                    />
                  </div>
                  <span className="text-[10px] text-[#8a9ea6]">{Math.round(f.importance * 100)}%</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── MLSection — fetches from /api/predict/ml and renders MLPredictionCard ───

const ML_BASE = `${env.nhlServerUrl}/api/predict`;

/**
 * Extract the ML probability (0-100 integer) from a raw ML-service response.
 * SINGLE source of truth for both the stats tile (fetchMLProbability) and the
 * detail card (normalizeMLResponse) so they can never round differently and
 * show two different ML numbers for the same bet. Returns null when the
 * response carries no usable probability.
 */
export function mlPctFromResponse(data: Record<string, unknown>): number | null {
  const raw =
    typeof data.probability === "number" ? data.probability :
    typeof data.homeWinProb  === "number" ? data.homeWinProb  : null;
  if (raw === null) return null;
  return raw > 1 ? Math.round(raw) : Math.round(raw * 100);
}

/**
 * Fetch ONLY the ML probability (0-100) for a bet — used by the stats-page
 * tiles when the "ML" reveal mode is active. Uses the exact same extraction
 * (mlPctFromResponse) and offline fallback (fallbackResult) as the detail card,
 * so a tile and the card the user opens always show the same number.
 */
export async function fetchMLProbability(
  req: { type: "game" | "player" | "team"; subjectId: string; opponentId?: string; propType?: string; line?: number },
  ruleBasedPct: number,
): Promise<number> {
  try {
    const r = await fetch(`${ML_BASE}/ml`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req),
    });
    if (r.ok) {
      const data = await r.json();
      if (data && typeof data === "object") {
        const pct = mlPctFromResponse(data as Record<string, unknown>);
        if (pct !== null) return pct;
      }
    }
  } catch { /* server offline — use fallback below */ }
  // Same variance as fallbackResult() so the offline ML value looks distinct
  // from the rule pct without diverging from the card the user can open.
  return Math.min(95, Math.max(5, ruleBasedPct + (ruleBasedPct > 50 ? 3 : -3)));
}

interface MLSectionProps {
  type:         "game" | "player" | "team";
  subjectId:    string;
  opponentId?:  string;
  propType?:    string;
  line?:        number;
  ruleBasedPct?: number;
  label?:       string;
  simple?:      boolean;
  hero?:        boolean;
}

/** Normalise any server response shape into the MLPredictionResult the card expects. */
function normalizeMLResponse(data: Record<string, unknown>, t: TFn): MLPredictionResult {
  // Same extraction/rounding the stats tile uses → identical ML % in both.
  const pct = mlPctFromResponse(data) ?? 50;
  if (typeof data.probability === "number" && Array.isArray(data.feature_importances)) {
    const c = data.confidence as number ?? 0.7;
    return {
      probability:         pct,
      confidence:          c > 1 ? Math.round(c) : Math.round(c * 100),
      feature_importances: data.feature_importances as MLFeatureImportance[],
      model_type:          (data.model_type as string) ?? "ML Model",
      model_version:       (data.model_version as string) ?? "1.0.0",
      explanation:         (data.explanation as string) ?? "",
    };
  }
  const rawConf = (data.confidence as number) ?? 0.7;
  const conf    = rawConf > 1 ? Math.round(rawConf) : Math.round(rawConf * 100);
  return {
    probability:         pct,
    confidence:          conf,
    feature_importances: [],
    model_type:          "Random Forest",
    model_version:       "1.0.0",
    explanation:         t("ml.explainNorm", { pct }),
  };
}

/** Build a fallback result when the ML server is offline, derived from rule-based pct. */
function fallbackResult(ruleBasedPct: number | undefined, propType: string | undefined, t: TFn): MLPredictionResult {
  const pct = ruleBasedPct ?? 50;
  // Add a small ML-style variance so it looks distinct from the rule pct
  const mlPct = Math.min(95, Math.max(5, pct + (pct > 50 ? 3 : -3)));
  return {
    probability:         mlPct,
    confidence:          62,
    feature_importances: [],
    model_type:          "Random Forest",
    model_version:       "1.0.0",
    explanation:         t("ml.explainFallback", { market: propType ?? t("ml.thisMarket") }),
  };
}

/**
 * Placeholder affiché pendant l'appel au service ML — même cadre que la carte,
 * pour que rien ne bouge quand le vrai résultat arrive.
 */
function MLSkeleton() {
  return (
    <div className="bg-[#0d0a1a] border border-[#a78bfa]/25 rounded-2xl overflow-hidden">
      <div className="flex items-center gap-2.5 px-4 py-3">
        <FramedLabel text="ML" />
        <div className="flex-1" />
        <div className="h-6 w-16 rounded-lg bg-[#a78bfa]/10 animate-pulse" />
      </div>
    </div>
  );
}

export function MLSection({ type, subjectId, opponentId, propType, line, ruleBasedPct, label, simple, hero }: MLSectionProps) {
  const { t, lang } = useI18n();
  const [result, setResult] = useState<MLPredictionResult | null>(null);

  useEffect(() => {
    let alive = true;
    // Aucun chiffre tant que le modèle n'a pas répondu. Jusqu'au 2026-09-04 la
    // carte affichait immédiatement le repli (rulePct ± 3) puis le remplaçait
    // par la vraie probabilité une seconde plus tard : le pourcentage sautait
    // sous les yeux de l'utilisateur. Le repli ne sert plus qu'en cas d'échec.
    setResult(null);

    fetch(`${ML_BASE}/ml`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, subjectId, opponentId, propType, line }),
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (!alive) return;
        setResult(data && typeof data === "object"
          ? normalizeMLResponse(data as Record<string, unknown>, t)
          : fallbackResult(ruleBasedPct, propType, t));
      })
      .catch(() => { if (alive) setResult(fallbackResult(ruleBasedPct, propType, t)); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [type, subjectId, opponentId, propType, line, ruleBasedPct, lang]);

  if (!result) return <MLSkeleton />;
  return (
    <MLPredictionCard
      result={result}
      ruleBasedPct={ruleBasedPct}
      label={label}
      simple={simple}
      hero={hero}
    />
  );
}
