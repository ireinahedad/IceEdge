/**
 * useChatSocket — real-time chat via Socket.io
 *
 * Usage:
 *   const { messages, onlineCount, connected, initMessages, appendOptimistic, confirmMessage } =
 *     useChatSocket(roomId);
 *
 * Flow:
 *   1. On mount, caller fetches HTTP history and calls mergeMessages(msgs)
 *   2. Socket emits 'new_message' → deduped and appended automatically
 *   3. For own sends: appendOptimistic(msg) immediately, then confirmMessage(tempId, serverMsg)
 *
 * ⚠️ **L'historique est TOUJOURS fusionné, jamais écrasé** — au montage comme
 * après une coupure. `initMessages`, qui remplaçait la liste, a été retiré le
 * 2026-09-08 : il ouvrait une course. Le socket se connecte pendant que le
 * `GET /messages` est en vol, et un message arrivé dans cet intervalle était
 * **effacé par la réponse HTTP**. Court, mais permanent : ce message-là ne
 * revenait jamais.
 *
 * Ce que `initMessages` faisait d'autre, et qu'il fallait remplacer : isoler
 * les salons. C'est maintenant l'effet ci-dessous qui vide la liste quand
 * `roomId` change — donc à l'endroit où le salon change, et non dans le premier
 * `fetch` de l'appelant, où c'était un effet de bord invisible.
 *
 * Survivre à un passage en arrière-plan (audit pré-freeze iOS)
 * ───────────────────────────────────────────────────────────
 * Trois trous se cumulaient, tous visibles dès le premier verrouillage d'écran :
 *
 *   a. `connect` ne faisait que `join_room`. Ce qui est arrivé pendant la
 *      coupure n'est diffusé qu'aux sockets vivantes : c'était **perdu
 *      définitivement**, un trou silencieux dans la conversation. D'où
 *      `resyncKey`, que la page surveille pour redemander l'historique.
 *   b. Aucun écouteur `connect_error`. Le jeton d'accès expire en 15 min, le
 *      serveur refuse alors le handshake et socket.io réessayait en boucle
 *      avec le même jeton mort — chat mort, un point gris pour tout signe.
 *   c. `room_error` était émis par le serveur et écouté par personne.
 *
 * Et `visibilitychange`, qui n'est dans aucun des trois : iOS gèle la
 * WKWebView, la socket peut se croire vivante au réveil et son ping met une
 * vingtaine de secondes à découvrir qu'elle est morte.
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import { io as socketIO, Socket } from 'socket.io-client';
import type { ChatMessage } from '../types/user';
import { refreshSession, getFreshAccessToken } from '../services/authService';
import { env } from '../env';

const SOCKET_URL = env.socketUrl;

/**
 * Plafond du tableau en mémoire.
 *
 * Sans lui, les messages s'accumulaient **sans borne** : le serveur en sert 100
 * au chargement, puis chaque `new_message` en ajoutait un pour toute la durée de
 * la session. Un salon « live » de soir de match laissé ouvert pendant deux
 * heures finissait avec des milliers d'objets — et autant de nœuds DOM, puisque
 * `RoomChat` rend le tableau entier. Sur iPhone, c'est le genre de croissance
 * que WKWebView règle en purgeant l'onglet.
 *
 * 200 : le double de ce que le serveur envoie, donc un resync ne tronque jamais
 * ce qu'il vient de livrer.
 *
 * ⚠️ On coupe par le DÉBUT, donc les plus anciens. Quelqu'un qui lit tout en
 * haut pendant qu'un salon très actif défile peut voir le sommet disparaître.
 * C'est assumé : il n'existe aucun défilement infini ici, ces messages-là ne
 * sont déjà plus rattrapables autrement qu'en rouvrant le salon, et la seule
 * alternative est de laisser la page grossir jusqu'à se faire tuer.
 */
const MAX_MESSAGES = 200;

function capMessages(list: ChatMessage[]): ChatMessage[] {
  return list.length <= MAX_MESSAGES ? list : list.slice(list.length - MAX_MESSAGES);
}

export function useChatSocket(roomId: string | null) {
  const socketRef = useRef<Socket | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [onlineCount, setOnlineCount] = useState(0);
  const [connected, setConnected] = useState(false);
  /** Monte de 1 à chaque fois que l'historique doit être redemandé. */
  const [resyncKey, setResyncKey] = useState(0);
  /** La session est morte : le refresh a échoué après un handshake refusé. */
  const [authError, setAuthError] = useState(false);
  /** Message brut d'un `room_error` du serveur ('Access denied', …). */
  const [roomError, setRoomError] = useState<string | null>(null);

  // Changer de salon remet le compteur à zéro AVANT que la page ne lise sa
  // valeur : sinon son effet croirait revenir d'une coupure et **fusionnerait
  // l'historique du nouveau salon dans les messages de l'ancien**. Ajuster
  // l'état pendant le rendu est le patron prévu pour ça — React rejette ce
  // rendu et recommence avant de lancer le moindre effet.
  const [lastRoomId, setLastRoomId] = useState(roomId);
  if (lastRoomId !== roomId) {
    setLastRoomId(roomId);
    setResyncKey(0);
    setAuthError(false);
    setRoomError(null);
  }

  useEffect(() => {
    if (!roomId) return;

    // Changer de salon vide la liste. Sans ça, la fusion mêlerait les messages
    // du salon précédent à ceux du nouveau. C'est la contrepartie du retrait
    // d'`initMessages` : la remise à zéro appartient au changement de salon.
    setMessages([]);

    // Portées à l'effet, pas au composant : elles doivent repartir de zéro
    // avec chaque socket.
    let cancelled = false;
    let hasConnectedOnce = false;
    let refreshTried = false;

    const socket = socketIO(SOCKET_URL, {
      /**
       * WebSocket SEULEMENT — et ce n'est pas une optimisation.
       *
       * Une poignée de main en HTTP long-polling s'étale sur PLUSIEURS requêtes
       * qui doivent toutes atteindre la MÊME instance : sinon le serveur qui
       * reçoit la deuxième ne connaît pas la session ouverte par la première et
       * répond 400. La parade habituelle est l'affinité de session côté
       * répartiteur — que **Railway ne propose pas, et n'a pas prévu de
       * proposer**.
       *
       * En WebSocket, tout tient dans une seule connexion TCP longue : il n'y a
       * plus rien à faire suivre, donc plus besoin d'affinité. C'est ce qui rend
       * la 2ᵉ instance possible, avec l'adaptateur Redis côté serveur
       * (`server/src/redis.ts`). Les deux vont ensemble.
       *
       * Contrepartie : un réseau qui bloque les WebSockets n'a plus de repli.
       * En pratique c'est très rare aujourd'hui, et le chat est déjà inutilisable
       * sans temps réel — un repli en polling qui ne reçoit jamais les nouveaux
       * messages ne vaut pas mieux qu'une absence de connexion.
       */
      transports: ['websocket'],
      path: '/socket.io',
      // Callback form, not a literal: reading the token is async since R3.6.
      // Socket.io calls this before each (re)connection, so a token refreshed
      // in the meantime is picked up instead of the one captured at mount.
      //
      // `getFreshAccessToken` plutôt que `tokenStore.getAccess` : au retour
      // d'un écran verrouillé, le jeton capturé est souvent mort et le
      // handshake partait pour se faire refuser, le temps d'un aller-retour,
      // avant que `connect_error` ne déclenche enfin le refresh. Le jeton est
      // désormais renouvelé AVANT le handshake, et `connect_error` redevient
      // ce qu'il devrait être : le cas rare.
      auth: (cb: (data: object) => void) => {
        getFreshAccessToken().then((token) => cb({ token: token ?? '' }));
      },
    });
    socketRef.current = socket;

    socket.on('connect', () => {
      setConnected(true);
      setAuthError(false);
      refreshTried = false;          // la prochaine expiration aura droit à son refresh
      socket.emit('join_room', roomId);

      // La PREMIÈRE connexion n'a rien à resynchroniser : la page est déjà en
      // train de charger l'historique. Les suivantes sont des RE-connexions.
      if (hasConnectedOnce) setResyncKey((n) => n + 1);
      hasConnectedOnce = true;
    });

    socket.on('disconnect', () => setConnected(false));

    /**
     * Handshake refusé. Le serveur répond 'Invalid or expired token' ou
     * 'Authentication required' (`socket.ts`) ; tout le reste est une panne
     * réseau, que socket.io retente très bien tout seul.
     *
     * Une seule tentative de refresh par cycle : `refreshTried` n'est remis à
     * false que par un `connect` réussi. Sans ce garde, chaque tentative de
     * reconnexion relancerait une rotation de jeton — une tempête de refresh
     * sur un réseau qui va mal.
     */
    socket.on('connect_error', async (err: Error) => {
      setConnected(false);
      if (!/token|auth/i.test(String(err?.message ?? ''))) return;
      if (refreshTried) { setAuthError(true); return; }
      refreshTried = true;
      const ok = await refreshSession();
      if (cancelled) return;
      if (ok) socket.connect();      // le callback `auth` relira le jeton neuf
      else setAuthError(true);
    });

    // Émis par le serveur quand `join_room` est refusé. Personne ne l'écoutait :
    // l'utilisateur restait dans un salon qui ne recevait rien, sans un mot.
    socket.on('room_error', ({ error }: { roomId: string; error: string }) => {
      setRoomError(error);
    });

    socket.on('new_message', (msg: ChatMessage) => {
      setMessages((prev) => {
        // Ignore if already present (own optimistic or duplicate)
        if (prev.some((m) => m.id === msg.id)) return prev;
        return capMessages([...prev, msg]);
      });
    });

    socket.on('message_deleted', ({ messageId }: { messageId: string }) => {
      setMessages((prev) => prev.filter((m) => m.id !== messageId));
    });

    socket.on('room_users', (count: number) => setOnlineCount(count));

    /**
     * Retour au premier plan. iOS gèle la WKWebView : au réveil la socket peut
     * se croire connectée alors que la connexion est morte, et le ping de
     * socket.io met une vingtaine de secondes à s'en apercevoir. On ne l'attend
     * pas — on relance la socket si elle est tombée, et on redemande
     * l'historique tout de suite.
     */
    const onVisibility = () => {
      if (document.visibilityState !== 'visible') return;
      if (!socket.connected) socket.connect();
      setResyncKey((n) => n + 1);
    };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', onVisibility);
      socket.emit('leave_room', roomId);
      socket.disconnect();
      socketRef.current = null;
      setConnected(false);
    };
  }, [roomId]);

  /**
   * Fusionner un historique fraîchement chargé avec ce qui est déjà à l'écran.
   * Le SEUL point d'entrée de l'historique HTTP, au montage comme après une
   * coupure.
   *
   * Écraser perdrait trois choses : un message arrivé par le socket pendant
   * que la requête était en vol, les messages optimistes encore en attente, et
   * tout ce qui est plus ancien que la fenêtre que renvoie l'API. Le serveur
   * fait foi sur les identifiants qu'il renvoie ; le tri se fait sur `sentAt`
   * parce que l'ordre d'arrivée d'une reconnexion ne veut plus rien dire.
   *
   * ⚠️ Connu et assumé : un message supprimé pendant l'absence n'est pas dans
   * l'historique rechargé, donc la fusion le laisse affiché jusqu'au prochain
   * `message_deleted` ou au prochain montage. C'est le prix de ne rien perdre.
   */
  const mergeMessages = useCallback((msgs: ChatMessage[]) => {
    setMessages((prev) => {
      const byId = new Map(prev.map((m) => [m.id, m]));
      for (const m of msgs) byId.set(m.id, m);
      return capMessages([...byId.values()].sort(
        (a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime(),
      ));
    });
  }, []);

  /** Optimistically add own message before the server confirms */
  const appendOptimistic = useCallback((msg: ChatMessage) => {
    setMessages((prev) => capMessages([...prev, msg]));
  }, []);

  /** Replace the optimistic message with the confirmed server version.
   *  Also removes any socket-delivered copy that may have arrived first
   *  (race: socket fires before the HTTP await resolves → double message). */
  const confirmMessage = useCallback((tempId: string, confirmed: ChatMessage) => {
    setMessages((prev) =>
      capMessages(
        prev.filter((m) => m.id !== confirmed.id && m.id !== tempId).concat(confirmed)
      )
    );
  }, []);

  /** Remove a message locally (optimistic delete before/without the socket event). */
  const removeMessage = useCallback((messageId: string) => {
    setMessages((prev) => prev.filter((m) => m.id !== messageId));
  }, []);

  return {
    messages, onlineCount, connected,
    mergeMessages, appendOptimistic, confirmMessage, removeMessage,
    resyncKey, authError, roomError,
  };
}
