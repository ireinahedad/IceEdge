/**
 * Palier du banc B15 — une soirée EN DIRECT, processus neuf.
 *
 * `V` spectateurs rafraîchissent la page d'un des `G` matchs en cours
 * (`GET /api/predict/game/:id/bundle`) pendant `S` secondes. Tout est le vrai
 * code : paquet d'avant-match (10 min), paquet en direct (30 s, dédoublonné en
 * vol), feuille de match NHL, calage, moteur des effets de score.
 */

import { boot, request, sustain, summarise } from './harness';
import * as upstream from './upstream';
import { emit, envInt } from './spawn';

export async function main() {
  const viewers = envInt('BENCH_VIEWERS', 100);
  const games = envInt('BENCH_LIVE_GAMES', 16);
  const seconds = envInt('BENCH_SECONDS', 75);
  const thinkMs = envInt('BENCH_THINK_MS', 1000);

  upstream.setLeague({ teams: 32, games, players: 20 });
  upstream.setLatency({ nhl: 120, odds: 200, ml: 300 });
  upstream.setGamesLive(true);

  const { base, metrics, close } = await boot({ sqlLatencyMs: 2 });
  const ids = Array.from({ length: games }, (_, i) => upstream.benchGameId(i));

  upstream.reset();
  metrics.resetMetrics();
  const { replies, iterations } = await sustain(
    viewers, seconds * 1000,
    (vu) => request(base, `/api/predict/game/${ids[(vu + Math.floor(Math.random() * 3)) % games]}/bundle`,
                    { discardBody: true }).then(r => [r]),
    thinkMs,
  );

  const snap = metrics.snapshotMetrics();
  const c = upstream.counts();
  const live = snap.caches['mlGameBundlesLive'] ?? { hits: 0, misses: 0, dedup: 0 };
  const pre = snap.caches['mlGameBundles'] ?? { hits: 0, misses: 0, dedup: 0 };
  const windows = Math.ceil(seconds / 30);
  emit({
    viewers, games, seconds, iterations,
    ...summarise(replies),
    rps: +(replies.length / seconds).toFixed(1),
    liveExecutions: live.misses, liveDedup: live.dedup, liveHits: live.hits,
    preExecutions: pre.misses,
    liveExecPerGamePerWindow: +(live.misses / games / windows).toFixed(2),
    nhl: c['nhl-web'] + c['nhl-stats'], ml: c.ml, odds: c.odds,
    nhlPerGamePerWindow: +((c['nhl-web'] + c['nhl-stats']) / games / windows).toFixed(1),
    eventLoopP99: (snap.eventLoop as any)?.p99Ms ?? null,
    rssMb: snap.memory.rssMb,
  });
  await close();
}
