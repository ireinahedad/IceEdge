import { Request, Response, NextFunction } from 'express';
import { verifyAccessToken } from '../services/auth.service';
import { isPro } from '../services/subscription.service';
import { UserRole } from '../types/user.type';
import { sendError } from '../httpError';

// -------------------------------------------------------
//  Require a valid JWT access token
// -------------------------------------------------------

export function authenticate(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization'];
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing or malformed Authorization header' });
    return;
  }

  const token = authHeader.slice(7);

  try {
    req.user = verifyAccessToken(token);
    next();
  } catch (err: any) {
    sendError(res, err, { fallbackStatus: 401 });
  }
}

// -------------------------------------------------------
//  Optional authentication (guest-friendly)
// -------------------------------------------------------
//  Attaches req.user when a valid Bearer token is present, but does NOT
//  reject anonymous requests: routes decide per-endpoint whether a user is
//  required. Used by read-only public endpoints (e.g. public chat rooms) that
//  should be visible to signed-out visitors while writes stay protected.
//
//  Note: a present-but-invalid/expired token still returns 401 so the client's
//  authedFetch can refresh and retry, rather than silently downgrading a
//  logged-in user to the guest view.

export function optionalAuthenticate(req: Request, res: Response, next: NextFunction): void {
  const authHeader = req.headers['authorization'];
  if (!authHeader?.startsWith('Bearer ')) {
    next(); // no credentials → treat as guest
    return;
  }

  const token = authHeader.slice(7);
  try {
    req.user = verifyAccessToken(token);
    next();
  } catch (err: any) {
    sendError(res, err, { fallbackStatus: 401 });
  }
}

// -------------------------------------------------------
//  Require specific role(s)
// -------------------------------------------------------

export function requireRole(...roles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthenticated' });
      return;
    }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ error: 'Insufficient permissions' });
      return;
    }
    next();
  };
}

// -------------------------------------------------------
//  Require an active Pro subscription (admins always pass)
// -------------------------------------------------------
//  Use after `authenticate`. Checks the DB so a downgrade takes effect
//  immediately rather than waiting for the 15-min access token to expire.

export async function requirePro(req: Request, res: Response, next: NextFunction): Promise<void> {
  if (!req.user) {
    res.status(401).json({ error: 'Unauthenticated' });
    return;
  }
  try {
    if (req.user.role === 'admin' || (await isPro(req.user.sub))) {
      next();
      return;
    }
    res.status(402).json({ error: 'Pro subscription required', code: 'PRO_REQUIRED' });
  } catch (err: any) {
    sendError(res, err);
  }
}

// -------------------------------------------------------
//  Require the caller to be the resource owner OR admin
// -------------------------------------------------------

export function requireOwnerOrAdmin(req: Request, res: Response, next: NextFunction): void {
  const { user } = req;
  const targetId = req.params.id;

  if (!user) {
    res.status(401).json({ error: 'Unauthenticated' });
    return;
  }

  if (user.role === 'admin' || user.sub === targetId) {
    next();
  } else {
    res.status(403).json({ error: 'Forbidden' });
  }
}