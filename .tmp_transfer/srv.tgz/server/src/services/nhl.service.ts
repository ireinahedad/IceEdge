/**
 * nhl.service.ts
 * All NHL data is fetched live from the official NHL Stats API via nhlApiClient.
 * The DB is only used for user-specific records (bets, profiles, chat).
 */

import * as nhlApi from './nhlApiClient';
import { boxscoreLiveInfo } from './nhlPredictions';

export class NHLService {

  // --- Games ----------------------------------------------------------------

  async getGamesByDate(date?: string) {
    const d = date || new Date().toISOString().split('T')[0];
    return nhlApi.fetchGamesByDate(d);
  }

  async getGamesRange(start: string, end: string) {
    return nhlApi.fetchGamesRange(start, end);
  }

  async getPastGames(q: Parameters<typeof nhlApi.fetchPastGames>[0]) {
    return nhlApi.fetchPastGames(q);
  }

  async getScheduleAnchor() {
    return nhlApi.fetchScheduleAnchor();
  }

  async getLiveGames() {
    return nhlApi.fetchLiveGames();
  }

  async getGame(id: string) {
    return nhlApi.fetchGameById(id);
  }

  async getGameDetail(id: string) {
    return nhlApi.fetchGameDetail(id);
  }

  // --- Teams ----------------------------------------------------------------

  async getTeams() {
    return nhlApi.fetchTeams();
  }

  async getTeamStats(id: string) {
    const t = await nhlApi.fetchTeamByAbbr(id);
    // PP% / PK% : `standings` ne les porte PAS (powerPlayPctg/penaltyKillPctg y
    // sont absents, d'où le 0 de fetchTeams), ils vivent dans team/summary. Sans
    // cette fusion, la page d'une équipe affichait « PK% — » et calculait ses
    // règles spéciales sur 0 % — le moteur de prédiction, lui, lisait déjà la
    // bonne source, ce qui faisait dire deux chiffres différents au même écran.
    // Le try/catch est là pour que le reste de la fiche sorte quand même si
    // team/summary tombe (il expire au bout de 8 s comme les autres appels).
    let summary: { ppPct: number; pkPct: number } | undefined;
    try {
      summary = (await nhlApi.fetchTeamSummaryStats())[t.abbreviation];
    } catch { /* PP/PK indisponibles : on reste sur ce que porte le standings */ }
    return {
      teamId:              t.id,
      name:                t.name,
      abbreviation:        t.abbreviation,
      city:                t.city,
      conference:          t.conference,
      division:            t.division,
      color:               t.color,
      emoji:               t.emoji,
      gamesPlayed:         t.gamesPlayed,
      wins:                t.wins,
      losses:              t.losses,
      otLosses:            t.otLosses,
      points:              t.points,
      goalsFor:            t.goalsFor,
      goalsAgainst:        t.goalsAgainst,
      goalsForPerGame:     t.goalsForPerGame,
      goalsAgainstPerGame: t.goalsAgainstPerGame,
      powerPlayPct:        t.ppPct || summary?.ppPct || 0,
      penaltyKillPct:      t.pkPct || summary?.pkPct || 0,
      homeRecord:          t.homeRecord,
      awayRecord:          t.awayRecord,
      streak:              t.streak,
      winPct:              t.winPct,
    };
  }

  async getTeamLastNGames(id: string, n: number) {
    const stats = await this.getTeamStats(id);
    const gp    = stats.gamesPlayed || 1;
    const ratio = n / gp;
    return {
      ...stats,
      gamesPlayed:  n,
      wins:         Math.round(stats.wins         * ratio),
      losses:       Math.round(stats.losses       * ratio),
      goalsFor:     Math.round(stats.goalsFor     * ratio),
      goalsAgainst: Math.round(stats.goalsAgainst * ratio),
    };
  }

  // --- Players --------------------------------------------------------------

  async searchPlayers(q: string) {
    return nhlApi.searchPlayers(q);
  }

  async getAllPlayerStats() {
    return nhlApi.fetchTopPlayers();
  }

  async getTeamRoster(abbr: string) {
    return nhlApi.fetchTeamRoster(abbr);
  }

  async getTeamPlayerSeasons(abbr: string) {
    return nhlApi.fetchTeamPlayerSeasons(abbr);
  }

  async getTeamOpponentSplits(abbr: string, season: string) {
    return nhlApi.fetchTeamOpponentSplits(abbr, season);
  }

  async getTeamSeasonOfficial(abbr: string, season: string) {
    return nhlApi.fetchTeamSeasonOfficial(abbr, season);
  }

  async getHeadToHeadSeason(abbr: string, opp: string, season: string) {
    return nhlApi.fetchHeadToHeadSeason(abbr, opp, season);
  }

  async getAllTeamsSeason(season?: string) {
    return nhlApi.fetchAllTeamsSeason(season);
  }

  async getPlayerLeaders(
    season: string | undefined,
    view: 'skater' | 'goalie',
    sort: string,
    limit: number,
  ) {
    return nhlApi.fetchPlayerLeaders(season, view, sort, limit);
  }

  /**
   * Feuille de match en direct : les compteurs de CHAQUE joueur pour CE match.
   *
   * Sert les grilles de paris joueur pendant la partie — un pari « 2+ buts »
   * n'a pas le même sens quand le joueur en a déjà un. La `Map` interne devient
   * un objet indexé, parce qu'une `Map` ne survit pas à `JSON.stringify`.
   *
   * `state` accompagne les lignes : c'est lui qui décide du `Cache-Control` de
   * la route (30 s en direct, 6 h une fois terminé), et l'écran s'en sert pour
   * n'afficher un compteur « en direct » que lorsqu'il l'est vraiment.
   */
  async getGameBoxscore(gameId: string) {
    const full = await nhlApi.fetchGameBoxscoreFull(gameId);
    if (!full) return { state: 'unknown' as const, players: {} };
    // Match commencé : temps restant et premier buteur, pour que les grilles
    // recalculent leurs seuils (« 2+ buts » quand le joueur en a déjà un).
    // Feuille du match illisible → pas de `live`, et la grille affiche « — ».
    let live: ReturnType<typeof boxscoreLiveInfo> = null;
    if (full.state === 'live' || full.state === 'final') {
      try { live = boxscoreLiveInfo(await nhlApi.fetchGameDetail(gameId)); } catch { live = null; }
    }
    return {
      state: full.state,
      players: Object.fromEntries(full.players),
      ...(live ? { live } : {}),
    };
  }

  async getPlayer(id: string) {
    return nhlApi.fetchPlayerById(id);
  }

  async getPlayerStats(id: string) {
    const p = await nhlApi.fetchPlayerById(id);
    return {
      playerId:         p.id,
      fullName:         p.name,
      teamAbbr:         p.teamAbbr,
      // `season` était `null` en dur. C'est la saison de ces chiffres, et elle
      // n'est plus devinable : en avant-saison, les totaux sont ceux de la
      // dernière saison complète (voir `pickSeasonRow`). L'écran doit pouvoir
      // la dater — « 32 buts » sans année, sur une page qui parle du match de
      // ce soir, se lit comme « 32 buts cette saison ».
      season:           p.statsSeason ?? null,
      statsSeason:      p.statsSeason ?? null,
      gamesPlayed:      p.gamesPlayed,
      goals:            p.goals,
      assists:          p.assists,
      points:           p.points,
      plusMinus:        p.plusMinus,
      shots:            p.shots,
      shootingPct:      p.shotPct,
      powerPlayGoals:   null,
      powerPlayPoints:  p.ppPoints,
      shortHandedGoals: null,
      // ⚠️ Ces quatre champs étaient écrits `null` EN DUR, alors que
      // `fetchPlayerById` les remonte (`penaltyMinutes`, `avgToi`) ou les
      // remonte depuis le câblage du rapport `realtime` (`blockedShots`,
      // `hits`). Ce DTO les jetait juste avant la sortie.
      //
      // Conséquence à l'écran : `PlayerPrediction` garde ses groupes de marchés
      // « Blocked Shots », « Hits » et « Penalty Minutes » derrière un `> 0`
      // sur ces valeurs. `null ?? 0` valant 0, la garde était toujours fausse —
      // trois groupes de paris écrits et jamais rendus une seule fois. Le
      // commentaire de `fetchPlayerById` explique même que `pim` et `avgToi`
      // avaient été ajoutés exprès ; ils n'ont jamais traversé cette couche.
      penaltyMinutes:   p.penaltyMinutes ?? null,
      blockedShots:     p.blockedShots ?? null,
      hits:             p.hits ?? null,
      timeOnIce:        p.avgToi ?? null,
      faceoffWinPct:    null,
      // Gardien (null pour un patineur) — l'en-tête de la page gardien montrait
      // buts / passes / +/- d'un patineur (2026-10-05).
      savePct:          p.savePct ?? null,
      goalsAgainstAvg:  p.goalsAgainstAvg ?? null,
      wins:             p.wins ?? null,
      shutouts:         p.shutouts ?? null,
      lastFive:         p.lastFive,
      winImpact:        p.winImpact,
    };
  }

  // --- Standings ------------------------------------------------------------

  async getStandings() {
    const teams = await nhlApi.fetchTeams();
    const grouped: Record<string, any> = {};

    for (const t of teams) {
      const key = `${t.conference}-${t.division}`;
      if (!grouped[key]) {
        grouped[key] = { conference: t.conference, division: t.division, teams: [] };
      }
      grouped[key].teams.push({
        rank: grouped[key].teams.length + 1,
        team: {
          id:           t.id,
          name:         t.name,
          abbreviation: t.abbreviation,
          emoji:        t.emoji,
        },
        stats: {
          gamesPlayed:      t.gamesPlayed,
          wins:             t.wins,
          losses:           t.losses,
          otLosses:         t.otLosses,
          points:           t.points,
          winPct:           t.winPct,
          goalDifferential: t.goalsFor - t.goalsAgainst,
          streak:           t.streak,
        },
      });
    }
    return Object.values(grouped);
  }
}
