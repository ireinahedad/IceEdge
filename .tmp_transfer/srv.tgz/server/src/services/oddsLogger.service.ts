// ============================================================
//  Odds logger — journalise les cotes NHL du jour pour le ML
// ============================================================
// The Odds API n'archive pas l'historique gratuitement (les cotes publiques
// s'arrêtent en 2022-23). Pour pouvoir réentraîner et backtester le modèle sur
// les saisons récentes, on capture chaque jour les cotes de clôture NHL.
//
// STOCKAGE : table `odds_log` (migration 027), et non plus un CSV. Le disque de
// Railway est éphémère : le fichier disparaissait à chaque déploiement, donc le
// job donnait l'illusion de collecter sans jamais rien accumuler. L'export vers
// le format attendu par fetch_data_v4.py se fait à la demande
// (`npm run odds:export`), depuis une donnée qui, elle, survit.
//
// SÉRIE TEMPORELLE (A3, 2026-08-23) : chaque passe archive en plus son état
// dans `odds_snapshots` (migration 031). `odds_log` écrase — il ne garde qu'une
// ouverture et une clôture — alors que le CLV a besoin de savoir quel prix était
// affiché à un instant donné. Le calendrier des passes vit dans `SLOTS`, en bas
// de ce fichier, avec le raisonnement sur le quota qui lui donne sa forme.
//
// Activé via ODDS_LOG_ENABLED=true.
// Sans clé The Odds API (ODDS_API_KEY) le job se désactive proprement.

import { pool } from '../db/connection';
import { fetchCollectorOdds, ODDS_COLLECT_BOOKMAKERS, ODDS_SHADOW_BOOKMAKERS,
         type RawOddsEvent } from './oddsClient';
import { toAbbr } from './oddsTeamNames';
import { logger } from '../logger';
import { withJobLock } from './jobLock';
import * as oddsQuota from './oddsQuota';

/** Un appel Odds API + un upsert. Généreux pour un upstream lent. */
const LOCK_TTL_MS = 5 * 60 * 1000;

/**
 * Coût d'une passe, en crédits The Odds API : 1 par marché et par région.
 *
 * `full` et `close` demandent tous deux h2h + spreads depuis le 2026-10-01
 * (avant : `full` ajoutait les totaux, clos pour de bon). Jusqu'au 2026-09-27 la passe du soir s'appelait `spreads`
 * et ne prenait que la puck line (1 crédit), contrainte du quota gratuit.
 * Voir `SLOTS`.
 */
const COLLECT_COST: Record<PassKind, number> = { full: 2, close: 2 };

/** Marchés demandés à The Odds API pour chaque passe. */
const PASS_MARKETS: Record<PassKind, string> = {
  // Depuis le 2026-10-01 (décision du user) : moneyline + puck line ±1.5
  // seulement, sur tous les matchs. Les totaux ne sont plus collectés.
  full: 'h2h,spreads',
  close: 'h2h,spreads',
};

/** Quels marchés une passe demande. Stocké tel quel dans `odds_snapshots`. */
export type PassKind = 'full' | 'close';

/** L'état `active` d'une ligue change au plus une fois par jour. */
let seasonCache: { active: boolean; at: number } | null = null;
const SEASON_TTL_MS = 6 * 60 * 60 * 1000;

/**
 * La NHL est-elle en cours ? Consulté avant toute dépense.
 *
 * `/v4/sports` est explicitement **hors quota** côté fournisseur : ce contrôle
 * est donc gratuit, et il évite de payer quatre appels par jour pendant les
 * quatre mois d'intersaison. En cas d'échec réseau on répond `true` — mieux
 * vaut une passe inutile qu'une saison entière ratée sur une erreur transitoire.
 */
async function isSeasonActive(): Promise<boolean> {
  if (seasonCache && Date.now() - seasonCache.at < SEASON_TTL_MS) {
    return seasonCache.active;
  }
  try {
    const res = await fetch(
      `https://api.the-odds-api.com/v4/sports?apiKey=${process.env.ODDS_API_KEY}`,
    );
    if (!res.ok) {
      // Le repli reste inchangé — mieux vaut une passe inutile qu'une saison
      // ratée. Mais un 401/403 n'est pas un incident transitoire : c'est une
      // clé morte, et sans cette ligne elle ne se manifesterait qu'au premier
      // jour de matchs, en `[OddsLogger] échec` sans cause désignée.
      // ⚠️ On ne journalise QUE le statut : l'URL ci-dessus porte la clé en
      // clair dans sa query string et ne doit jamais être écrite dans un log.
      if (res.status === 401 || res.status === 403) {
        logger.error(
          { status: res.status },
          '[OddsLogger] ⚠️ ODDS_API_KEY REFUSÉE par The Odds API — collecte et proxy hors service',
        );
      }
      return true;
    }
    const sports = (await res.json()) as Array<{ key: string; active: boolean }>;
    const nhl = sports.find((s) => s.key === 'icehockey_nhl');
    const active = nhl?.active !== false;
    seasonCache = { active, at: Date.now() };
    return active;
  } catch {
    return true;
  }
}

/** La sonde de démarrage ne doit pas retarder l'écoute du serveur. */
const KEY_PROBE_TIMEOUT_MS = 5_000;

/**
 * Sonde de démarrage : la clé The Odds API est-elle encore acceptée ?
 *
 * **Pourquoi elle existe.** Trois contrôles prétendaient couvrir cette clé et
 * aucun ne testait sa validité : la bannière `[Server] Réglages effectifs`
 * imprime `ODDS_API_KEY: présente` sur la seule présence de la variable,
 * `startOddsLogger()` teste exactement la même chose, et `isSeasonActive()`
 * répond « en saison » sur n'importe quel échec. Une clé révoquée passait donc
 * au vert au démarrage et ne se manifestait qu'au premier jour de matchs —
 * jusqu'à quatre mois plus tard si la révocation tombait hors saison. C'est le
 * défaut corrigé côté R2 par `verifyAvatarStorage()`, dont cette fonction
 * reprend la forme et les trois issues distinctes.
 *
 * **Elle est gratuite** : `/v4/sports` est explicitement hors quota côté
 * fournisseur (cf. `isSeasonActive`). Lancée sans `await` depuis `server.ts` :
 * elle ne doit ni retarder l'écoute, ni pouvoir empêcher le démarrage.
 *
 * ⚠️ **Sécurité.** L'URL porte la clé en clair dans sa query string. Ne jamais
 * journaliser l'URL, l'erreur brute, ni `err.cause` — uniquement le statut HTTP
 * et le nom de l'erreur, qui ne peuvent pas la contenir.
 */
export async function verifyOddsApiKey(): Promise<void> {
  // Absente : la bannière de démarrage le dit déjà, et il n'y a rien à sonder.
  if (!process.env.ODDS_API_KEY) return;

  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), KEY_PROBE_TIMEOUT_MS);

  try {
    const res = await fetch(
      `https://api.the-odds-api.com/v4/sports?apiKey=${process.env.ODDS_API_KEY}`,
      { signal: abort.signal },
    );

    if (res.ok) {
      logger.info('[OddsLogger] ✅ ODDS_API_KEY acceptée par The Odds API');
    } else if (res.status === 401 || res.status === 403) {
      logger.error(
        { status: res.status },
        '[OddsLogger] ⚠️ ODDS_API_KEY REFUSÉE — clé révoquée, expirée, ou absente de ce compte. '
          + 'La collecte de cotes et le proxy /api/odds sont hors service.',
      );
    } else {
      logger.warn(
        { status: res.status },
        '[OddsLogger] ODDS_API_KEY non vérifiable — réponse inattendue de The Odds API',
      );
    }
  } catch (err: any) {
    // Réseau, DNS, ou délai dépassé : on ne peut pas conclure, et surtout pas
    // conclure à une clé morte. Non concluant n'est pas rouge.
    logger.warn(
      { err: err?.name, timedOut: abort.signal.aborted },
      '[OddsLogger] ODDS_API_KEY non vérifiable — The Odds API injoignable au démarrage',
    );
  } finally {
    clearTimeout(timer);
  }
}

// Colonnes attendues par fetch_data_v4.py (identiques à odds.csv).
// `source` permet de distinguer ces lignes de celles de l'archive SBRO : les
// deux sources n'ont ni le même bookmaker ni la même marge, et un ROI qui
// n'apparaîtrait que d'un côté de la jointure serait un artefact de source.
const HEADER =
  'date,home_team,away_team,home_ml_open,away_ml_open,home_ml_close,away_ml_close,' +
  'total_open,total_close,total_open_over,total_open_under,' +
  'total_close_over,total_close_under,puck_line_home,pl_home_price,pl_away_price,source';

/** Date locale (Est) du match au format YYYY-MM-DD — cohérent avec le spine NHL. */
function easternDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}

/** Ordre de préférence du livre de collecte (`ODDS_COLLECT_BOOKMAKERS`). */
const COLLECT_BOOKS = ODDS_COLLECT_BOOKMAKERS.split(',').map((b) => b.trim()).filter(Boolean);

/**
 * Le livre qui fournit `market` pour cet événement, choisi STRICTEMENT dans
 * `books` (ordre de préférence), ou null.
 *
 * Jusqu'au 2026-10-04 la fonction retombait sur « le premier livre venu ».
 * C'était sans effet tant que l'appel ne demandait que le livre de collecte ;
 * depuis que la même réponse porte aussi les livres parallèles
 * (`ODDS_SHADOW_BOOKMAKERS`), ce repli aurait versé des prix BET99 dans la
 * série DraftKings du CLV pour chaque match que DraftKings ne cote pas.
 */
function pickBook(ev: RawOddsEvent, market: string, books: string[]) {
  const withMkt = ev.bookmakers.filter((b) => b.markets.some((m) => m.key === market));
  for (const key of books) {
    const hit = withMkt.find((b) => b.key === key);
    if (hit) return hit;
  }
  return null;
}

interface Row {
  date: string; home: string; away: string;
  /**
   * Mise au jeu, telle que renvoyée par l'API. Indispensable au CLV : les
   * matchs d'une même soirée commencent entre 19 h et 22 h 30 ET, donc le
   * « T−3 h » et le « dernier prix avant le début » sont propres à chaque
   * match et ne se déduisent pas de `date`.
   */
  commenceTime: string;
  homeMl: number | null; awayMl: number | null; total: number | null;
  // Marchés dérivés (2026-08-04). Sans ces PRIX, aucun ROI n'est calculable
  // sur les totaux ni la puck line — c'est-à-dire précisément les marchés que
  // le modèle de score price le mieux et les seuls encore ouverts.
  totalOver: number | null; totalUnder: number | null;
  puckLineHome: number | null;
  plHomePrice: number | null; plAwayPrice: number | null;
  /**
   * Livre qui a fourni le prix (moneyline, sinon puck line, sinon total).
   * Archivé dans `odds_snapshots.bookmaker` (migration 038) : sans lui, un
   * changement de `ODDS_COLLECT_BOOKMAKERS` en cours de saison mélangerait
   * deux sources dans la série du CLV sans que rien ne le montre.
   */
  bookmaker: string | null;
}

/**
 * Marge admissible d'un marché à DEUX issues (moneyline, puck line ±1.5) :
 * 1/c_dom + 1/c_ext. Un vrai prix à deux issues tombe vers 1.03-1.07.
 *
 * Trouvé le 2026-10-12 (STATUS.md §3.5 P) : les observations d'août-septembre
 * 2026, sans livre archivé, sortaient à 0.79-0.88 — un marché « 60 minutes »
 * à trois issues dont on ne lisait que deux prix, ou deux livres mélangés.
 * Dévigé par normalisation, ça donnait une probabilité fausse sans que rien ne
 * le signale. On jette la paire plutôt que de la stocker.
 */
export const TWO_WAY_OVERROUND: readonly [number, number] = [1.0, 1.12];

export function isValidTwoWay(a: number | null | undefined, b: number | null | undefined): boolean {
  if (a == null || b == null || !(a > 1) || !(b > 1)) return false;
  const o = 1 / a + 1 / b;
  return o >= TWO_WAY_OVERROUND[0] && o <= TWO_WAY_OVERROUND[1];
}

/** Paires jetées par `isValidTwoWay` pendant la passe en cours (pour le log). */
let rejectedPairs = 0;

/** Convertit un événement en ligne loggable, prix lus chez `books` seulement. */
function eventToRow(ev: RawOddsEvent, books: string[] = COLLECT_BOOKS): Row | null {
  const home = toAbbr(ev.home_team);
  const away = toAbbr(ev.away_team);
  if (!home || !away) return null;

  let homeMl: number | null = null, awayMl: number | null = null, total: number | null = null;
  let totalOver: number | null = null, totalUnder: number | null = null;
  let puckLineHome: number | null = null;
  let plHomePrice: number | null = null, plAwayPrice: number | null = null;

  const h2hBook = pickBook(ev, 'h2h', books);
  const h2h = h2hBook?.markets.find((m) => m.key === 'h2h');
  if (h2h) {
    const oh = h2h.outcomes.find((o) => o.name.toLowerCase() === ev.home_team.toLowerCase());
    const oa = h2h.outcomes.find((o) => o.name.toLowerCase() === ev.away_team.toLowerCase());
    homeMl = oh?.price ?? null;
    awayMl = oa?.price ?? null;
    if ((homeMl != null || awayMl != null) && !isValidTwoWay(homeMl, awayMl)) {
      rejectedPairs += 1;
      homeMl = null;
      awayMl = null;
    }
  }

  const totBook = pickBook(ev, 'totals', books);
  const totals = totBook?.markets.find((m) => m.key === 'totals');
  if (totals) {
    const over  = totals.outcomes.find((o) => /over/i.test(o.name));
    const under = totals.outcomes.find((o) => /under/i.test(o.name));
    total = typeof over?.point === 'number' ? over!.point : null;
    totalOver  = over?.price  ?? null;
    totalUnder = under?.price ?? null;
  }

  // Puck line : `point` du côté domicile est SON handicap (−1.5 s'il est
  // favori, +1.5 sinon). On ne retient que la ligne standard : les lignes
  // alternatives (±2.5) sont un autre marché et les mélanger dans la même
  // colonne rendrait le règlement ambigu au moment du backtest.
  const spBook = pickBook(ev, 'spreads', books);
  const spreads = spBook?.markets.find((m) => m.key === 'spreads');
  if (spreads) {
    const oh = spreads.outcomes.find((o) => o.name.toLowerCase() === ev.home_team.toLowerCase());
    const oa = spreads.outcomes.find((o) => o.name.toLowerCase() === ev.away_team.toLowerCase());
    if (typeof oh?.point === 'number' && Math.abs(Math.abs(oh.point) - 1.5) < 1e-9) {
      if (isValidTwoWay(oh.price, oa?.price)) {
        puckLineHome = oh.point;
        plHomePrice  = oh.price ?? null;
        plAwayPrice  = oa?.price ?? null;
      } else {
        rejectedPairs += 1;
      }
    }
  }

  // Une passe `close` ne ramène pas de total : refuser la ligne sur l'absence
  // d'un seul marché jetterait ce qu'on est venu chercher.
  if (homeMl == null && total == null && puckLineHome == null) return null;
  return {
    date: easternDate(ev.commence_time), home, away,
    commenceTime: ev.commence_time,
    homeMl, awayMl, total,
    totalOver, totalUnder, puckLineHome, plHomePrice, plAwayPrice,
    bookmaker: (h2hBook ?? spBook ?? totBook)?.key ?? null,
  };
}

/**
 * Capture les cotes du jour dans `odds_log`.
 *
 * IDEMPOTENCE — la clé primaire (game_date, home_team, away_team) la porte : le
 * job peut tourner autant de fois qu'on veut, y compris depuis deux instances,
 * sans créer de doublon. C'est ce qui remplace la relecture intégrale du CSV à
 * chaque exécution, dont le coût croissait avec la saison.
 *
 * OUVERTURE / CLÔTURE — la première passe d'une journée écrit les deux ; les
 * suivantes ne mettent à jour que la clôture. Le mouvement de cote entre la
 * première observation et la dernière est le signal que le CSV ne pouvait pas
 * capturer (il écrivait open = close et n'y revenait jamais).
 *
 * SNAPSHOTS (A3, 2026-08-23) — en plus de l'upsert ci-dessus, chaque passe
 * insère son état complet dans `odds_snapshots`. Le résumé ouverture/clôture
 * reste le contrat de `fetch_data_v4.py` et ne bouge pas ; la série temporelle
 * est ce que le CLV réclame, et elle ne coûte aucun crédit supplémentaire —
 * l'appel ramenait déjà ces prix, le collecteur les jetait.
 *
 * @param kind `full` ou `close` — h2h + spreads, 2 crédits chacune depuis le
 *             2026-10-01. Voir `SLOTS` pour le calendrier.
 * @returns nombre de lignes écrites ou mises à jour dans `odds_log`.
 */
export async function logTodaysOdds(kind: PassKind = 'full'): Promise<number> {
  // ── Deux garde-fous AVANT de dépenser le moindre crédit ───────────────────
  //
  // 1. La saison est-elle en cours ? L'endpoint /v4/sports est gratuit (il ne
  //    décompte aucun crédit) et porte un booléen `active` par ligue. Sans ce
  //    contrôle, l'intersaison — de juin à début octobre — brûle ~4 appels par
  //    jour pour ramener une liste vide, soit plus de 1 000 crédits sur un
  //    quota mensuel de 500. C'est l'économie la plus facile du lot.
  if (!(await isSeasonActive())) {
    logger.info('[OddsLogger] NHL inactive — aucun crédit dépensé.');
    return 0;
  }

  // 2. Reste-t-il assez de crédits SANS entamer la réserve des visiteurs ?
  //    Le collecteur cède toujours : une journée de collecte manquée est une
  //    perte pour le futur modèle, une page vide est une perte immédiate pour
  //    quelqu'un qui est là maintenant.
  if (!(await oddsQuota.collectorMaySpend(COLLECT_COST[kind]))) {
    logger.warn({ remaining: oddsQuota.remaining(), kind },
      '[OddsLogger] réserve visiteurs atteinte — collecte suspendue ce cycle.');
    return 0;
  }

  const fetched = await fetchCollectorOdds(PASS_MARKETS[kind]);
  if (!fetched.length) return 0;

  // Un seul horodatage pour toute la passe, calculé ici et non par `NOW()`
  // ligne à ligne : c'est ce qui rend « l'état du marché à 18 h 45 »
  // regroupable, au lieu d'horodatages qui diffèrent de quelques millisecondes.
  const observedAt = new Date();

  // AVANT-MATCH SEULEMENT (2026-10-12). `/odds` renvoie aussi les matchs EN
  // COURS : les passes de 21 h 45 et 22 h 45 ET tombent en plein match de 19 h,
  // et leurs prix écrasaient la clôture — 1.00 / 31.00 pour NYI–NJD le
  // 2026-10-03, observé deux heures après la mise au jeu. Une clôture
  // en direct contient le score : c'est une fuite pour tout backtest et tout CLV.
  // Les snapshots n'en gardent pas non plus : rien ne s'en sert, et un lecteur
  // distrait les prendrait pour des prix d'avant-match.
  const events = fetched.filter((ev) => Date.parse(ev.commence_time) > observedAt.getTime());
  const inPlay = fetched.length - events.length;
  rejectedPairs = 0;

  const rows: Row[] = [];
  const shadowRows: Row[] = [];
  const seen = new Set<string>();
  for (const ev of events) {
    // Livres parallèles : une ligne par livre, pour `odds_snapshots` seulement.
    for (const book of ODDS_SHADOW_BOOKMAKERS) {
      const sr = eventToRow(ev, [book]);
      if (!sr) continue;
      const skey = `${sr.date}|${sr.home}|${sr.away}|${book}`;
      if (seen.has(skey)) continue;
      seen.add(skey);
      shadowRows.push(sr);
    }
    const r = eventToRow(ev);
    if (!r) continue;
    // The Odds API peut renvoyer deux entrées pour le même match (marchés
    // séparés) : on garde la première, la clé primaire ferait le reste mais
    // autant ne pas envoyer deux fois la même ligne.
    const key = `${r.date}|${r.home}|${r.away}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push(r);
  }
  if (inPlay || rejectedPairs) {
    logger.info({ kind, inPlay, rejectedPairs },
      '[OddsLogger] matchs en cours ignorés / paires de prix impossibles jetées');
  }

  // `odds_log` : LE JOUR DU MATCH SEULEMENT (2026-10-12). L'ouverture était la
  // toute première observation, parfois cinq semaines avant le match (et chez
  // un livre inconnu avant la migration 038) ; et un match qu'aucune passe du
  // jour n'avait vu gardait comme « clôture » ce prix d'août. L'ouverture utile
  // est la passe de 11 h ET du jour (cf. `SLOTS`). La série complète, elle,
  // reste dans `odds_snapshots`.
  const today = easternDate(observedAt.toISOString());
  const logRows = rows.filter((r) => r.date === today);

  if (!logRows.length) {
    // Le livre de collecte ne cote rien aujourd'hui : rien pour `odds_log`,
    // mais la série (autres jours, livres parallèles) garde son point.
    if (rows.length || shadowRows.length) await insertSnapshots([...rows, ...shadowRows], observedAt, kind);
    return 0;
  }

  // Un seul aller-retour pour toute la journée : `unnest` déplie les tableaux
  // en lignes côté Postgres. Une boucle d'INSERT aurait fait ~15 requêtes pour
  // une donnée qui tient dans une.
  // Les colonnes d'OUVERTURE reçoivent la même valeur à l'insertion et ne sont
  // jamais réécrites ; seules les colonnes de CLÔTURE sont mises à jour aux
  // passes suivantes. L'écart entre les deux EST le mouvement de cote, et
  // c'est lui qu'on cherche à capturer — pas seulement le prix final.
  const res = await pool.query(
    `INSERT INTO odds_log (game_date, home_team, away_team,
                           home_ml_open, away_ml_open, home_ml_close, away_ml_close,
                           total_open, total_close,
                           total_open_over, total_open_under,
                           total_close_over, total_close_under,
                           puck_line_home,
                           pl_home_price_open, pl_away_price_open,
                           pl_home_price, pl_away_price)
     SELECT * FROM unnest(
       $1::date[], $2::text[], $3::text[],
       $4::numeric[], $5::numeric[], $4::numeric[], $5::numeric[],
       $6::numeric[], $6::numeric[],
       $7::numeric[], $8::numeric[],
       $7::numeric[], $8::numeric[],
       $9::numeric[],
       $10::numeric[], $11::numeric[],
       $10::numeric[], $11::numeric[]
     )
     ON CONFLICT (game_date, home_team, away_team) DO UPDATE SET
       -- L'ouverture ne se réécrit JAMAIS quand elle existe (l'argument de
       -- gauche gagne) — mais elle se remplit si elle était nulle. Deux cas
       -- réels le demandent : un book qui n'a pas encore affiché un marché lors
       -- de la première passe, et une journée dont la première passe est une
       -- passe 'close' (démarrage du serveur en soirée), qui ne rapporte pas
       -- de total. Sans ce rattrapage, ces colonnes restaient nulles
       -- pour toujours, puisque seules les colonnes de clôture étaient mises à
       -- jour.
       home_ml_open      = COALESCE(odds_log.home_ml_open,      EXCLUDED.home_ml_open),
       away_ml_open      = COALESCE(odds_log.away_ml_open,      EXCLUDED.away_ml_open),
       total_open        = COALESCE(odds_log.total_open,        EXCLUDED.total_open),
       total_open_over   = COALESCE(odds_log.total_open_over,   EXCLUDED.total_open_over),
       total_open_under  = COALESCE(odds_log.total_open_under,  EXCLUDED.total_open_under),
       pl_home_price_open = COALESCE(odds_log.pl_home_price_open, EXCLUDED.pl_home_price_open),
       pl_away_price_open = COALESCE(odds_log.pl_away_price_open, EXCLUDED.pl_away_price_open),
       home_ml_close     = COALESCE(EXCLUDED.home_ml_close,     odds_log.home_ml_close),
       away_ml_close     = COALESCE(EXCLUDED.away_ml_close,     odds_log.away_ml_close),
       total_close       = COALESCE(EXCLUDED.total_close,       odds_log.total_close),
       total_close_over  = COALESCE(EXCLUDED.total_close_over,  odds_log.total_close_over),
       total_close_under = COALESCE(EXCLUDED.total_close_under, odds_log.total_close_under),
       -- La ligne de puck line peut bouger (le favori change de camp) : on
       -- suit la dernière observée, comme pour la ligne de total.
       puck_line_home    = COALESCE(EXCLUDED.puck_line_home,    odds_log.puck_line_home),
       pl_home_price     = COALESCE(EXCLUDED.pl_home_price,     odds_log.pl_home_price),
       pl_away_price     = COALESCE(EXCLUDED.pl_away_price,     odds_log.pl_away_price),
       updated_at        = NOW()`,
    [...keyColumns(logRows), ...priceColumns(logRows)],
  );

  await insertSnapshots([...rows, ...shadowRows], observedAt, kind);
  return res.rowCount ?? 0;
}

/** Colonnes d'identité d'un match pour `unnest` : date, domicile, extérieur. */
function keyColumns(rows: Row[]) {
  return [rows.map((r) => r.date), rows.map((r) => r.home), rows.map((r) => r.away)];
}

/** Colonnes de prix pour `unnest`, dans l'ordre commun à `odds_log` et `odds_snapshots`. */
function priceColumns(rows: Row[]) {
  return [
    rows.map((r) => r.homeMl),
    rows.map((r) => r.awayMl),
    rows.map((r) => r.total),
    rows.map((r) => r.totalOver),
    rows.map((r) => r.totalUnder),
    rows.map((r) => r.puckLineHome),
    rows.map((r) => r.plHomePrice),
    rows.map((r) => r.plAwayPrice),
  ];
}

/**
 * Archive l'état du marché à un instant donné (A3).
 *
 * Complémentaire de `odds_log`, qui écrase : ici rien n'est jamais réécrit, on
 * empile. C'est la seule forme qui permette de répondre à « quel prix était
 * affiché quand le modèle aurait misé, et où la ligne a-t-elle fini ? ».
 *
 * `ON CONFLICT DO NOTHING` plutôt qu'un upsert : deux exécutions concurrentes
 * du même créneau — que `withJobLock` empêche déjà — ne doivent pas se
 * réécrire l'une l'autre. Un snapshot est un fait observé, pas un état courant.
 *
 * Un échec ici ne fait pas échouer la passe : `odds_log` est déjà écrit, et
 * c'est lui qui alimente le pipeline ML existant. Perdre un point de série
 * temporelle est regrettable, perdre la clôture du jour l'est bien davantage.
 */
async function insertSnapshots(
  rows: Row[], observedAt: Date, kind: PassKind,
): Promise<void> {
  try {
    await writeSnapshots(rows, observedAt, kind, SNAPSHOT_CONFLICT);
  } catch (err: any) {
    // 42P10 = aucun index unique ne correspond à l'ON CONFLICT : la migration
    // 041 n'est pas passée. On sauve la série du livre de COLLECTE avec
    // l'ancienne clé (un livre par passe) et on le crie : les livres parallèles
    // sont perdus jusqu'à la migration, la série du CLV ne l'est pas.
    if (err?.code === '42P10') {
      logger.error('[OddsLogger] ⛔ migration 041 non appliquée — snapshots des livres '
        + 'parallèles PERDUS ce cycle (série du livre de collecte sauvée). '
        + 'Lancer `npm run db:migrate:all`.');
      const primary = rows.filter((r) => r.bookmaker == null || COLLECT_BOOKS.includes(r.bookmaker));
      try {
        if (primary.length) await writeSnapshots(primary, observedAt, kind, LEGACY_SNAPSHOT_CONFLICT);
      } catch (err2: any) {
        logger.warn({ err: err2?.message, kind },
          '[OddsLogger] snapshot non archivé — odds_log reste à jour');
      }
      return;
    }
    logger.warn({ err: err?.message, kind },
      '[OddsLogger] snapshot non archivé — odds_log reste à jour');
  }
}

/** Clé d'unicité d'un snapshot : match × passe × LIVRE (migration 041). */
const SNAPSHOT_CONFLICT =
  '(game_date, home_team, away_team, observed_at, (COALESCE(bookmaker, \'\')))';
/** Ancienne clé (031) : un seul livre par passe. Repli si la 041 manque. */
const LEGACY_SNAPSHOT_CONFLICT = '(game_date, home_team, away_team, observed_at)';

async function writeSnapshots(
  rows: Row[], observedAt: Date, kind: PassKind, conflict: string,
): Promise<void> {
    await pool.query(
      `INSERT INTO odds_snapshots (game_date, home_team, away_team,
                                   observed_at, commence_time, markets,
                                   home_ml, away_ml, total,
                                   total_over, total_under,
                                   puck_line_home, pl_home_price, pl_away_price,
                                   bookmaker)
       SELECT * FROM unnest(
         $1::date[], $2::text[], $3::text[],
         $4::timestamptz[], $5::timestamptz[], $6::text[],
         $7::numeric[], $8::numeric[], $9::numeric[],
         $10::numeric[], $11::numeric[],
         $12::numeric[], $13::numeric[], $14::numeric[],
         $15::text[]
       )
       ON CONFLICT ${conflict} DO NOTHING`,
      [
        ...keyColumns(rows),
        rows.map(() => observedAt),
        rows.map((r) => r.commenceTime),
        rows.map(() => kind),
        ...priceColumns(rows),
        rows.map((r) => r.bookmaker),
      ],
    );
}

/**
 * Rend le journal au format CSV attendu par `fetch_data_v4.py`.
 *
 * Le format de sortie est inchangé — c'est le stockage qui a bougé, pas le
 * contrat avec le pipeline ML. Utilisé par `npm run odds:export`.
 */
export async function exportOddsLogCsv(): Promise<string> {
  const { rows } = await pool.query(
    `SELECT to_char(game_date, 'YYYY-MM-DD') AS date, home_team, away_team,
            home_ml_open, away_ml_open, home_ml_close, away_ml_close,
            total_open, total_close,
            total_open_over, total_open_under,
            total_close_over, total_close_under,
            puck_line_home, pl_home_price, pl_away_price
       FROM odds_log
      ORDER BY game_date ASC, home_team ASC`,
  );
  const num = (v: unknown) => (v == null ? '' : Number(v).toFixed(4));
  const lines = rows.map((r: any) => [
    r.date, r.home_team, r.away_team,
    num(r.home_ml_open), num(r.away_ml_open), num(r.home_ml_close), num(r.away_ml_close),
    num(r.total_open), num(r.total_close),
    num(r.total_open_over), num(r.total_open_under),
    num(r.total_close_over), num(r.total_close_under),
    num(r.puck_line_home), num(r.pl_home_price), num(r.pl_away_price),
    'oddsapi:live',
  ].join(','));
  return [HEADER, ...lines].join('\n') + '\n';
}

/**
 * Rend la série temporelle `odds_snapshots` au format de
 * `ml/data/odds_snapshots_hist.csv` (`fetch_data_v4.SNAPSHOT_COLS`), que le
 * backtest lit (`backtest_walkforward.load_snapshot_pairs`).
 *
 * `source` = `oddsapi:<livre>` — la même convention que le backfill
 * (`oddsapi:draftkings`) : les lignes live du livre de collecte prolongent sa
 * série, et chaque livre parallèle (`oddsapi:bet99_ca_on`) forme la sienne, que
 * le backtest juge séparément. Utilisé par `npm run odds:export-snapshots`.
 */
export async function exportOddsSnapshotsCsv(): Promise<string> {
  const { rows } = await pool.query(
    `SELECT to_char(game_date, 'YYYY-MM-DD') AS game_date, home_team, away_team,
            to_char(observed_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS observed_at,
            to_char(commence_time AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') AS commence_time,
            markets, home_ml, away_ml, total, total_over, total_under,
            puck_line_home, pl_home_price, pl_away_price, bookmaker
       FROM odds_snapshots
      ORDER BY game_date, home_team, observed_at, bookmaker`,
  );
  const num = (v: unknown) => (v == null ? '' : Number(v).toFixed(4));
  const header = 'game_date,home_team,away_team,observed_at,commence_time,markets,'
    + 'home_ml,away_ml,total,total_over,total_under,puck_line_home,pl_home_price,pl_away_price,source';
  const lines = rows.map((r: any) => [
    r.game_date, r.home_team, r.away_team, r.observed_at, r.commence_time ?? '', r.markets,
    num(r.home_ml), num(r.away_ml), num(r.total), num(r.total_over), num(r.total_under),
    num(r.puck_line_home), num(r.pl_home_price), num(r.pl_away_price),
    r.bookmaker ? `oddsapi:${r.bookmaker}` : 'oddsapi:live',
  ].join(','));
  return [header, ...lines].join('\n') + '\n';
}

// ── Calendrier de collecte ───────────────────────────────────────────────────
//
// CE QUI A CHANGÉ ET POURQUOI (A3, 2026-08-23). L'ancienne version faisait
// `setInterval(6 h)` amorcé au démarrage du processus : la phase dépendait donc
// de l'heure du dernier déploiement Railway. Rien ne garantissait qu'une passe
// tombe près d'une mise au jeu, et le dernier prix observé avant un match de
// 19 h ET pouvait dater de six heures. Or le CLV se mesure CONTRE la clôture :
// une « clôture » à T−5 h n'en est pas une, et toute la mesure s'en trouvait
// faussée dans le sens optimiste (une ligne qui a moins bougé paraît plus
// souvent du bon côté).
//
// LE BUDGET COMMANDE LA FORME. Plan 20K depuis le 2026-09-27 (avant : quota
// gratuit de 500, d'où une passe du soir réduite à la seule puck line). Répartition
// retenue : ~15 000 backfill, ~4 500 affichage, et la collecte ci-dessous.
//
// Ici : six passes h2h + spreads (2 crédits) = **12 crédits/jour, ~370/mois**
// (14/jour avant le 2026-10-01, quand les deux passes `full` prenaient aussi
// les totaux). Le moneyline
// retrouve une vraie clôture (son CLV est réel, A3) ; la puck line garde la
// sienne (règle A2). Les totaux ne sont plus collectés : ils sont clos, aucune
// stratégie vivante ne les price.
//
// LES HEURES. 11 h ET : les lignes du soir sont affichées, c'est l'ouverture
// utile. 17 h ET : dernière passe complète avant les matchs. 18 h 45 / 19 h 45 :
// juste avant les créneaux de 19 h et 20 h, qui portent la majorité du
// calendrier. 21 h 45 / 22 h 45 : les matchs de la côte Ouest.
const SLOTS: Array<{ hour: number; minute: number; kind: PassKind }> = [
  { hour: 11, minute: 0,  kind: 'full'    },
  { hour: 17, minute: 0,  kind: 'full'    },
  { hour: 18, minute: 45, kind: 'close'   },
  { hour: 19, minute: 45, kind: 'close'   },
  { hour: 21, minute: 45, kind: 'close'   },
  { hour: 22, minute: 45, kind: 'close'   },
];

const ET = 'America/New_York';

/** Minutes écoulées depuis minuit, heure murale de l'Est. */
function easternMinutesNow(now: Date): number {
  const [h, m] = new Intl.DateTimeFormat('en-CA', {
    timeZone: ET, hour12: false, hour: '2-digit', minute: '2-digit',
  }).format(now).split(':').map(Number);
  // `en-CA` rend minuit « 24:00 » plutôt que « 00:00 ».
  return (h % 24) * 60 + m;
}

/**
 * Prochain créneau et délai jusqu'à lui.
 *
 * Le calcul se fait en minutes d'horloge murale de l'Est, puis le délai est
 * appliqué comme une durée réelle. Aux deux bascules d'heure d'été de l'année,
 * l'écart entre les deux vaut une heure : un créneau tombe alors une heure trop
 * tôt ou trop tard, une fois. Le calendrier se recale au créneau suivant, et
 * une observation légèrement décalée deux fois par an ne change rien à une
 * mesure de CLV. La solution exacte demanderait une dépendance de cron, ce que
 * ce dépôt n'a pour aucun de ses autres jobs planifiés.
 */
function nextSlot(now: Date): { delayMs: number; kind: PassKind } {
  const cur = easternMinutesNow(now);
  const mins = SLOTS.map((s) => ({ at: s.hour * 60 + s.minute, kind: s.kind }));
  const next = mins.find((s) => s.at > cur) ?? { ...mins[0], at: mins[0].at + 1440 };
  return { delayMs: (next.at - cur) * 60_000, kind: next.kind };
}

let timer: NodeJS.Timeout | null = null;

/**
 * Lance la collecte quotidienne des cotes (idempotente, verrouillée).
 *
 * Chaque créneau se replanifie après son exécution plutôt que de tourner sur
 * un intervalle fixe : c'est ce qui permet d'espacer inégalement les passes
 * (une le matin, quatre serrées le soir) et de rester calé sur l'heure de
 * l'Est, à laquelle le calendrier NHL est écrit.
 */
export function startOddsLogger(): void {
  if (process.env.ODDS_LOG_ENABLED !== 'true') {
    // Ligne bruyante, pas un `return` muet (2026-10-12) : le drapeau est resté à
    // false sur Railway du 4 au 12 oct. 2026 sans que rien ne le signale — huit
    // jours de clôtures perdus pour toujours (l'historique The Odds API est payant).
    logger.warn('[OddsLogger] ⚠️ ODDS_LOG_ENABLED≠true — AUCUNE cote collectée pour le ML '
      + '(odds_log, odds_snapshots). Chaque jour de saison ainsi perdu ne se rattrape pas.');
    return;
  }
  if (!process.env.ODDS_API_KEY) {
    logger.warn('[OddsLogger] ODDS_API_KEY absent — logging désactivé.');
    return;
  }

  // Sans verrou, N instances consomment N× le quota The Odds API pour produire
  // exactement les mêmes lignes — c'est le job dont la duplication coûte
  // directement de l'argent.
  const run = async (kind: PassKind) => {
    try {
      await withJobLock('odds-logger', LOCK_TTL_MS, () => logTodaysOdds(kind));
    } catch (err: any) {
      logger.warn({ err: err?.message, kind }, '[OddsLogger] échec');
    }
  };

  const schedule = () => {
    const { delayMs, kind } = nextSlot(new Date());
    timer = setTimeout(() => {
      // On replanifie AVANT d'attendre la passe : une collecte lente ou en
      // échec ne doit pas décaler ni interrompre le calendrier.
      schedule();
      void run(kind);
    }, delayMs);
    timer.unref?.();
  };

  logger.info({ slots: SLOTS.length, creditsPerDay: SLOTS.reduce(
    (n, s) => n + COLLECT_COST[s.kind], 0),
    collect: COLLECT_BOOKS, parallel: ODDS_SHADOW_BOOKMAKERS }, '[OddsLogger] calendrier armé');
  schedule();

  // Contrôle de mise en service de la 031, au démarrage, sans dépenser un
  // crédit ni attendre la saison.
  //
  // POURQUOI IL FAUT LE FAIRE ICI. `insertSnapshots` avale délibérément son
  // erreur (odds_log prime sur la série temporelle : perdre la clôture du jour
  // coûte plus cher que perdre un point de mesure). La conséquence, voulue pour
  // une panne passagère, est intenable pour une migration oubliée : la collecte
  // tournerait toute la saison, les logs diraient « ok », et `odds_snapshots`
  // resterait vide — on ne le découvrirait qu'en ouvrant le mode `--clv`, une
  // saison trop tard, sur une donnée qu'aucune archive ne peut reconstituer.
  //
  // POURQUOI AU DÉMARRAGE ET PAS À LA PREMIÈRE PASSE. En intersaison,
  // `logTodaysOdds` retourne AVANT d'écrire (garde-fou `isSeasonActive`) : la
  // première écriture réelle n'a lieu qu'à la pré-saison. Un contrôle placé sur
  // le chemin d'écriture ne dirait donc rien pendant les cinq semaines où l'on
  // peut encore corriger. Celui-ci parle au premier déploiement.
  //
  // Le `to_regclass` ne lit aucune ligne et ne verrouille rien.
  //
  // 038 (2026-09-27) : `insertSnapshots` écrit maintenant la colonne
  // `bookmaker`. Sans la migration, CHAQUE insertion échouerait — et serait
  // avalée comme ci-dessus. Le contrôle porte donc sur la colonne, pas
  // seulement sur la table.
  void pool
    .query(`SELECT to_regclass('public.odds_snapshots') AS t,
                   EXISTS (SELECT 1 FROM information_schema.columns
                            WHERE table_name = 'odds_snapshots'
                              AND column_name = 'bookmaker') AS has_book,
                   to_regclass('public.uq_odds_snapshots_obs_book') AS multibook`)
    .then(({ rows }) => {
      // 041 (2026-10-04) : sans l'index par livre, les livres parallèles sont
      // perdus à chaque passe (la série du livre de collecte, elle, est sauvée
      // par le repli d'`insertSnapshots`).
      if (rows[0]?.t && rows[0]?.has_book && !rows[0]?.multibook && ODDS_SHADOW_BOOKMAKERS.length) {
        logger.error(
          `[OddsLogger] ⛔ migration 041 non appliquée — la collecte parallèle `
          + `(${ODDS_SHADOW_BOOKMAKERS.join(', ')}) sera PERDUE. Lancer \`npm run db:migrate:all\`.`,
        );
      }
      if (rows[0]?.t && !rows[0]?.has_book) {
        logger.error(
          '[OddsLogger] ⛔ `odds_snapshots.bookmaker` INTROUVABLE — migration 038 '
          + 'non appliquée. Chaque snapshot échouera EN SILENCE et la série du '
          + 'CLV sera perdue. Lancer `npm run db:migrate:all`.',
        );
        return;
      }
      if (rows[0]?.t) {
        // Ligne de SUCCÈS, et pas seulement d'échec. Un contrôle muet quand
        // tout va bien ne se distingue pas d'un contrôle qui n'a pas tourné :
        // au démarrage du 2026-08-28, « je ne vois pas d'erreur » ne prouvait
        // rien de plus que « je n'ai pas déroulé les logs ». Le prochain
        // contrôle réel est en pré-saison, à cinq semaines de distance et sur
        // une donnée irrécupérable — il faut quelque chose à chercher, pas une
        // absence à interpréter.
        logger.info('[OddsLogger] ✅ `odds_snapshots` présente — série '
          + 'temporelle du CLV prête (migration 031 appliquée).');
        return;
      }
      logger.error(
        '[OddsLogger] ⛔ `odds_snapshots` INTROUVABLE — migration 031 non '
        + 'appliquée. La collecte va tourner et remplir `odds_log`, mais la '
        + 'série temporelle du CLV sera perdue jour après jour, en silence. '
        + 'Lancer `npm run db:migrate:all`.',
      );
    })
    .catch((err: any) => {
      // Base injoignable : le serveur a déjà tranché plus haut, on ne double
      // pas l'alarme — mais on ne prétend pas non plus avoir vérifié.
      logger.warn({ err: err?.message },
        '[OddsLogger] contrôle de `odds_snapshots` impossible.');
    });

  // Vérification de mise en service, explicitement opt-in.
  //
  // L'ancienne version lançait une passe 20 s après chaque démarrage. Railway
  // redéploie souvent : c'étaient 3 crédits offerts à chaque déploiement, pour
  // une donnée que le créneau suivant aurait ramenée de toute façon. Le
  // calendrier ne fait donc plus rien au boot — mais il faut bien pouvoir
  // constater UNE fois que la chaîne complète fonctionne, sans attendre 11 h ET.
  // D'où cette variable, à poser le temps d'un déploiement puis à retirer.
  if (process.env.ODDS_LOG_RUN_AT_BOOT === 'true') {
    logger.warn('[OddsLogger] ODDS_LOG_RUN_AT_BOOT — passe de vérification, '
      + 'à retirer après contrôle (3 crédits par démarrage).');
    setTimeout(() => void run('full'), 20_000).unref?.();
  }
}
